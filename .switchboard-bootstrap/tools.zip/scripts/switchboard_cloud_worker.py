#!/usr/bin/env python3
"""Publish a completed Cloud worker result bound to a Switchboard dispatch."""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path

from ctxlib import switchboard_cloud_worker as worker
from ctxlib.core import Config, Context, NotReady
from ctxlib.switchboard import redact


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--envelope', type=Path, required=True)
    parser.add_argument('--report', type=Path, required=True)
    parser.add_argument('--workspace', type=Path, required=True)
    parser.add_argument('--ticket', required=True)
    parser.add_argument('--state-dir', type=Path, default=Path(os.environ.get('CTX_STATE_DIR', Path.home() / '.local/share/ctx')))
    parser.add_argument('--host', default=os.environ.get('CTX_HOST', ''))
    args = parser.parse_args(argv)
    try:
        ctx = Context(Config(state=args.state_dir, host=args.host))
        result = worker.complete(ctx, envelope_path=args.envelope, report_path=args.report,
                                 workspace=args.workspace, ticket_id=args.ticket)
    except (NotReady, OSError, ValueError) as error:
        result = {'status': 'not_ready', 'reason': redact(str(error)), 'outputs_retained': True}
    print(json.dumps(result, ensure_ascii=False))
    return 0 if result['status'] == 'complete' else 2


if __name__ == '__main__':
    raise SystemExit(main())
