#!/usr/bin/env -S uv run --script
# /// script
# requires-python = ">=3.11"
# dependencies = ["websockets>=15,<17"]
# ///
"""Hand work between machines (sessions and Switchboard tasks), find earlier agent conversations, and query personal data."""

from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import sys
import time
import uuid
from datetime import datetime
from pathlib import Path

from ctxlib import (
    data,
    handoff,
    inbox,
    index,
    places,
    project_data,
    project_data_audit,
    project_data_cloud,
    project_data_completion,
    recall,
    review,
    switchboard,
)
from ctxlib.core import Config, Context

SUCCESS = {"complete", "complete_with_gaps", "catching_up", "registered", "started"}
ID_WIDTH = 10
TURN_CHARACTERS = 1200
ZONE = datetime.now().astimezone().isoformat()[-6:]


def parser():
    shared = argparse.ArgumentParser(add_help=False)
    shared.add_argument("--json", action="store_true", default=argparse.SUPPRESS, help="machine-readable output")
    root = argparse.ArgumentParser(description=__doc__)
    root.add_argument("--json", action="store_true", help="machine-readable output")
    root.add_argument("--state-dir", type=Path, default=Path(os.environ.get("CTX_STATE_DIR", Path.home() / ".local/share/ctx")))
    root.add_argument("--host", default=os.environ.get("CTX_HOST", ""))
    root.add_argument("--native-home", type=Path)
    root.add_argument("--registry-owner", default="m1pro")
    commands = root.add_subparsers(dest="command", required=True)

    def scoped(command):
        command.add_argument("-p", "--project")
        command.add_argument("--since", help="e.g. 24h, 7d, or an ISO time with offset")
        command.add_argument("--all", action="store_true", help="include headless and subagent sessions")
        return command

    find = scoped(commands.add_parser("find", parents=[shared], help="search conversations of both Macs; one line per session"))
    find.add_argument("query")
    find.add_argument("-n", "--limit", type=int, default=10)
    find.add_argument("-s", "--session", help="ID from ctx find or ctx ls: list every matching turn of that session")
    read = commands.add_parser("read", parents=[shared], help="read turns of one conversation")
    read.add_argument("ref", help="ID or ID@TURN from ctx find")
    read.add_argument("turns", nargs="?", help="START:END or TURN")
    read.add_argument("--full", action="store_true", help="do not clip long turns")
    read.add_argument("--raw", action="store_true", help="include the native records behind the turns (asks the owning Mac)")
    listing = commands.add_parser("ls", parents=[shared], help="list sessions, handoffs, or projects")
    listing.add_argument("kind", choices=("sessions", "handoffs", "projects"))
    scoped(listing)
    listing.add_argument("-n", "--limit", type=int, default=30)
    commands.add_parser("status", parents=[shared], help="index freshness, peers and gaps")
    sync = commands.add_parser("sync", parents=[shared], help="index this Mac's sessions and pull the other Mac's")
    sync.add_argument("--budget", type=float, default=300, help="seconds for local indexing")
    export = commands.add_parser("_export", parents=[shared])
    export.add_argument("after", type=int)
    export.add_argument("epoch")

    data = commands.add_parser("data", help="personal data in the Vault: dayflow, health, reminders").add_subparsers(dest="data_command")
    def source(name, help):
        command = data.add_parser(name, parents=[shared], help=help)
        command.add_argument("--vault", help="Database checkout; default CTX_VAULT or the iCloud Vault")
        return command
    source("ls", "sources, file counts and freshness")
    flow = source("dayflow", "activity cards for a day or range")
    flow.add_argument("day", nargs="?", help="YYYY-MM-DD, today or yesterday (04:00 Asia/Seoul boundary)")
    flow.add_argument("--since", help="7d, 2w or YYYY-MM-DD")
    flow.add_argument("--until")
    flow.add_argument("-s", "--search")
    body = source("health", "Apple Health: one row per day by default; sleep, workouts or raw samples")
    body.add_argument("--kind", default="days", choices=("days", "sleep", "workouts", "samples"))
    body.add_argument("--since", help="7d (default), 2w or YYYY-MM-DD")
    body.add_argument("--until")
    body.add_argument("-m", "--metric", help="day column, workout kind or sample metric substring")
    body.add_argument("-n", "--limit", type=int, default=2000)
    todo = source("reminders", "open Apple Reminders, or changes between snapshots")
    todo.add_argument("-s", "--search", help="title or notes substring")
    todo.add_argument("-l", "--list", dest="list_name", help="exact list name, e.g. Inbox")
    todo.add_argument("--diff", nargs="?", const="sent", metavar="OLD_JSON",
                      help="changes from an older open.json; without a path, from M1's last delivered snapshot")
    refresh = source("sync", "export this Mac's sources; on M1 also send context diffs to Cloud and autosave the Vault")
    refresh.add_argument("--full", action="store_true", help="rewrite the full history")
    refresh.add_argument("--source", action="append", choices=("dayflow", "health", "reminders"))

    project_files = commands.add_parser("project-data", help="prepare and publish opt-in NAS project data").add_subparsers(dest="project_data_command", required=True)
    project_files.add_parser("audit", parents=[shared], help="account for every fresh registry entry; no copying or publication checks")
    cloud = project_files.add_parser("configure-cloud", parents=[shared], help="save a nonsecret provider profile in ctx runtime state")
    cloud.add_argument("--provider", required=True, choices=project_data_cloud.PROVIDERS)
    completed = project_files.add_parser("complete", parents=[shared], help="seal explicitly finished results for scheduled publication")
    completed.add_argument("--workspace", help="producing Git repository; default current directory")
    completed.add_argument("--project", help="approved stable project ID or alias")
    completed.add_argument("--ticket", help="prepared external data ticket")
    completed.add_argument("--task", help="new ticket ID for local result capture")
    completed.add_argument("--path", action="append", help="finished local managed path; repeat as needed")
    completed.add_argument("--base", help="known input revision; required when sealing local paths")
    ready = project_files.add_parser("publish-ready", parents=[shared], help="publish only sealed completed tickets; retain failures")
    ready.add_argument("--ticket", help="publish this completed ticket now")
    ready.add_argument("--workspace", help="limit publication to this producing repository")
    for name, help_text in (("status", "inspect this project's managed data"),
                            ("prepare", "pin shared data in an external writable task workspace"),
                            ("publish", "freeze and publish a prepared task's data")):
        operation = project_files.add_parser(name, parents=[shared], help=help_text)
        operation.add_argument("--workspace", help="Git workspace; default current directory")
        operation.add_argument("--project", help="approved stable Cloud project ID or unambiguous alias")
        if name == "prepare":
            operation.add_argument("--task", help="unique task ID; generated when omitted")
            operation.add_argument("--path", action="append", help="selected managed relative path; repeat to fetch a subset")
            operation.add_argument("--revision", help="published revision to resume; otherwise use latest")
        elif name == "publish":
            operation.add_argument("--ticket", required=True, help="ID returned by prepare")

    transfers = commands.add_parser("handoff", help="continue the saved session and its files on another host").add_subparsers(dest="handoff_command", required=True)
    selected = transfers.add_parser("files", parents=[shared], help="validate .ctxignore and list allowed extra files; no transfer")
    selected.add_argument("--workspace", help="Git workspace to inspect; default the current directory")
    push = transfers.add_parser("push", parents=[shared], help="send the current workspace's saved session; returns it home from a received worktree")
    push.add_argument("--harness", choices=("codex", "claude"))
    push.add_argument("--to", help="destination host; default the host it came from, else m1pro")
    push.add_argument("--session")
    push.add_argument("--workspace", help="Git workspace to send; default the current directory")
    push.add_argument("--data-ticket", help="prepared project-data ticket ID; otherwise reuse the received handoff's ticket")
    pull = transfers.add_parser("pull", parents=[shared], help="ask the receiving host to push this host's latest handoff back")
    pull.add_argument("handoff_id", nargs="?")
    receive = transfers.add_parser("_receive", parents=[shared])
    receive.add_argument("phase", choices=("check", "apply", "launch"))

    where = commands.add_parser("places", parents=[shared], help="Git repositories with recent agent work on each host, for task placement")
    where.add_argument("--local", action="store_true", help="this host only")
    where.add_argument("--publish", action="store_true", help="write PLACES.md to the Switchboard repository when it changed")
    where.add_argument("--check", metavar="DIR", help="whether DIR lies inside one of this host's places")

    tasks = commands.add_parser("task", help="Switchboard tasks: unattended work on a chosen machine and directory").add_subparsers(dest="task_command", required=True)
    create = tasks.add_parser("create", parents=[shared], help="open a task; the body uses the board's ### sections")
    create.add_argument("--machine", help="m1, m3, nas, bv, codex-cloud or claude-cloud; default the continued session's host")
    create.add_argument("--continues", metavar="ID", help="follow up a session from ctx ps: its directory, harness and state fill the body")
    create.add_argument("--title", required=True)
    create.add_argument("--body-file", required=True, help="path, or - for stdin")
    create.add_argument("--new-place", action="store_true", help="allow a directory that ctx places does not list")
    create.add_argument("--dry-run", action="store_true", help="check the body and place without opening the issue")
    show_tasks = tasks.add_parser("ls", parents=[shared], help="open tasks, optionally by state label")
    show_tasks.add_argument("--state", choices=("running", "done", "failed", "wake-pending"))
    show_tasks.add_argument("-n", "--limit", type=int, default=30)
    for name, text in (("show", "state and latest result of a task"), ("retry", "run a finished task again")):
        tasks.add_parser(name, parents=[shared], help=text).add_argument("number", type=int)
    def issue_number(value):
        if not value.isascii() or not value.isdigit():
            raise argparse.ArgumentTypeError(f"issue number must be digits, not {value!r}")
        return int(value)

    runner = tasks.add_parser("_run", parents=[shared])
    runner.add_argument("number", type=issue_number)
    runner.add_argument("--machine", required=True, choices=switchboard.MACHINE_LABELS)
    cloud_attach = tasks.add_parser('cloud-attach', parents=[shared], help='attach an existing Codex Jstack web task and resume M1 supervision')
    cloud_attach.add_argument('number', type=issue_number)
    cloud_attach.add_argument('--url', required=True, help='exact existing ChatGPT Work task URL')
    for name in ("_reconcile", "_wake"):
        tasks.add_parser(name, parents=[shared]).add_argument("number", type=issue_number)
    lab_claim = tasks.add_parser("_claim", parents=[shared])
    lab_finish = tasks.add_parser("_finish", parents=[shared])
    for lab_parser in (lab_claim, lab_finish):
        lab_parser.add_argument("number", type=issue_number)
        lab_parser.add_argument("--machine", required=True, choices=switchboard.LAB_LABELS)
    lab_finish.add_argument("--job-result", required=True, choices=("success", "failure", "cancelled", "skipped"))
    tasks.add_parser("_sweep", parents=[shared])

    status_list = commands.add_parser("ps", parents=[shared], help="what agent sessions and Switchboard tasks are doing, waiting on, or left unread (all hosts)")
    status_list.add_argument("--here", action="store_true", help="only sessions in this repository and its worktrees, excluding this session")
    status_list.add_argument("--since", default="24h", help="also list items read within this period (default 24h)")
    status_list.add_argument("--all", action="store_true", help="include headless and subagent sessions")
    status_list.add_argument("-n", "--limit", type=int, default=60)
    status_list.add_argument("--root", action="append", default=[], help=argparse.SUPPRESS)
    status_list.add_argument("--exclude", action="append", default=[], help=argparse.SUPPRESS)
    detail = commands.add_parser("show", parents=[shared], help="one session or task from ctx ps: last exchange, what waits on you, changes, live progress")
    detail.add_argument("ref", help="ID from ctx ps, or #N for a Switchboard task")
    detail.add_argument("--live", action="store_true", help="also read the latest turn from the owning host (default for running sessions)")
    detail.add_argument("--brief", action="store_true", help="identity only, for pasting into another agent")

    queue = commands.add_parser("inbox", parents=[shared], help="sessions and Switchboard tasks waiting for review (stored on M1)")
    queue.add_argument("action", nargs="?", default="ls", choices=("ls", "dismiss", "unread", "focus", "_focus", "_ingest", "_flush", "_switchboard", "_sessions", "_reconcile",
                                                             "_pull", "_export", "_ack", "_activity"))
    queue.add_argument("keys", nargs="*", help="item IDs (any unique prefix) to dismiss or mark unread")
    queue.add_argument("--all", action="store_true", help="ls: include background sessions; dismiss: every unread item")

    add = commands.add_parser("projects").add_subparsers(dest="projects_command", required=True).add_parser("add", parents=[shared])
    add.add_argument("path")
    add.add_argument("--id", required=True)
    add.add_argument("--mode", choices=("workspace", "catalog"), default="workspace")
    add.add_argument("--label")
    add.add_argument("--promote", action="store_true", help="mark an existing catalog entry as a verified Git workspace")
    add.add_argument("--alias", action="append", default=[])
    add.add_argument("--git-owner", choices=tuple(places.RUN_LABELS),
                     help="the only host that may write this repository's Git; Switchboard runs its tasks only there")
    commands.add_parser("_register", parents=[shared])
    commands.add_parser("_registry", parents=[shared])
    return root


def personal(args, ctx=None):
    command = args.data_command or "ls"
    root = getattr(args, "vault", None)
    if command == "dayflow":
        return data.dayflow(root, day=args.day, since=args.since, until=args.until, text=args.search)
    if command == "health":
        return data.health(root, kind=args.kind, since=args.since, until=args.until, metric=args.metric, limit=args.limit)
    if command == "reminders":
        return data.reminders(root, text=args.search, list_name=args.list_name, diff=args.diff, ctx=ctx)
    return data.listing(root)


def run_task_command(ctx, args):
    command = args.task_command
    if command == "create":
        body = sys.stdin.read() if args.body_file == "-" else Path(args.body_file).read_text()
        machine = args.machine
        if args.continues:
            body, machine = review.continuation(ctx, args.continues, body, machine)
        if not machine:
            raise ValueError("--machine is required unless --continues names a session")
        result = switchboard.create(ctx, machine, args.title, body, new_place=args.new_place, dry_run=args.dry_run)
        if args.dry_run:
            result.setdefault('body', body)
        return result
    if command == "ls":
        return switchboard.listing(args.state, args.limit)
    if command == "show":
        return switchboard.show(args.number)
    if command == "retry":
        return switchboard.retry(args.number)
    if command == 'cloud-attach':
        return switchboard.cloud_attach(ctx, switchboard.BOARD, args.number, args.url)
    run_id = os.environ.get("GITHUB_RUN_ID") or datetime.now().strftime("%Y%m%d%H%M%S")
    if command == "_run":
        code = switchboard.run_task(ctx, switchboard.BOARD, args.number, args.machine, run_id)
    elif command == "_reconcile":
        code = switchboard.reconcile(switchboard.BOARD, args.number, run_id, ctx=ctx)
    elif command == "_wake":
        code = switchboard.wake(switchboard.BOARD, args.number)
    elif command == "_claim":
        code = switchboard.claim(ctx, switchboard.BOARD, args.number, args.machine, run_id)
    elif command == "_finish":
        code = switchboard.finish_lab(switchboard.BOARD, args.number, args.machine, run_id, args.job_result)
    else:
        code = switchboard.sweep(ctx, switchboard.BOARD, run_id)
    return {"status": "complete" if code == 0 else "failed"}


def dispatch(ctx, args):
    if args.command == "project-data":
        if args.project_data_command == "audit":
            return project_data_audit.audit(ctx)
        if args.project_data_command == "configure-cloud":
            return project_data_cloud.configure(ctx, args.provider)
        if args.project_data_command == "publish-ready":
            return project_data_completion.publish_ready(ctx, ticket_id=args.ticket, root=args.workspace)
        workspace = Path(args.workspace or Path.cwd()).expanduser().resolve()
        with project_data_cloud.selected_project(args.project):
            if args.project_data_command == "complete":
                result = project_data_completion.complete(ctx, workspace, identifier=args.task,
                                                          ticket_id=args.ticket, selected_paths=args.path, base=args.base)
            elif args.project_data_command == "status":
                result = project_data.status(ctx, workspace)
            elif args.project_data_command == "prepare":
                options = {'selected_paths': args.path} if args.path is not None else {}
                if args.revision:
                    options['pinned'] = {'revision': args.revision}
                result = project_data.prepare(ctx, workspace, args.task or uuid.uuid4().hex, **options)
            else:
                ticket = project_data.load_ticket(ctx, args.ticket)
                if not ticket.get("frozen"):
                    ticket = project_data.freeze(ctx, ticket, workspace)
                result = project_data.publish(ctx, ticket, integrated_root=workspace)
        if result is None:
            return {"status": "complete", "managed": False, "workspace": str(workspace)}
        return {**result, "data_status": result.get("status"), "status": "complete"}
    if args.command == "find":
        return recall.find(ctx, args.query, project=args.project, since=args.since, everything=args.all, limit=args.limit, session=args.session)
    if args.command == "read":
        return recall.read(ctx, args.ref, turns=args.turns, raw=args.raw)
    if args.command == "ls":
        if args.kind == "projects":
            return {"status": "complete", **ctx.registry()}
        if args.kind == "handoffs":
            return handoff.listing(ctx, args.limit)
        return recall.sessions(ctx, project=args.project, since=args.since, everything=args.all, limit=args.limit)
    if args.command == "status":
        return recall.status(ctx)
    if args.command == "sync":
        return recall.sync(ctx, budget=args.budget)
    if args.command == "_export":
        return index.export(ctx, args.after, None if args.epoch == "-" else args.epoch)
    if args.command == "data":
        if args.data_command == "sync":
            return data.sync(ctx, root=args.vault, full=args.full, sources=args.source)
        return personal(args, ctx)
    if args.command == "places":
        if args.publish:
            return places.publish(ctx, switchboard.BOARD)
        if args.check:
            return places.check(ctx, args.check)
        return places.local(ctx) if args.local else places.everywhere(ctx)
    if args.command == "task":
        return run_task_command(ctx, args)
    if args.command == "ps":
        scope = review.here(ctx.config.host) if args.here else {"roots": args.root}
        exclude = [*args.exclude, *(review._excluded() if args.here else [])]
        return review.ps(ctx, since=_seconds(args.since), everything=args.all, scope=scope, exclude=exclude, limit=args.limit)
    if args.command == "show":
        return review.show(ctx, args.ref, live=args.live or None, brief=args.brief)
    if args.command == "inbox":
        payload = json.load(sys.stdin) if args.action in {"_ingest", "_focus", "_export", "_ack", "_activity"} else None
        return inbox.run(args.action, host=ctx.config.host, keys=tuple(args.keys), everything=args.all, payload=payload)
    if args.command == "projects":
        return ctx.register(args.path, args.id, mode=args.mode, label=args.label, aliases=args.alias, promote=args.promote,
                            git_owner=args.git_owner)
    if args.command == "_register":
        return ctx.register_entry(json.load(sys.stdin))
    if args.command == "_registry":
        return ctx.receive_registry(json.load(sys.stdin))
    if args.handoff_command == "files":
        return handoff.files(ctx, args.workspace)
    if args.handoff_command == "push":
        return handoff.push(ctx, destination=args.to, harness=args.harness, session=args.session,
                            workspace=args.workspace, data_ticket=args.data_ticket)
    if args.handoff_command == "_receive":
        return handoff.receive(ctx, args.phase, json.load(sys.stdin))
    return handoff.pull(ctx, args.handoff_id)


def _seconds(value):
    match = re.fullmatch(r"(\d+)([smhd])", value or "")
    if not match:
        raise ValueError("--since takes a period such as 90m, 24h or 7d")
    return int(match[1]) * {"s": 1, "m": 60, "h": 3600, "d": 86400}[match[2]]


def _local(value, pattern):
    """Native timestamps are UTC; show them in this Mac's zone, which the header names."""
    try:
        return datetime.fromisoformat((value or "").replace("Z", "+00:00")).astimezone().strftime(pattern)
    except ValueError:
        return "-"


def _day(value):
    return _local(value, "%Y-%m-%d")


def _minute(value):
    return _local(value, "%Y-%m-%d %H:%M")


def _index_line(index):
    hosts = " ".join(f"{host} {count}" for host, count in sorted(index.get("sessions", {}).items()))
    stale = [peer for peer, value in index.get("peers", {}).items() if value.get("error")]
    return (f"index {_minute(index.get('indexed_at'))} · times {ZONE} · sessions {hosts}"
            + (f" · {index['pending_sessions']} pending" if index.get("pending_sessions") else "")
            + (f" · {index['gaps']} gaps (ctx status)" if index.get("gaps") else "")
            + (f" · {','.join(stale)} unreachable since last pull" if stale else ""))


def _found(result):
    if result.get("session"):
        source = result["session"]
        lines = [f"{len(result['hits'])} matching turns{' (more: raise -n)' if result['more'] else ''} in {source['id'][:ID_WIDTH]} "
                 f"{source['harness']}@{source['host']} | {source['title'][:60]} · times {ZONE}"]
        return lines + [f"{source['id'][:ID_WIDTH]}@{hit['turn']} {_minute(hit['timestamp'])} {hit['role']} | {hit['snippet']}" for hit in result["hits"]]
    lines = [f"{len(result['hits'])} sessions{' (more: raise -n or narrow)' if result['more'] else ''} · " + _index_line(result["index"])]
    for hit in result["hits"]:
        extra = f" ×{hit['matches']}" if hit["matches"] > 1 else ""
        lines.append(f"{hit['id'][:ID_WIDTH]}@{hit['turn']} {_day(hit['timestamp'])} {hit['project_id'] or '-'} "
                     f"{hit['harness']}@{hit['host']} {hit['role']}{extra} | {hit['title'][:40]} | {hit['snippet']}")
    return lines


def _read(result, full):
    source, selection = result["source"], result["selection"]
    lines = [f"{source['id'][:ID_WIDTH]} {source['project_id'] or '-'} {source['harness']}@{source['host']} "
             f"{source['origin']} | {source['title']} | turns {selection.get('start', 0)}-{selection.get('end', 0)} of {selection['available_turns']} · times {ZONE}"]
    for message in result["messages"]:
        text = message["text"]
        if not full and len(text) > TURN_CHARACTERS:
            text = text[:TURN_CHARACTERS] + f"… [+{len(text) - TURN_CHARACTERS} chars: --full]"
        lines += [f"[{message['turn']}] {message['role']} {_minute(message['timestamp'])}", text]
    lines += [json.dumps(record, ensure_ascii=False) for record in result.get("records", [])]
    return lines


def _sessions(result):
    more = f" (+{result['more']} more)" if result["more"] else ""
    lines = [f"{len(result['sessions'])} sessions{more} · " + _index_line(result["index"])]
    for item in result["sessions"]:
        origin = "" if item["origin"] == "interactive" else " " + item["origin"]
        lines.append(f"{item['id'][:ID_WIDTH]} {_minute(item['last_message_at'])} {item['project_id'] or '-'} "
                     f"{item['harness']}@{item['host']}{origin} | {item['title'][:70]}")
    return lines


def _handoffs(result):
    lines = []
    for item in result["handoffs"]:
        when = time.strftime("%Y-%m-%d %H:%M", time.localtime(item["at"]))
        route = f"{item['host']}→{item['peer']}" if item["direction"] == "sent" else f"{item['peer']}→{item['host']}"
        lines.append(f"{item['handoff_id']} {when} {route} {item['harness']} {item['mode']} {item.get('target', item['workspace'])}")
    return lines or ["no handoffs"]


def _projects(result, host):
    lines = []
    for project in result["projects"]:
        label = "" if project.get("label", project["id"]) == project["id"] else f" ({project['label']})"
        place = project["paths"].get(host) or ",".join(project["paths"])
        lines.append(f"{project['id']}{label} {project.get('mode', 'workspace')} {place}")
    return lines


def _status(result):
    lines = [_index_line({**result, "gaps": len(result["gap_sessions"])})]
    for peer, value in result["peers"].items():
        lines.append(f"{peer}: pulled {_minute(value.get('pulled_at'))}" + (f" · last error {_minute(value.get('failed_at'))} {value['error']}" if value.get("error") else ""))
    lines += [f"gap {item['id'][:ID_WIDTH]} {item['harness']}@{item['host']} {item['native_id']}: {item['reason']}" for item in result["gap_sessions"]]
    return lines


def _sync(result):
    local = result["local"]
    fields = [result["status"], f"indexed {local['indexed_sessions']}", f"pending {local['pending_sessions']}" if local["pending_sessions"] else ""]
    fields += [f"{peer} {value['status']} +{value['sessions']} sessions" for peer, value in result["peers"].items()]
    return [" · ".join(filter(None, fields))]


def _data(args, result):
    command = args.data_command or "ls"
    if command == "sync":
        parts = [f"{name} {value['status']}" for name, value in result["sources"].items()]
        parts += [f"{name} {result[name]['status']}" for name in ("context_diffs", "autosave") if name in result]
        return [result["status"] + (": " + ", ".join(parts) if parts else "")]
    if command == "dayflow":
        lines = [f"{len(result['cards'])} cards {result['from']}..{result['to']}"]
        clock = lambda value: value[11:16] if len(value) > 16 else value
        return lines + [f"{card['date']} {clock(card['start'])}-{clock(card['end'])} {card['title']} | {card['summary']}" for card in result["cards"]]
    if command == "health":
        rows = result["rows"]
        if result["kind"] == "days" and rows:
            used = [name for name in rows[0] if any(row.get(name) for row in rows)]
            rows = [{name: row[name] for name in used} for row in rows]
        lines = [f"{len(rows)} {result['kind']} rows {result['from']}..{result['to']}" + (f" (+{result['omitted']} earlier; narrow or -n)" if result["omitted"] else "")]
        if rows:
            lines.append(",".join(rows[0]))
            lines += [",".join(str(value) for value in row.values()) for row in rows]
        return lines
    if command == "reminders":
        if "changes" in result:
            return result["lines"] or ["no changes"]
        return [" | ".join([item["list"], item["title"]] + [f"{key} {item[key]}" for key in ("due", "priority") if key in item])
                for item in result["reminders"]] or ["no open reminders"]
    lines = [f"vault {result['vault']}"]
    for name, value in result["sources"].items():
        lines.append(f"{name} ({value['host']}): {value['files']} files {value['first'] or '-'}..{value['last'] or '-'} · modified {_minute(value['modified_at'])}")
    return lines


def _transfer(result):
    fields = [result.get("status"), result.get("handoff_id")]
    if "source_safe_to_close" in result:
        fields.append("safe_to_close=" + ("yes" if result["source_safe_to_close"] else "no"))
    if "elapsed_seconds" in result:
        fields.append(f"{result['elapsed_seconds']:.1f}s")
    for key in ("destination", "mode", "workspace", "native_id", "url", "mobile_url", "reason", "resume_command", "note"):
        if result.get(key):
            fields.append(f"{key}={result[key]}")
    viewer = result.get("viewer")
    if viewer:
        fields.append("viewer=" + viewer["status"] + (f" ({viewer['reason']})" if viewer.get("reason") else ""))
    lines = [" ".join(str(field) for field in fields if field)]
    if result.get("missing"):
        lines.append(f"{len(result['missing'])} conversation attachments were already missing on this host")
    return lines


def _inbox(result):
    marks = {"unread": "●", "running": "◌", "read": " "}
    lines = [f"{result['unread']} unread"]
    for item in result["items"]:
        stamp = item["stop_at"] or item["prompt_at"] or item["updated_at"]
        duration = f" {item['duration'] // 60}m{item['duration'] % 60:02d}s" if item["duration"] is not None else ""
        lines.append(f"{marks[item['state']]} {item['id']} {time.strftime('%m-%d %H:%M', time.localtime(stamp))}{duration} "
                     f"{item['host']} {item['surface'] or item['harness']} {item['cwd'] or '-'} | {item['title'][:70]}")
    return lines


def _clock(stamp, now=None):
    """HH:MM today, else MM-DD HH:MM."""
    if not stamp:
        return "-"
    same_day = time.localtime(stamp)[:3] == time.localtime(now or time.time())[:3]
    return time.strftime("%H:%M" if same_day else "%m-%d %H:%M", time.localtime(stamp))


def _span(seconds):
    seconds = int(seconds or 0)
    return f"{seconds // 3600}h{seconds % 3600 // 60:02d}m" if seconds >= 3600 else f"{seconds // 60}m"


def _first_line(text, width):
    line = next((line.strip() for line in (text or "").splitlines() if line.strip()), "")
    return line[:width] + ("…" if len(line) > width else "")


def _excerpt(text, width):
    """Head and tail of a long reply: agents put the summary first and the question last."""
    text = (text or "").strip()
    if len(text) <= width:
        return text
    head = width // 3
    return text[:head].rstrip() + f"\n… [{len(text) - width} chars omitted] …\n" + text[-(width - head):].lstrip()


def _who(item):
    if item["kind"] == "task":
        return f"#{item['native_id']} switchboard {item['harness']}@{item['host']}"
    return f"{item['id']} {item['harness']}@{item['host']} {item['surface'] or '-'}"


def _place(item):
    return f"{item['project']}" + (f"@{item['branch']}" if item.get("branch") else "")


def _ps(result):
    counts = result["counts"]
    window = _span(result["since_seconds"]) if result["since_seconds"] < 86400 else f"{result['since_seconds'] // 86400}d"
    head = (f"{counts['needs-you']} needs-you · {counts['running']} running · {counts['unread']} unread · "
            f"{counts['read']} read in {window}" + (f" ({result['older_read']} older read not shown)" if result["older_read"] else "")
            + (" · this repository only" if result["scoped"] else "") + f" · times {ZONE}")
    lines, group, now = [head], None, time.time()
    for item in result["items"]:
        if item["status"] != group:
            group = item["status"]
            lines.append(group)
        if item["kind"] == "task":
            detail = f"task {item['task_state'] or '-'}"
        elif item["status"] == "needs-you":
            detail = "waits: " + _first_line(item["waiting"] or item["question"], 160)
        elif item["state"] == "running":
            detail = f"running {_span(now - (item['prompt_at'] or now))} > " + _first_line(item["prompt"], 120)
        else:
            changed = ", ".join(filter(None, [f"{len(item['files'])} files" if item["files"] else "",
                                              f"{len(item['commits'])} commits" if item["commits"] else ""]))
            detail = (changed + " | " if changed else "") + _first_line(item["reply"], 140)
        duration = f" {_span(item['duration'])}" if item.get("duration") else ""
        lines.append(f"  {_who(item)} {_place(item)} {_clock(item['at'], now)}{duration} | {item['title'][:70]} | {detail}")
    if result["more"]:
        lines.append(f"  … {result['more']} more not shown (read items beyond the latest {review.READ_SHOWN}; -n, --since)")
    lines.append("next: ctx show ID (#N for a task) · ctx read ID (conversation turns) · ctx task create --continues ID")
    return lines


def _paths(paths, cwd):
    """Paths inside the session's directory relative to it; others as given."""
    prefix = (cwd or "").rstrip("/") + "/"
    return ", ".join(path[len(prefix):] if cwd and path.startswith(prefix) else path for path in paths)


def _show(result):
    item = result["item"]
    if item["kind"] == "task":
        lines = [f"Task #{item['native_id']} · {item['harness']}@{item['host']} · {item['task_state'] or '-'} · {item['status']}",
                 f"Title: {item['title']}", f"Directory: {item['cwd'] or '-'}", item["url"]]
        worker = item.get("worker")
        lines += [f"Worker session: {worker['id']} ({worker['state']})"] if worker else []
        lines += _progress(item)
        return lines + [f"Inspect: ctx task show {item['native_id']}" + (f" · ctx show {worker['id']} · ctx read {worker['id']}" if worker else "")]
    checkout = f" ({item['branch']} @ {item['head']})" if item.get("branch") else ""
    running = item["state"] == "running"
    turn = f"{_clock(item['prompt_at'])} → " + (f"running {_span(time.time() - (item['prompt_at'] or time.time()))}" if running else _clock(item["stop_at"]))
    turn += f" ({_span(item['duration'])})" if item.get("duration") else ""
    lines = [f"Session {item['id']} · {item['harness']}@{item['host']} ({item['surface'] or '-'}) · {item['status']} · project {item['project']}",
             f"Title: {item['title']}", f"Directory: {item['cwd'] or '-'}{checkout}",
             f"Native: {item['harness']} {item['native_id']} on {item['host']}", f"Turn: {turn} · times {ZONE}"]
    if result.get("brief"):
        return lines + [f"Inspect: ctx show {item['id']} · ctx read {item['id']}"]
    if item["waiting"] or item["question"]:
        lines += ["", "Waits on you:", item["waiting"] or item["question"]]
    if item["prompt"]:
        lines += ["", "Last prompt:", _excerpt(item["prompt"], 600)]
    if item["reply"]:
        lines += ["", "Last reply" + (" (previous turn)" if item["state"] == "running" else "") + ":", _excerpt(item["reply"], 1500)]
    if item.get("subagents"):
        lines += ["", f"Subagents ({len(item['subagents'])}, newest first; ctx show ID for one):",
                  *[f"  {child['id']} {child['state']} {child['title'] or '-'}" + (f" | {child['reply']}" if child["reply"] else "")
                    for child in item["subagents"]]]
    if item["files"]:
        lines += ["", f"Files changed in this session ({len(item['files'])}, relative to its directory): " + _paths(item["files"], item["cwd"])]
    if item["commits"]:
        lines += ["Commits: " + "; ".join(f"{commit['sha']} {commit['subject']}" for commit in item["commits"])]
    lines += _progress(item)
    lines += ["", f"next: ctx read {item['id']} (turns; ID@TURN, --full, --raw) · ctx task create --continues {item['id']} --title T --body-file -"]
    return lines


def _progress(item):
    """The live turn block of a session, or of a running task's worker session."""
    lines, progress = [], item.get("progress")
    if progress:
        source = "This turn so far" if item["kind"] == "task" or item["state"] == "running" else "Last turn, read from its transcript"
        lines += ["", f"{source} (live from {item['host']}):"]
        if progress.get("status") != "complete":
            lines.append("  unavailable: " + progress.get("reason", ""))
        else:
            if progress["messages"]:
                lines += ["  latest message:", _excerpt(progress["messages"][-1], 1200)]
            lines += ["  recent actions:", *[f"    {action}" for action in progress["actions"]]] if progress["actions"] else []
            lines += ["  files: " + _paths(progress["files"], item["cwd"])] if progress["files"] else []
            lines += ["  commits: " + "; ".join(f"{commit['sha']} {commit['subject']}" for commit in progress["commits"])] if progress["commits"] else []
    return lines


def render(args, result, host):
    if args.command == "handoff":
        if args.handoff_command == "files" and result.get("status") == "complete":
            return [f"{result['workspace']} · {result['policy']} · {len(result['files'])} extra/control files · {result['bytes']} bytes",
                    *[item["path"] for item in result["files"]]]
        return _transfer(result)
    if args.command == "project-data" and args.project_data_command == "audit" and "registry_count" in result:
        return [(f"registry={result['registry_count']} accounted={result['accounted_count']} "
                f"coverage_complete={result['coverage_complete']} pending={len(result['pending'])} "
                f"bindings={result['binding_count']} publication=not_checked"),
                *[f"{row['project']} · {row['disposition']} · {row['reason']}" for row in result["projects"]]]
    if result.get("status") == "not_ready":
        return ["not_ready: " + result.get("reason", "")]
    if args.command == "project-data":
        if args.project_data_command == "publish-ready":
            return [f"{result['status']} · published={len(result.get('published', []))} "
                    f"skipped={len(result.get('skipped', []))} failed={len(result.get('failed', []))}",
                    *[f"{row.get('id', row.get('ticket', ''))}: {row.get('reason', row.get('revision', ''))}"
                      for key in ('published', 'skipped', 'failed') for row in result.get(key, [])]]
        fields = [result.get("data_status") or result["status"]]
        if result.get("managed") is False:
            fields.append("unmanaged")
        fields += [f"{key}={result[key]}" for key in ("project", "id", "revision", "workspace") if result.get(key)]
        return [" ".join(fields)]
    if args.command == "data":
        return _data(args, result)
    if args.command == "find":
        return _found(result)
    if args.command == "read":
        return _read(result, args.full)
    if args.command == "ls":
        return {"sessions": _sessions, "handoffs": _handoffs}.get(args.kind, lambda value: _projects(value, host))(result)
    if args.command == "status":
        return _status(result)
    if args.command == "sync":
        return _sync(result)
    if args.command == "task":
        if args.task_command == "ls":
            return [f"#{item['number']} {item['updated'][:16].replace('T', ' ')} {','.join(item['labels'])} | {item['title']}"
                    for item in result["tasks"]] or ["no open tasks"]
        if args.task_command == "show":
            return [f"#{result['number']} {result['state'].lower()} {','.join(result['labels'])} | {result['title']}",
                    result["url"], "", result["result"] or "no result yet"]
        if args.task_command == "create" and args.dry_run:
            return [f"would open on {result['machine']}: {result['directory']}", *([result["body"]] if result.get("body") else [])]
        if args.task_command == "create":
            return [f"#{result['number']} {result['machine']} {result['url']}"]
        if args.task_command == "retry":
            return [f"#{result['number']} queued again on {result['machine']}"]
        if args.task_command == 'cloud-attach':
            return [f"#{result['number']} attached {result['cloud_task']['url']}", 'M1 supervision: ' + result['resume']]
        return [result["status"]]
    if args.command == "ps":
        return _ps(result)
    if args.command == "show":
        return _show({**result, "brief": args.brief})
    if args.command == "inbox" and args.action == "ls":
        return _inbox(result)
    if args.command == "places" and args.check:
        return [("known " if result["known"] else "not a known place ") + result["path"]]
    if args.command == "places" and not args.publish:
        hosts = result["hosts"] if "hosts" in result else {result["host"]: result}
        return [f"{host} {place['last'][:10] or '-'} {place['path']} {place['project_id'] or '-'}"
                for host, value in hosts.items() for place in value.get("places", [])]
    return [json.dumps(result, ensure_ascii=False)]


def main(argv=None):
    args = parser().parse_args(argv)
    ctx = None
    try:
        ctx = Context(Config(state=args.state_dir, host=args.host, native_home=args.native_home, registry_owner=args.registry_owner))
        result = dispatch(ctx, args)
    except subprocess.TimeoutExpired:
        result = {"status": "not_ready", "source_safe_to_close": False, "reason": "context operation exceeded its deadline; no confirmed close signal"}
    except subprocess.CalledProcessError as error:
        result = {"status": "not_ready", "source_safe_to_close": False, "reason": f"{' '.join(error.cmd[:3])} failed: {(error.stderr or '').strip()[-300:]}"}
    except (RuntimeError, ValueError, OSError, LookupError) as error:
        result = {"status": "not_ready", "source_safe_to_close": False, "reason": str(error)}
    if getattr(args, "json", False):
        print(json.dumps(result, ensure_ascii=False))
    else:
        print("\n".join(render(args, result, ctx.config.host if ctx else "")))
    return 0 if result.get("status", "complete") in SUCCESS else 2


if __name__ == "__main__":
    raise SystemExit(main())
