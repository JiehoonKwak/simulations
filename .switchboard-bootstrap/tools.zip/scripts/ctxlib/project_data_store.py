"""Private filesystem checkpoint publisher, also executable on NAS Python 3.8.

JSON requests use stdin/stdout over an authenticated SSH session, without a daemon.
"""
from __future__ import annotations

import fcntl
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import sys
import tempfile


def component(value):
    if not isinstance(value, str) or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,127}', value):
        raise ValueError('invalid identifier')
    return value


def safe_path(value):
    if not isinstance(value, str):
        raise ValueError('unsafe relative data path')
    path = PurePosixPath(value)
    if not value or value == '.' or path.is_absolute() or '..' in path.parts or value != path.as_posix():
        raise ValueError('unsafe relative data path')
    return path


def encoded(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(',', ':')).encode()


def sha(path):
    result = hashlib.sha256()
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(8 * 1024 * 1024), b''):
            result.update(block)
    return result.hexdigest()


def sync_directory(path):
    descriptor = os.open(str(path), os.O_RDONLY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def write_json(path, value):
    descriptor, temp = tempfile.mkstemp(dir=path.parent, prefix='.ref-')
    try:
        with os.fdopen(descriptor, 'wb') as handle:
            handle.write(encoded(value) + b'\n')
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(temp, 0o600)
        os.replace(temp, path)
        sync_directory(path.parent)
    finally:
        if os.path.exists(temp):
            os.unlink(temp)


def check_files(payload, manifest, *, reused=()):
    expected = manifest['files']
    actual = set()
    for folder, directories, files in os.walk(payload, followlinks=False):
        for name in directories + files:
            if (Path(folder) / name).is_symlink():
                raise ValueError('symlinks are not permitted in checkpoints')
        actual.update((Path(folder) / name).relative_to(payload).as_posix() for name in files)
    if actual != set(expected):
        raise ValueError('checkpoint file set differs from manifest')
    for name, entry in expected.items():
        safe_path(name)
        path = payload / name
        if path.stat().st_size != entry['size'] or (name not in reused and sha(path) != entry['sha256']):
            raise ValueError('checkpoint checksum mismatch: ' + name)


def dispatch(root, request, *, authorize=None):
    root = Path(root)
    if not root.is_absolute():
        raise ValueError('store root must be absolute')
    project = root / 'projects' / component(request['project'])
    for directory in ('refs', 'checkpoints', 'staging'):
        (project / directory).mkdir(parents=True, exist_ok=True, mode=0o700)
    reference = project / 'refs/current.json'
    current = json.loads(reference.read_text()) if reference.exists() else None
    action = request['action']
    if action == 'inspect':
        revision = request.get('revision') or (current or {}).get('revision')
        if not revision:
            return {'status': 'complete', 'revision': None, 'manifest': None}
        revision = component(revision)
        manifest = json.loads((project / 'checkpoints' / revision / 'manifest.json').read_text())
        if hashlib.sha256(encoded(manifest)).hexdigest() != revision:
            raise ValueError('published manifest identity mismatch')
        return {'status': 'complete', 'revision': revision, 'manifest': manifest,
                'payload': str(project / 'checkpoints' / revision / 'payload')}
    if action == 'stage':
        stage = project / 'staging' / component(request['id'])
        resumed = stage.exists()
        stage.mkdir(mode=0o700, exist_ok=True)
        (stage / 'payload').mkdir(mode=0o700, exist_ok=True)
        return {'status': 'complete', 'stage': str(stage), 'resumed': resumed}
    if action != 'publish':
        raise ValueError('unknown store action')
    revision = component(request['revision'])
    stage = project / 'staging' / component(request['id'])
    with (project / '.publish.lock').open('a') as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
        current = json.loads(reference.read_text()) if reference.exists() else None
        if authorize is not None:
            authorize()
        if current and current['revision'] == revision:
            return {'status': 'complete', 'revision': revision, 'idempotent': True}
        if (current or {}).get('revision') != request.get('base'):
            return {'status': 'conflict', 'revision': (current or {}).get('revision'),
                    'reason': 'current revision changed; staged candidate retained'}
        destination = project / 'checkpoints' / revision
        candidate = destination if destination.exists() else stage
        manifest = json.loads((candidate / 'manifest.json').read_text())
        if manifest['project'] != request['project'] or hashlib.sha256(encoded(manifest)).hexdigest() != revision:
            raise ValueError('candidate manifest identity mismatch')
        check_files(candidate / 'payload', manifest)
        for folder, _, files in os.walk(candidate, topdown=False):
            for name in files:
                with (Path(folder) / name).open('rb') as handle:
                    os.fsync(handle.fileno())
            sync_directory(folder)
        if candidate == stage:
            os.rename(stage, destination)
        sync_directory(destination.parent)
        sync_directory(stage.parent)
        sync_directory(project)
        sync_directory(project.parent)
        sync_directory(root)
        if authorize is not None:
            authorize()
        write_json(reference, {'revision': revision})
        return {'status': 'complete', 'revision': revision, 'idempotent': False}


if __name__ == '__main__':
    os.umask(0o077)
    try:
        result = dispatch(sys.argv[1], json.load(sys.stdin))
    except (ValueError, OSError, KeyError) as error:
        result = {'status': 'not_ready', 'reason': str(error)}
    print(json.dumps(result, ensure_ascii=False))
    sys.exit(0 if result['status'] == 'complete' else 1)
