"""Show a continued native session in a Herdr tab so the user can watch it work."""

from __future__ import annotations

import json
import shlex
import shutil
import subprocess
import time
from pathlib import Path

def _binary() -> str | None:
    """SSH and LaunchAgent shells may lack ~/.local/bin, where Herdr installs itself."""
    fallback = Path.home() / ".local/bin/herdr"
    return shutil.which("herdr") or (str(fallback) if fallback.is_file() else None)


def _call(*args: str) -> dict:
    binary = _binary()
    if not binary:
        raise RuntimeError("Herdr is not installed")
    result = subprocess.run([binary, *args], capture_output=True, text=True, timeout=15)
    if result.returncode:
        raise RuntimeError((result.stderr or result.stdout).strip()[-200:] or "herdr failed")
    return json.loads(result.stdout)["result"] if result.stdout.strip() else {}


def _running(binary: str) -> bool:
    result = subprocess.run([binary, "status", "server"], capture_output=True, text=True, timeout=10)
    return "status: running" in result.stdout


def _ensure_server(binary: str) -> None:
    """Start the headless server when none runs (for example after a reboot) so sessions stay observable."""
    if _running(binary):
        return
    subprocess.Popen([binary, "server"], stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                     stderr=subprocess.DEVNULL, start_new_session=True)
    deadline = time.monotonic() + 10
    while time.monotonic() < deadline:
        time.sleep(0.5)
        if _running(binary):
            return
    raise RuntimeError("herdr server did not start")


def show(command: list[str], cwd, label: str, workspace: str) -> dict:
    """Open `command` in a new tab of the Herdr workspace named after the project; Herdr problems never fail the launch."""
    binary = _binary()
    if not binary:
        return {"status": "skipped", "reason": "herdr not installed"}
    try:
        _ensure_server(binary)
        workspaces = _call("workspace", "list")["workspaces"]
        existing = next((item for item in workspaces if item.get("label") == workspace), None)
        if existing:
            pane = _call("tab", "create", "--workspace", existing["workspace_id"], "--cwd", str(cwd), "--label", label)["root_pane"]
        else:
            created = _call("workspace", "create", "--cwd", str(cwd), "--label", workspace)
            pane = created["root_pane"]
            _call("tab", "rename", created["tab"]["tab_id"], label)
        _call("pane", "run", pane["pane_id"], shlex.join(command))
        return {"status": "shown", "pane": pane["pane_id"]}
    except (OSError, ValueError, KeyError, RuntimeError, subprocess.TimeoutExpired) as error:
        return {"status": "skipped", "reason": str(error)[:200]}


def _same_folder(left: str, right: str) -> bool:
    """Codex can execute in a linked worktree while its TUI stays in the original checkout."""
    paths = [Path(value).expanduser().resolve() for value in (left, right)]
    if paths[0] == paths[1]:
        return True
    folders = []
    for path in paths:
        try:
            result = subprocess.run(
                ["git", "-C", str(path), "rev-parse", "--path-format=absolute", "--show-toplevel", "--git-common-dir"],
                capture_output=True, text=True, timeout=2,
            )
            if result.returncode:
                return False
            root, common = result.stdout.splitlines()
            folders.append((Path(common).resolve(), path.relative_to(Path(root).resolve())))
        except (OSError, ValueError, subprocess.TimeoutExpired):
            return False
    return folders[0] == folders[1]


def find_session(harness: str, native_id: str, title: str, cwd: str) -> str:
    """Resolve a live occupant, never trust pane IDs inherited by a shared app-server."""
    agents = _call("agent", "list")["agents"]
    exact = [a for a in agents if a.get("agent") == harness
             and a.get("agent_session", {}).get("kind") == "id"
             and a["agent_session"].get("value") == native_id]
    if len(exact) == 1:
        return exact[0]["pane_id"]
    if exact:
        raise LookupError("More than one Herdr pane has this session")
    matches = []
    for agent in agents:
        if harness != "codex" or agent.get("agent") != harness or agent.get("agent_session"):
            continue
        live_cwd = agent.get("foreground_cwd") or agent.get("cwd", "")
        live_title = agent.get("terminal_title_stripped", "").lstrip(" ⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏")
        expected = f"{title} | {Path(live_cwd).name}"
        if title and cwd and live_cwd and live_title in {title, expected} and _same_folder(live_cwd, cwd):
            matches.append(agent["pane_id"])
    if len(matches) != 1:
        raise LookupError("No unique live Herdr pane matches this session")
    return matches[0]
