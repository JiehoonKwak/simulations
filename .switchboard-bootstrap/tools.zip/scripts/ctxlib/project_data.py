"""Opt-in project data: pinned cache, durable task workspaces and NAS checkpoints."""
from __future__ import annotations

import fcntl
import fnmatch
import hashlib
import json
import os
import shlex
import shutil
import sqlite3
import subprocess
import sys
import tempfile
from contextlib import contextmanager
from pathlib import Path

from . import project_data_cloud, secrets_scan
from . import project_data_store as store
from .core import (
    NotReady,
    atomic_json,
    canonical,
    component,
    digest_file,
    host_alias,
    primary_checkout,
    run_git,
)

SOURCE_ROOT = Path(__file__).resolve().parents[2]
DEFAULT_STORE = '/volume1/homes/jiehoonk/project-data'


def manages(config, path):
    name = Path(path).as_posix()
    return any(name == p or name.startswith(p.rstrip('/') + '/') for p in config['paths']) and not any(
        fnmatch.fnmatchcase(name, pattern) for pattern in config.get('exclude', []))


def validate(config):
    component(config['project'])
    if not isinstance(config.get('paths'), list) or not config['paths']:
        raise NotReady('project data config requires selected relative paths')
    for path in config['paths']:
        store.safe_path(path)
        if any(p in {'.git', '.env', '.ssh', '.codex', '.claude', '.venv', 'node_modules'} for p in Path(path).parts):
            raise NotReady('runtime/credential path is not a dataset')
    allow = config.get('secret_scan_allow', [])
    if not isinstance(allow, list) or not all(isinstance(pattern, str) and pattern for pattern in allow):
        raise NotReady('secret_scan_allow must be a list of relative path globs')
    return config


def require_clean_payload(payload, manifest, config, *, guidance, names=None):
    """Refuse publication while the frozen payload holds a credential.

    The scan reads the frozen copy that is uploaded, and each scanned file must still match its
    manifest digest, so a clean result belongs to that candidate revision. Only paths and
    credential kinds are reported, never values. `secret_scan_allow` globs in the binding
    exempt reviewed false positives."""
    allow = config.get('secret_scan_allow', [])
    findings, changed = {}, []
    for name, entry in sorted(manifest['files'].items()):
        if names is not None and name not in names:
            continue
        if secrets_scan.allowed(name, allow):
            continue
        try:
            data = secrets_scan.readable(Path(payload) / name)
        except FileNotFoundError:
            changed.append(name)
            continue
        if data is None:
            continue
        if hashlib.sha256(data).hexdigest() != entry['sha256']:
            changed.append(name)
        elif found := secrets_scan.kinds_in(data):
            findings[name] = found
    if changed:
        raise NotReady('frozen payload no longer matches its manifest; nothing was published: ' + ', '.join(changed))
    if findings:
        listing = '; '.join(f"{name} ({', '.join(kinds)})" for name, kinds in findings.items())
        raise NotReady(f'credential-like values in project data; nothing was published. {guidance} For a reviewed '
                       'false positive, add its path glob to the binding\'s secret_scan_allow and prepare a new ticket. '
                       'Found: ' + listing)


def binding(ctx, root):
    root = Path(root).resolve()
    try:
        root = Path(run_git(root, 'rev-parse', '--show-toplevel').decode().strip())
    except NotReady:
        pass
    selected_project = os.environ.get('CTX_PROJECT_DATA_PROJECT')
    if selected_project:
        component(selected_project)
    direct = root / '.ctxdata.json'
    if direct.exists():
        config = validate(json.loads(direct.read_text()))
        if selected_project and selected_project != config['project']:
            raise NotReady('explicit project data identity differs from repository binding')
        return config
    shared = Path(os.environ.get('CTX_PROJECT_DATA_BINDINGS', SOURCE_ROOT / 'config/project-data.json'))
    if not shared.exists():
        if selected_project:
            raise NotReady('explicit project data identity has no shared binding')
        return None
    bindings = json.loads(shared.read_text()).get('projects', [])
    if selected_project:
        matches = [config for config in bindings if config['project'] == selected_project]
        if len(matches) != 1:
            raise NotReady('explicit project data identity requires exactly one shared binding')
        return validate(matches[0])
    try:
        project_id = ctx.project(cwd=root, cached=True)['id']
    except NotReady:
        main = primary_checkout(root)
        project_id = None
        if main is not None:
            try:
                project_id = ctx.project(cwd=main, cached=True)['id']
            except NotReady:
                pass
        if project_id is None:
            project_id = project_data_cloud.resolve_repository(root)
        if project_id is None:
            return None
    matches = [config for config in bindings if config['project'] == project_id]
    return validate(matches[0]) if matches else None


def settings(ctx):
    explicit = os.environ.get('CTX_PROJECT_DATA_SETTINGS')
    cloud = project_data_cloud.cloudsettings(ctx)
    if explicit is None and cloud is not None:
        return cloud
    path = Path(explicit) if explicit is not None else Path.home() / '.config/ctx/project-data.json'
    if explicit is not None and not path.is_file():
        raise NotReady('explicit project data settings are missing; no remote fallback was used')
    try:
        value = json.loads(path.read_text()) if path.exists() else {}
    except (OSError, ValueError) as error:
        raise NotReady('project data settings are unreadable or invalid; no remote fallback was used') from error
    if cloud is not None:
        if (not isinstance(value, dict) or value.get('endpoint') != cloud['endpoint']
                or value.get('auth') != cloud['auth']
                or value.get('provider', cloud['provider']) != cloud['provider']
                or value.get('use_sessions') is not True
                or value.get('token_env') != cloud.get('token_env')
                or value.get('token_file') or value.get('local', False)):
            raise NotReady('explicit data settings conflict with the active Cloud profile; no remote fallback was used')
        return {**cloud, **value}
    value.setdefault('host', 'nas')
    value.setdefault('root', DEFAULT_STORE)
    value.setdefault('local', False)
    value.setdefault('tasks', str(ctx.config.state / 'project-data/tasks'))
    value.setdefault('cache', str(ctx.config.state / 'project-data/cache'))
    return value


def command(ctx, request):
    config = settings(ctx)
    try:
        if config.get('endpoint'):
            from .project_data_http import Client
            value = Client(config).command(request)
        elif config['local']:
            value = store.dispatch(config['root'], request)
        else:
            source = Path(store.__file__).read_text()
            remote = 'python3 -c ' + shlex.quote(source) + ' ' + shlex.quote(config['root'])
            result = subprocess.run(['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=10',
                                     config['host'], remote], input=canonical(request),
                                    capture_output=True, timeout=7200)
            try:
                value = json.loads(result.stdout)
            except ValueError as error:
                raise NotReady('NAS store did not answer: ' + result.stderr.decode(errors='replace')[-500:]) from error
        if value['status'] != 'complete':
            raise NotReady(value.get('reason', value['status']))
        return value
    except (ValueError, OSError, KeyError, subprocess.TimeoutExpired) as error:
        raise NotReady(str(error)) from error


def transfer(ctx, source, target, *, upload=False, link_dest=None, checksum=False, names=None):
    config = settings(ctx)
    source, target = str(source), str(target)
    if names is not None:
        for name in names:
            store.safe_path(name)
    if config.get('endpoint'):
        from .project_data_http import Client
        try:
            Client(config).transfer(source, target, upload=upload, names=names)
        except (ValueError, OSError, KeyError) as error:
            raise NotReady(str(error)) from error
        return
    if config['local']:
        if names is None:
            shutil.copytree(source, target, dirs_exist_ok=True)
        else:
            for name in names:
                destination = Path(target) / name
                destination.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
                shutil.copy2(Path(source) / name, destination)
        return
    if names == []:
        return
    remote = config['host'] + ':'
    executable = '/opt/homebrew/bin/rsync' if Path('/opt/homebrew/bin/rsync').exists() else 'rsync'
    args = [executable, '-rt', '-s', '--partial', '--chmod=Du=rwx,Dgo=,Fu=rw,Fgo=',
            '-e', 'ssh -o BatchMode=yes -o ConnectTimeout=10']
    if link_dest:
        args.append('--link-dest=' + str(link_dest))
    if checksum:
        args.append('--checksum')
    args += [source if upload else remote + source, remote + target if upload else target]
    if names is None:
        result = subprocess.run(args, capture_output=True, timeout=24 * 3600)
    else:
        with tempfile.NamedTemporaryFile() as selection:
            selection.write(b'\0'.join(name.encode() for name in names) + b'\0')
            selection.flush()
            selected_args = args[:-2] + ['--files-from=' + selection.name, '--from0'] + args[-2:]
            result = subprocess.run(selected_args,
                                    capture_output=True, timeout=24 * 3600)
    if result.returncode:
        raise NotReady('data transfer failed; outputs retained: ' + result.stderr.decode(errors='replace')[-500:])


def files(root, config):
    root = Path(root).resolve()
    try:
        tracked = set(run_git(root, 'ls-files', '-z').decode().split('\0'))
    except NotReady:
        tracked = set()
    selected = set()
    for name in config['paths']:
        path = root / name
        if not path.exists():
            continue
        candidates = [path] if path.is_file() else path.rglob('*')
        for candidate in candidates:
            relative = candidate.relative_to(root).as_posix()
            if not manages(config, relative):
                continue
            if candidate.is_symlink() or candidate.resolve() != candidate.absolute():
                raise NotReady('symlink in selected data: ' + relative)
            if candidate.is_file() and relative not in tracked and not sqlite_auxiliary(candidate):
                selected.add(relative)
    return sorted(selected)


def copy_file(source, destination):
    if sys.platform == 'darwin':
        cloned = subprocess.run(['/bin/cp', '-c', '-p', str(source), str(destination)], capture_output=True)
        if cloned.returncode == 0:
            return
    elif sys.platform == 'linux':
        executable = shutil.which('cp')
        if executable:
            cloned = subprocess.run([executable, '--reflink=auto', '--preserve=timestamps', str(source), str(destination)], capture_output=True)
            if cloned.returncode == 0:
                return
    shutil.copy2(source, destination)


def snapshot(source, destination, names):
    destination = Path(destination)
    destination.mkdir(parents=True, exist_ok=True, mode=0o700)
    for name in names:
        src, dst = Path(source) / name, destination / name
        dst.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        with src.open('rb') as handle:
            is_sqlite = handle.read(16) == b'SQLite format 3\0'
        if is_sqlite:
            origin = sqlite3.connect(src.resolve().as_uri() + '?mode=ro', uri=True, timeout=30)
            copy = sqlite3.connect(dst)
            try:
                origin.backup(copy)
                copy.execute('PRAGMA journal_mode=DELETE')
                if copy.execute('PRAGMA quick_check').fetchone()[0] != 'ok':
                    raise NotReady('SQLite snapshot failed integrity check: ' + name)
            finally:
                copy.close()
                origin.close()
        else:
            before = src.stat()
            copy_file(src, dst)
            after = src.stat()
            if (before.st_size, before.st_mtime_ns, before.st_ino) != (after.st_size, after.st_mtime_ns, after.st_ino):
                raise NotReady('source changed while freezing: ' + name)
        os.chmod(dst, 0o600)


def file_manifest(root):
    entries = {}
    for path in sorted(Path(root).rglob('*')):
        if path.is_symlink():
            raise NotReady('symlink in task data')
        if path.is_file():
            entry = {'size': path.stat().st_size, 'sha256': digest_file(path)}
            with path.open('rb') as handle:
                is_sqlite = handle.read(16) == b'SQLite format 3\0'
            if is_sqlite:
                entry['sqlite_sha256'] = sqlite_digest(path)
            entries[path.relative_to(root).as_posix()] = entry
    return entries


def sqlite_digest(path):
    database = sqlite3.connect(Path(path).resolve().as_uri() + '?mode=ro', uri=True)
    result = hashlib.sha256()
    try:
        for statement in database.iterdump():
            result.update(statement.encode())
            result.update(b'\n')
    finally:
        database.close()
    return result.hexdigest()


def content_identity(manifest):
    return {name: entry.get('sqlite_sha256', entry['sha256']) for name, entry in manifest['files'].items()}


def cache_fingerprints(payload):
    fingerprints = {}
    for name in data_names(payload):
        stat = (Path(payload) / name).stat()
        fingerprints[name] = [stat.st_size, stat.st_mtime_ns, stat.st_ctime_ns]
    return fingerprints


def data_names(root):
    root = Path(root)
    names = []
    for path in root.rglob('*'):
        if path.is_symlink():
            raise NotReady('symlink in task data')
        if not path.is_file():
            continue
        if sqlite_auxiliary(path):
            continue
        names.append(path.relative_to(root).as_posix())
    return sorted(names)


def sqlite_auxiliary(path):
    for suffix in ('-wal', '-shm', '-journal'):
        if path.name.endswith(suffix):
            database = path.with_name(path.name[:-len(suffix)])
            if database.is_file():
                with database.open('rb') as handle:
                    return handle.read(16) == b'SQLite format 3\0'
    return False


def save_ticket(ctx, ticket):
    atomic_json(Path(settings(ctx)['tasks']) / ticket['id'] / 'ticket.json', ticket)
    return ticket


def load_ticket(ctx, identifier):
    component(identifier)
    try:
        return json.loads((Path(settings(ctx)['tasks']) / identifier / 'ticket.json').read_text())
    except OSError as error:
        raise NotReady('data ticket not found: ' + identifier) from error


@contextmanager
def locked_directory(directory):
    directory.mkdir(parents=True, exist_ok=True, mode=0o700)
    with (directory / '.prepare.lock').open('a') as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
        try:
            yield
        finally:
            fcntl.flock(lock.fileno(), fcntl.LOCK_UN)


def reuse_cached_files(cache, manifest):
    reused = set()
    payload = cache / 'payload'
    payload.mkdir(parents=True, exist_ok=True, mode=0o700)
    for previous in sorted(cache.parent.iterdir()):
        marker = previous / 'manifest.json'
        fingerprints = previous / 'verified.json'
        if previous == cache or previous.is_symlink() or not marker.exists() or not fingerprints.exists():
            continue
        with locked_directory(previous):
            try:
                old_manifest = json.loads(marker.read_text())
                old_fingerprints = json.loads(fingerprints.read_text())
                if hashlib.sha256(canonical(old_manifest)).hexdigest() != previous.name:
                    continue
                if old_fingerprints != cache_fingerprints(previous / 'payload'):
                    continue
            except (ValueError, OSError, NotReady):
                continue
            for name, entry in manifest['files'].items():
                old_entry = old_manifest['files'].get(name)
                if name in reused or old_entry is None:
                    continue
                if (entry['size'], entry['sha256']) != (old_entry['size'], old_entry['sha256']):
                    continue
                source = previous / 'payload' / name
                destination = payload / name
                destination.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
                if destination.exists():
                    destination.unlink()
                copy_file(source, destination)
                stat = source.stat()
                if old_fingerprints[name] != [stat.st_size, stat.st_mtime_ns, stat.st_ctime_ns]:
                    raise NotReady('verified input cache changed during reuse')
                reused.add(name)
        if reused == set(manifest['files']):
            break
    return reused


def reuse_selected_files(cache, manifest, selected_paths):
    """Reuse only the same selection from immutable, completed revision caches."""
    reused = set()
    for revision in sorted(cache.parent.parent.iterdir()):
        previous = revision / cache.name
        if revision.is_symlink() or previous == cache or previous.is_symlink():
            continue
        try:
            baseline = json.loads((previous / 'manifest.json').read_text())
            fingerprints = json.loads((previous / 'verified.json').read_text())
            expected = {name for name in baseline['files'] if in_selection(name, selected_paths)}
            if (hashlib.sha256(canonical(baseline)).hexdigest() != revision.name
                    or set(fingerprints) != expected
                    or fingerprints != cache_fingerprints(previous / 'payload')):
                continue
        except (OSError, ValueError, KeyError, TypeError, NotReady):
            continue
        for name, entry in manifest['files'].items():
            old = baseline['files'].get(name)
            if name in reused or name not in expected or old is None:
                continue
            if (entry['size'], entry['sha256']) != (old['size'], old['sha256']):
                continue
            source, destination = previous / 'payload' / name, cache / 'payload' / name
            destination.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
            if destination.exists():
                destination.unlink()
            copy_file(source, destination)
            stat = source.stat()
            if fingerprints[name] != [stat.st_size, stat.st_mtime_ns, stat.st_ctime_ns]:
                raise NotReady('verified selected cache changed during reuse')
            reused.add(name)
        if reused == set(manifest['files']):
            break
    return reused


def selection_paths(config, selected_paths, root=None):
    if selected_paths is None:
        return None
    if not isinstance(selected_paths, list) or not selected_paths:
        raise NotReady('data selection requires a nonempty list of relative paths')
    selected = set()
    for name in selected_paths:
        try:
            store.safe_path(name)
        except ValueError as error:
            raise NotReady(str(error)) from error
        if not manages(config, name):
            raise NotReady('selected path is outside managed data paths: ' + name)
        if any(part in {'.git', '.env', '.ssh', '.codex', '.claude', '.venv', 'node_modules'}
               for part in Path(name).parts):
            raise NotReady('runtime/credential path is not a dataset')
        if root is not None:
            path = Path(root).resolve() / name
            if path.is_symlink() or path.resolve() != path.absolute():
                raise NotReady('symlink in selected data: ' + name)
        selected.add(name)
    return sorted(name for name in selected if not any(
        name.startswith(other + '/') for other in selected if other != name))


def in_selection(name, selected_paths):
    return any(name == path or name.startswith(path + '/') for path in selected_paths)


def partial_baseline(ticket):
    selection = selection_paths(ticket['config'], ticket['selected_paths'])
    baseline = ticket.get('baseline_manifest')
    if (not baseline or baseline.get('project') != ticket['project']
            or hashlib.sha256(canonical(baseline)).hexdigest() != ticket['base']):
        raise NotReady('partial task baseline manifest identity mismatch')
    expected = sorted(name for name in baseline['files'] if in_selection(name, selection))
    if ticket.get('materialized_files') != expected:
        raise NotReady('partial task materialized file selection changed')
    return baseline, selection


def hydrate_cache(ctx, config, current, selected_paths=None):
    cache = Path(settings(ctx)['cache']) / config['project'] / current['revision']
    manifest = current['manifest']
    if selected_paths is not None:
        if hashlib.sha256(canonical(manifest)).hexdigest() != current['revision']:
            raise NotReady('published manifest identity mismatch')
        selection_hash = hashlib.sha256(canonical(selected_paths)).hexdigest()
        cache = cache.parent / '.selected' / current['revision'] / selection_hash
        manifest = {**manifest, 'files': {name: entry for name, entry in manifest['files'].items()
                                        if in_selection(name, selected_paths)}}
    with locked_directory(cache):
        marker = cache / 'manifest.json'
        fingerprints = cache / 'verified.json'
        payload = cache / 'payload'
        if not marker.exists():
            resumed = payload.exists()
            payload.mkdir(parents=True, exist_ok=True, mode=0o700)
            reused = (reuse_cached_files(cache, manifest) if selected_paths is None
                      else reuse_selected_files(cache, manifest, selected_paths))
            names = sorted(set(manifest['files']) - reused)
            transfer(ctx, current['payload'] + '/', str(payload) + '/', checksum=resumed, names=names)
            store.check_files(payload, manifest, reused=reused if selected_paths is None else ())
            for path in payload.rglob('*'):
                os.chmod(path, 0o500 if path.is_dir() else 0o400)
            atomic_json(fingerprints, cache_fingerprints(payload))
            atomic_json(marker, current['manifest'])
        elif (json.loads(marker.read_text()) != current['manifest']
              or not fingerprints.exists()
              or json.loads(fingerprints.read_text()) != cache_fingerprints(payload)):
            raise NotReady('verified input cache changed; restore it before preparing task data')
        elif selected_paths is not None:
            try:
                store.check_files(payload, manifest)
            except ValueError as error:
                raise NotReady('verified input cache changed: ' + str(error)) from error
        return payload


def prepare(ctx, root, task_id, pinned=None, selected_paths=None):
    config = binding(ctx, root)
    if config is None:
        if pinned:
            raise NotReady('receiver has no managed data binding')
        return None
    selection = selection_paths(config, selected_paths, root)
    identifier = component(task_id)
    directory = Path(settings(ctx)['tasks']) / identifier
    with locked_directory(directory):
        if (directory / 'ticket.json').exists():
            old = load_ticket(ctx, identifier)
            if (old['project'] != config['project'] or old.get('config') != config
                    or (pinned and old['revision'] != pinned['revision'])
                    or old.get('selected_paths') != selection):
                raise NotReady('task ID already belongs to different inputs')
            return old
        current = command(ctx, {'action': 'inspect', 'project': config['project'], 'revision': (pinned or {}).get('revision')})
        revision = current['revision']
        if revision is None:
            raise NotReady('project has no completed NAS checkpoint; import data first')
        payload = hydrate_cache(ctx, config, current, selection)
        workspace = directory / 'workspace'
        names = sorted(name for name in current['manifest']['files']
                       if selection is None or in_selection(name, selection))
        snapshot(payload, workspace, names)
        for path in workspace.rglob('*'):
            os.chmod(path, 0o700 if path.is_dir() else 0o600)
        partial = {} if selection is None else {'selected_paths': selection,
                                               'baseline_manifest': current['manifest'],
                                               'materialized_files': names}
        return save_ticket(ctx, {'id': identifier, 'project': config['project'], 'config': config,
                                'revision': revision, 'base': revision, 'workspace': str(workspace),
                                'root': str(Path(root).resolve()), 'frozen': False, 'status': 'prepared', **partial})


def code_provenance(root, identifier):
    try:
        commit = run_git(Path(root), 'rev-parse', 'HEAD').decode().strip()
    except NotReady:
        return {'commit': None, 'ref': None}
    ref = 'refs/heads/ctx-data/' + component(identifier)
    run_git(Path(root), 'update-ref', ref, commit)
    return {'commit': commit, 'ref': ref}


def repository_identity(root):
    root = Path(root).resolve()
    try:
        common = run_git(root, 'rev-parse', '--git-common-dir').decode().strip()
    except NotReady:
        return root
    return (root / common).resolve()


def validate_producing_root(ctx, ticket, root):
    if repository_identity(root) != repository_identity(ticket['root']):
        raise NotReady('computation repository differs from prepared task')
    if binding(ctx, root) != ticket['config']:
        raise NotReady('computation data binding differs from prepared task')


def persist_code_ref(ctx, ticket, root):
    if not ticket.get('source_commit'):
        return
    if 'origin' not in run_git(root, 'remote').decode().splitlines():
        if settings(ctx)['local']:
            return
        raise NotReady('producing code has no origin remote; outputs retained')
    ref = ticket['manifest']['provenance']['ref']
    run_git(root, 'push', 'origin', ref + ':' + ref)


def freeze(ctx, ticket, producing_root):
    if ticket.get('frozen'):
        return ticket
    if not ticket.get('initial'):
        validate_producing_root(ctx, ticket, producing_root)
    stage = Path(settings(ctx)['tasks']) / ticket['id'] / 'frozen'
    if stage.exists():
        raise NotReady('incomplete freeze retained; inspect or use a new ticket ID')
    if ticket.get('initial'):
        provenance = {'kind': 'initial-copy', 'commit': None, 'ref': None,
                      'source_host': ticket.get('source_host'), 'source_stats': ticket.get('source_stats')}
    else:
        provenance = code_provenance(producing_root, ticket['id'])
    if provenance['commit']:
        dirty = run_git(Path(producing_root), 'diff', '--name-only', '-z', 'HEAD').decode().split('\0')
        untracked = run_git(Path(producing_root), 'ls-files', '--others', '--exclude-standard', '-z').decode().split('\0')
        dirty_code = any(name and relevant(ticket['config'], name) for name in dirty)
        untracked_code = any(name and relevant(ticket['config'], name) and not manages(ticket['config'], name)
                             for name in untracked)
        if dirty_code or untracked_code:
            raise NotReady('uncommitted computation code; commit it before freezing data')
    workspace = Path(ticket['workspace'])
    names = data_names(workspace)
    if any(not manages(ticket['config'], name) for name in names):
        raise NotReady('task wrote outside its managed data paths')
    baseline, selection = partial_baseline(ticket) if 'selected_paths' in ticket else (None, None)
    if selection is not None and any(not in_selection(name, selection) for name in names):
        raise NotReady('task wrote outside its selected data paths')
    before = [(p, (workspace / p).stat().st_size, (workspace / p).stat().st_mtime_ns) for p in names]
    snapshot(workspace, stage / 'payload', names)
    after = [(name, (workspace / name).stat().st_size, (workspace / name).stat().st_mtime_ns)
             for name in data_names(workspace)]
    if sorted(before) != sorted(after):
        raise NotReady('task data changed during freeze; candidate retained')
    provenance['input_revision'] = ticket['revision']
    provenance['config_sha256'] = hashlib.sha256(canonical(ticket['config'])).hexdigest()
    manifest = {'schema_version': 1, 'project': ticket['project'], 'files': file_manifest(stage / 'payload'),
                'provenance': provenance}
    if baseline is not None:
        manifest['files'] = {**{name: entry for name, entry in baseline['files'].items()
                              if not in_selection(name, selection)}, **manifest['files']}
    try:
        require_clean_payload(stage / 'payload', manifest, ticket['config'], names=set(names),
                              guidance='The frozen copy was removed; remove the values from the task workspace and publish again.')
    except NotReady:
        shutil.rmtree(stage)
        raise
    atomic_json(stage / 'manifest.json', manifest)
    return save_ticket(ctx, {**ticket, 'frozen': True, 'stage': str(stage), 'manifest': manifest,
                            'candidate': hashlib.sha256(canonical(manifest)).hexdigest(),
                            'source_commit': manifest['provenance']['commit'], 'status': 'frozen'})


def relevant(config, name):
    if config.get('code_paths'):
        return any(fnmatch.fnmatchcase(name, p) for p in config['code_paths'])
    return Path(name).suffix.lower() in {'.py', '.r', '.ipynb', '.sh', '.js', '.ts', '.toml', '.yaml', '.yml', '.json'}


def publish(ctx, ticket, integrated_root=None):
    if ticket.get('status') == 'published':
        return {'status': 'complete', 'revision': ticket['candidate'], 'workspace': ticket['workspace']}
    if not ticket.get('frozen'):
        raise NotReady('freeze outputs before publishing')
    selected_files = None
    if 'selected_paths' in ticket:
        baseline, selection = partial_baseline(ticket)
        if not settings(ctx).get('endpoint'):
            raise NotReady('partial data publication requires HTTPS; frozen outputs retained')
        retained = {name: entry for name, entry in baseline['files'].items() if not in_selection(name, selection)}
        actual_retained = {name: entry for name, entry in ticket['manifest']['files'].items()
                           if not in_selection(name, selection)}
        if retained != actual_retained:
            raise NotReady('partial candidate changed unselected baseline files')
        selected_files = {name for name in ticket['manifest']['files'] if in_selection(name, selection)}
        try:
            store.check_files(Path(ticket['stage']) / 'payload',
                              {'files': {name: ticket['manifest']['files'][name] for name in selected_files}})
        except ValueError as error:
            raise NotReady('partial frozen payload changed: ' + str(error)) from error
    require_clean_payload(Path(ticket['stage']) / 'payload', ticket['manifest'], ticket['config'],
                          names=selected_files,
                          guidance='The frozen candidate is retained unchanged; remove the values from the task data and prepare a new ticket.')
    root = Path(integrated_root or ticket['root'])
    if not ticket.get('initial'):
        validate_producing_root(ctx, ticket, root)
    commit = ticket.get('source_commit')
    if commit:
        if run_git(root, 'rev-parse', ticket['manifest']['provenance']['ref']).decode().strip() != commit:
            raise NotReady('producing code ref changed')
        changes = run_git(root, 'diff', '--name-only', commit, 'HEAD').decode().splitlines()
        if any(relevant(ticket['config'], name) for name in changes):
            raise NotReady('computation code changed during integration; outputs retained for validation/rerun')
    persist_code_ref(ctx, ticket, root)
    current = command(ctx, {'action': 'inspect', 'project': ticket['project']})
    if ('selected_paths' in ticket and current['revision'] not in {ticket['base'], ticket['candidate']}):
        raise NotReady('current revision changed; partial candidate retained without upload; prepare a new task')
    if (current['manifest'] and content_identity(current['manifest']) == content_identity(ticket['manifest'])
            and current['manifest'].get('switchboard_result') == ticket['manifest'].get('switchboard_result')
            and current['revision'] == ticket['base']):
        save_ticket(ctx, {**ticket, 'candidate': current['revision'], 'status': 'published'})
        return {'status': 'complete', 'revision': current['revision'], 'unchanged': True, 'workspace': ticket['workspace']}
    if current['revision'] != ticket['candidate']:
        stage = command(ctx, {'action': 'stage', 'project': ticket['project'], 'id': ticket['id']})
        if not stage.get('publishing'):
            transfer(ctx, ticket['stage'] + '/', stage['stage'] + '/', upload=True,
                     link_dest=str(Path(current['payload']).parent) if current.get('payload') else None,
                     checksum=stage.get('resumed', False) or bool(current.get('payload')))
    receipt = command(ctx, {'action': 'publish', 'project': ticket['project'], 'id': ticket['id'],
                            'revision': ticket['candidate'], 'base': ticket['base']})
    save_ticket(ctx, {**ticket, 'status': 'published'})
    return {**receipt, 'workspace': ticket['workspace']}


def inventoried_files(root, config, names):
    try:
        tracked = set(run_git(root, 'ls-files', '-z').decode().split('\0'))
    except NotReady:
        tracked = set()
    selected = set()
    for name in names:
        store.safe_path(name)
        path = root / name
        if path.is_symlink() or path.resolve() != path.absolute():
            raise NotReady('symlink in selected data: ' + name)
        if not manages(config, name) or not path.is_file() or name in tracked or sqlite_auxiliary(path):
            raise NotReady('inventoried path is not selected untracked regular data: ' + name)
        selected.add(name)
    return sorted(selected)


def import_local(ctx, root, config, identifier, *, base=None, names=None):
    """Freeze selected existing data for initial copying, retaining all originals."""
    config = validate(config)
    identifier = component(identifier)
    root = Path(root).resolve()
    directory = Path(settings(ctx)['tasks']) / identifier
    with locked_directory(directory):
        if (directory / 'ticket.json').exists():
            return load_ticket(ctx, identifier)
        names = files(root, config) if names is None else inventoried_files(root, config, names)
        if not names:
            raise NotReady('no selected untracked dataset files')
        source_stats = {}
        for name in names:
            stat = (root / name).stat()
            source_stats[name] = {'size': stat.st_size, 'mtime_ns': stat.st_mtime_ns}
        workspace = directory / 'workspace'
        snapshot(root, workspace, names)
        ticket = save_ticket(ctx, {'id': identifier, 'project': config['project'], 'config': config,
                                  'revision': base, 'base': base, 'workspace': str(workspace),
                                  'root': str(root), 'initial': True, 'source_host': host_alias(),
                                  'source_stats': source_stats, 'frozen': False, 'status': 'prepared'})
        return freeze(ctx, ticket, root)


def status(ctx, root):
    config = binding(ctx, root)
    if config is None:
        return {'status': 'complete', 'managed': False}
    current = command(ctx, {'action': 'inspect', 'project': config['project']})
    return {'status': 'complete', 'managed': True, 'project': config['project'], 'revision': current['revision']}


def handoff_state(ctx, root, ticket=None):
    config = binding(ctx, root)
    if config is None:
        if ticket is not None:
            raise NotReady('data ticket requires a managed project binding')
        return None
    if ticket is not None:
        ticket = load_ticket(ctx, ticket if isinstance(ticket, str) else ticket['id'])
        if ticket['project'] != config['project'] or ticket['config'] != config:
            raise NotReady('managed data ticket identity/config does not match source')
        validate_producing_root(ctx, ticket, root)
        revision = ticket['candidate'] if ticket['status'] == 'published' else ticket['revision']
        current = command(ctx, {'action': 'inspect', 'project': config['project'], 'revision': revision})
        expected_manifest = current['manifest']
        if 'selected_paths' in ticket:
            selection = selection_paths(config, ticket['selected_paths'])
            expected_manifest = {**expected_manifest, 'files': {
                name: entry for name, entry in expected_manifest['files'].items()
                if in_selection(name, selection)}}
        if content_identity({'files': file_manifest(Path(ticket['workspace']))}) != content_identity(expected_manifest):
            raise NotReady('publish managed task data before handoff')
    else:
        current = command(ctx, {'action': 'inspect', 'project': config['project']})
        if not current['revision']:
            raise NotReady('import managed data before handoff')
        names = files(Path(root), config)
        if set(names) != set(current['manifest']['files']):
            raise NotReady('local managed data differs from NAS; prepare an external workspace before handoff')
        for name in names:
            expected = current['manifest']['files'].get(name)
            path = Path(root) / name
            with path.open('rb') as handle:
                is_sqlite = handle.read(16) == b'SQLite format 3\0'
            if is_sqlite:
                digest = sqlite_digest(path)
                expected_digest = (expected or {}).get('sqlite_sha256')
            else:
                digest = digest_file(path)
                expected_digest = (expected or {}).get('sha256')
            if not expected or digest != expected_digest:
                raise NotReady('local managed data differs from NAS; preserve/publish it before handoff')
    selection = {'selected_paths': ticket['selected_paths']} if ticket and 'selected_paths' in ticket else {}
    return {'schema_version': 1, 'project': config['project'], 'revision': current['revision'], 'config': config, **selection}


def check_handoff(ctx, metadata, root):
    config = binding(ctx, root)
    if metadata is None:
        if config:
            raise NotReady('source omitted managed data metadata')
        return True
    if metadata.get('schema_version') != 1 or metadata.get('config') != config or metadata.get('project') != (config or {}).get('project'):
        raise NotReady('managed data identity/config does not match receiver')
    component(metadata['revision'])
    validate(config)
    if 'selected_paths' in metadata:
        selection_paths(config, metadata['selected_paths'], root)
    command(ctx, {'action': 'inspect', 'project': config['project'], 'revision': metadata['revision']})
    return True
