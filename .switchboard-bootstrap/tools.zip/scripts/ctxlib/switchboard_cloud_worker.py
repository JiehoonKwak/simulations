"""Bind a Cloud worker's completed result to its private Switchboard dispatch."""
from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path

from . import project_data as data
from . import project_data_cloud
from .core import NotReady, atomic_json, canonical, component, run_git
from .project_data_completion import fingerprints, publication_lock
from .switchboard import redact

REPORT_LIMIT = 50_000
ENVELOPE_LIMIT = 16_384
RESULT_FIELDS = ('schema_version', 'issue', 'run_id', 'nonce', 'contract_sha256',
                 'base', 'repository', 'ticket', 'project', 'input_revision', 'selected_paths')


def bounded_text(path, limit):
    path = Path(path)
    if path.is_symlink():
        raise NotReady('Cloud dispatch inputs must not be symlinks')
    with path.open('rb') as handle:
        content = handle.read(limit + 1)
    if len(content) > limit or b'\0' in content:
        raise NotReady('Cloud dispatch input is too large or is not text')
    try:
        return content.decode('utf-8')
    except UnicodeError:
        raise NotReady('Cloud dispatch input must be UTF-8 text') from None


def repository(value):
    if isinstance(value, str) and value.startswith('github.com/'):
        value = 'https://' + value
    normalized = project_data_cloud.normalize_repository(value)
    if normalized is None:
        raise NotReady('Cloud dispatch requires a GitHub repository identity')
    return normalized


def read_envelope(path):
    try:
        envelope = json.loads(bounded_text(path, ENVELOPE_LIMIT))
        if not isinstance(envelope, dict) or type(envelope.get('schema_version')) is not int or envelope['schema_version'] != 1:
            raise ValueError
        if type(envelope['issue']) is not int or envelope['issue'] < 1:
            raise ValueError
        for key in ('run_id', 'nonce', 'project', 'ticket'):
            component(envelope[key])
        for key in ('contract_sha256', 'input_revision'):
            if not re.fullmatch(r'[0-9a-f]{64}', envelope[key]):
                raise ValueError
        if not re.fullmatch(r'[0-9a-f]{40}|[0-9a-f]{64}', envelope['base']):
            raise ValueError
        envelope['repository'] = repository(envelope['repository'])
        if not isinstance(envelope['selected_paths'], list) or not envelope['selected_paths']:
            raise ValueError
        return envelope
    except (KeyError, TypeError, ValueError):
        raise NotReady('Cloud dispatch envelope is missing or invalid') from None


def validate_report(report):
    """Share the explicit completion contract with the M1 receipt collector."""
    try:
        invalid = not isinstance(report, str) or len(report.encode('utf-8')) > REPORT_LIMIT or '\0' in report
    except UnicodeError:
        invalid = True
    if invalid:
        raise NotReady('Cloud report is too large or is not text')
    lines = [line.strip() for line in report.splitlines() if line.strip()]
    if not lines or lines[-1] != 'SWITCHBOARD-OUTCOME: done':
        raise NotReady('Cloud report must end with SWITCHBOARD-OUTCOME: done')
    outcomes = [line for line in lines if line.startswith('SWITCHBOARD-OUTCOME:')]
    if outcomes != ['SWITCHBOARD-OUTCOME: done']:
        raise NotReady('Cloud report contains conflicting outcomes')
    if [line for line in lines if line.startswith('SWITCHBOARD-WRITERS:')] != ['SWITCHBOARD-WRITERS: stopped']:
        raise NotReady('Cloud report must declare SWITCHBOARD-WRITERS: stopped')
    return redact(report)


def read_report(path):
    return validate_report(bounded_text(path, REPORT_LIMIT))


def validate_dispatch(envelope, ticket, root):
    if (ticket['id'] != envelope['ticket'] or ticket['project'] != envelope['project']
            or ticket['revision'] != envelope['input_revision']
            or ticket['base'] != envelope['input_revision']):
        raise NotReady('prepared Cloud ticket differs from dispatch identity or inputs')
    selection = data.selection_paths(ticket['config'], envelope['selected_paths'], root)
    if selection != envelope['selected_paths'] or ticket.get('selected_paths') != selection:
        raise NotReady('prepared Cloud selection differs from dispatch')
    if repository(run_git(root, 'remote', 'get-url', 'origin').decode().strip()) != envelope['repository']:
        raise NotReady('Cloud computation repository differs from dispatch')
    if run_git(root, 'status', '--porcelain', '--untracked-files=all').strip():
        raise NotReady('commit Cloud computation changes before publishing')
    try:
        run_git(root, 'merge-base', '--is-ancestor', envelope['base'], 'HEAD')
    except NotReady:
        raise NotReady('Cloud producing commit does not descend from dispatch base') from None
    if (run_git(root, 'ls-files', '--', '.switchboard-bootstrap').strip()
            or run_git(root, 'log', '--format=', '--name-only', envelope['base'] + '..HEAD',
                       '--', '.switchboard-bootstrap').strip()):
        raise NotReady('remove Cloud bootstrap files before committing; bootstrap history cannot be integrated')


def complete(ctx, *, envelope_path, report_path, workspace, ticket_id):
    """Freeze, bind and CAS-publish explicit completed output; retain on refusal."""
    envelope = read_envelope(envelope_path)
    report = read_report(report_path)
    root = Path(workspace).resolve()
    with publication_lock(ctx):
        ticket = data.load_ticket(ctx, component(ticket_id))
        validate_dispatch(envelope, ticket, root)
        metadata = {key: envelope[key] for key in RESULT_FIELDS}
        metadata.update(outcome='done', report=report)
        names = data.data_names(Path(ticket['workspace']))
        before = fingerprints(ticket['workspace'], names)
        frozen = data.freeze(ctx, ticket, root)
        if names != data.data_names(Path(ticket['workspace'])) or before != fingerprints(ticket['workspace'], names):
            raise NotReady('Cloud completed data changed while freezing; candidate retained')
        if (json.loads((Path(frozen['stage']) / 'manifest.json').read_text()) != frozen['manifest']
                or hashlib.sha256(canonical(frozen['manifest'])).hexdigest() != frozen['candidate']):
            raise NotReady('frozen Cloud manifest identity changed; candidate retained')
        existing = frozen['manifest'].get('switchboard_result')
        if existing is not None and existing != metadata:
            raise NotReady('frozen Cloud result belongs to another report or dispatch')
        if existing is None:
            if frozen.get('status') == 'published':
                raise NotReady('published checkpoint has no matching Cloud completion receipt')
            manifest = {**frozen['manifest'], 'switchboard_result': metadata}
            atomic_json(Path(frozen['stage']) / 'manifest.json', manifest)
            frozen = data.save_ticket(ctx, {**frozen, 'manifest': manifest,
                                           'candidate': hashlib.sha256(canonical(manifest)).hexdigest()})
        receipt = data.publish(ctx, frozen, integrated_root=root)
        if receipt.get('revision') != frozen['candidate']:
            raise NotReady('NAS publication did not return the bound Cloud candidate')
        return {'status': 'complete', 'issue': envelope['issue'], 'run_id': envelope['run_id'],
                'project': ticket['project'], 'ticket': ticket['id'], 'revision': receipt['revision'],
                'commit': frozen['source_commit'], 'ref': frozen['manifest']['provenance']['ref']}
