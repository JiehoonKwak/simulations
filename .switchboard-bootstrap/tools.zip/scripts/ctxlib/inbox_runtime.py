"""Repair missing headless metadata and settle sessions from their exact Actions run."""

from __future__ import annotations

import json
from pathlib import Path
import re
import subprocess
import time
import uuid

from .core import NotReady
from .dialogue import timestamp_value

CLAUDE_PROJECTS = Path.home() / ".claude/projects"
RUN_ROOT = Path.home() / ".local/state/agent-runs/switchboard"


def claude_turn_origin(path: Path, prompt_at: float = 0) -> str | None:
    """Use the latest main-session entrypoint; stale SDK metadata cannot hide a manual resume."""
    from .inbox import _tail

    latest = None
    for line in _tail(path).splitlines():
        try:
            record = json.loads(line)
        except ValueError:
            continue
        if not isinstance(record, dict) or record.get("type") != "user" or record.get("isSidechain") or record.get("isMeta"):
            continue
        if isinstance(record.get("entrypoint"), str):
            latest = record
    if latest is None:
        return None
    if prompt_at and timestamp_value(latest.get("timestamp")) < prompt_at - 5:
        return "interactive"
    return "headless" if latest["entrypoint"].startswith("sdk") else "interactive"


def headless_claude(item: dict) -> bool:
    from .inbox import NATIVE_ID

    if not NATIVE_ID.fullmatch(item["native_id"]):
        return False
    paths = list(CLAUDE_PROJECTS.glob(f"*/{item['native_id']}.jsonl"))
    return len(paths) == 1 and claude_turn_origin(paths[0], item.get("prompt_at") or 0) == "headless"


def recorded_run(item: dict) -> str:
    """Legacy worktree names locate a run; its stream must independently name this session."""
    match = re.search(r"(?:^|/)switchboard-(\d+)-(\d{1,20})(?:/|$)", item.get("cwd", ""))
    if not match:
        return ""
    for stream in (RUN_ROOT / f"{match[1]}-{match[2]}").glob("*.events.jsonl"):
        try:
            with stream.open() as handle:
                for line in handle:
                    try:
                        record = json.loads(line)
                    except ValueError:
                        continue
                    if isinstance(record, dict) and (record.get("session_id") == item["native_id"]
                                                    or record.get("thread_id") == item["native_id"]):
                        return match[2]
        except OSError:
            continue
    return ""


def metadata_events(items: list[dict], *, host: str) -> list[dict]:
    events = []
    for item in items:
        if item.get("host") != host or item.get("state") != "running":
            continue
        fields = {}
        background = bool(item.get("background"))
        if not background and item.get("harness") == "claude" and item.get("surface") == "cli" and headless_claude(item):
            fields["background"] = True
            background = True
        if background and not item.get("run_id"):
            run_id = recorded_run(item)
            if run_id:
                fields["run_id"] = run_id
        if fields:
            events.append({"id": uuid.uuid4().hex, "type": "metadata", "at": time.time(), "host": host,
                           "harness": item["harness"], "native_id": item["native_id"],
                           "expected_event_at": item["event_at"], **fields})
    return events


def reconcile_metadata(*, host: str) -> int:
    from . import inbox

    inbox.flush(host=host)
    items = inbox.run("_sessions", host=host, keys=(host,))["items"]
    events = metadata_events(items, host=host)
    for event in events:
        inbox.spool(event)
    if events:
        inbox.flush(host=host)
    return len(events)


def finish_runs(db, board: str) -> dict:
    """A completed workflow settles only background sessions bound to that run and not resumed later."""
    from . import inbox, switchboard

    rows = [dict(row) for row in db.execute("SELECT * FROM items WHERE kind='session' AND background=1 AND state='running' AND run_id != ''")]
    finished, deferred = 0, []
    for run_id in sorted({row["run_id"] for row in rows}):
        if not re.fullmatch(r"\d{1,20}", run_id):
            continue
        try:
            run = json.loads(switchboard.gh("api", f"repos/{board}/actions/runs/{run_id}", attempts=1))
            if str(run.get("id")) != run_id or run.get("status") != "completed":
                continue
            at = timestamp_value(run.get("updated_at"))
            if not 1_000_000_000 < at <= time.time() + 300:
                continue
        except (NotReady, OSError, ValueError, AttributeError, subprocess.SubprocessError):
            deferred.append(run_id)
            continue
        for item in rows:
            if item["run_id"] != run_id:
                continue
            finished += inbox.apply(db, {"id": uuid.uuid4().hex, "type": "finished", "at": at,
                                         "host": item["host"], "harness": item["harness"], "native_id": item["native_id"],
                                         "run_id": run_id, "expected_event_at": item["event_at"]})
    return {"finished_sessions": finished, "deferred_runs": deferred}
