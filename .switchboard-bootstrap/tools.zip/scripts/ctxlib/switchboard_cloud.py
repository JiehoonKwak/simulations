"""M1 supervises hosted workers through task-bound NAS and Git receipts.

Provider CLI output proves submission only. Completion comes from a pinned NAS
checkpoint carrying the exact dispatch envelope and a recoverable producing ref.
Unknown submissions are retained for recovery, never automatically submitted again.
"""
from __future__ import annotations

import hashlib
import json
import os
import pty
import re
import select
import shlex
import subprocess
import time
import uuid
import zipfile
from pathlib import Path

from . import models, project_data, project_data_cloud, secrets_scan
from .core import NotReady, atomic_json, canonical, component

CONFIG_PATH = Path.home() / '.config/ctx/switchboard-cloud.json'
SOURCE_ROOT = Path(__file__).resolve().parents[2]
POLL_SECONDS = 30
POLL_TIMEOUT = 7200
SUBMISSION_TIMEOUT = 120
MAX_OUTPUT = 65536
CLAUDE_AUTH_OVERRIDES = ('CLAUDE_CODE_OAUTH_TOKEN', 'ANTHROPIC_API_KEY', 'ANTHROPIC_AUTH_TOKEN',
                         'ANTHROPIC_API_TOKEN', 'ANTHROPIC_BASE_URL')


def provider_config(provider):
    try:
        value = json.loads(CONFIG_PATH.read_text())
        selected = value['providers'][provider]
        identity = selected['environment_id']
        if (value['schema_version'] != 1 or not isinstance(identity, str)
                or not re.fullmatch(r'[A-Za-z0-9_-]{4,128}', identity)
                or selected.get('submission', 'cli') not in ('cli', 'web')
                or selected.get('submission') == 'web' and provider != 'codex'):
            raise ValueError
        return selected
    except (OSError, KeyError, TypeError, ValueError) as error:
        raise NotReady(f'M1 has no valid pinned Jstack environment for {provider}') from error


def submission_identity(provider, output):
    """Accept an official hosted URL, never a local connected-session identifier."""
    output = re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]', '', output)
    pattern = (r'https://chatgpt\.com/codex/(?:tasks/)?(task_[A-Za-z0-9_-]+)'
               if provider == 'codex' else r'https://claude\.ai/code/(session_[A-Za-z0-9_-]+)')
    match = re.search(pattern, output)
    return {'id': match[1], 'url': match[0]} if match else None


def _interactive_submit(command, cwd, provider):
    """Bounded PTY for Claude's documented hosted launch; no local session fallback."""
    master, slave = pty.openpty()
    output = bytearray()
    process = None
    try:
        environment = dict(os.environ)
        if provider == 'claude':
            environment = {key: value for key, value in environment.items() if key not in CLAUDE_AUTH_OVERRIDES}
        process = subprocess.Popen(command, cwd=cwd, stdin=slave, stdout=slave, stderr=slave,
                                   start_new_session=True, env=environment)
        os.close(slave)
        slave = None
        deadline = time.monotonic() + SUBMISSION_TIMEOUT
        while time.monotonic() < deadline:
            if select.select([master], [], [], 0.25)[0]:
                try:
                    block = os.read(master, 4096)
                except OSError:
                    break
                if not block:
                    break
                output.extend(block)
                if len(output) > MAX_OUTPUT:
                    raise NotReady('Cloud submission output exceeded its bounded receipt size')
                if submission_identity(provider, output.decode(errors='replace')):
                    break
            if process.poll() is not None:
                break
        return output.decode(errors='replace')
    finally:
        if process is not None and process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=5)
        os.close(master)
        if slave is not None:
            os.close(slave)


def submit(provider, environment, dispatch_branch, prompt, cwd, run_dir):
    """Submit once. Absence of a durable URL is an unknown submission, not a retry."""
    from . import switchboard as board
    if provider == 'codex':
        result = subprocess.run(['codex', 'cloud', 'exec', '--env', environment,
                                 '--branch', dispatch_branch, '-'], input=prompt, cwd=cwd,
                                capture_output=True, text=True, timeout=SUBMISSION_TIMEOUT)
        output = (result.stdout + '\n' + result.stderr)[:MAX_OUTPUT]
    else:
        settings = json.dumps({'remote': {'defaultEnvironmentId': environment}}, separators=(',', ':'))
        output = _interactive_submit(['claude', '--cloud', prompt, '--settings', settings,
                                      '--setting-sources', 'user'], cwd, provider)
    board.private_write(run_dir / 'cloud-submission.log', secrets_scan.redact(output))
    identity = submission_identity(provider, output)
    if identity is None:
        raise NotReady('Cloud submission did not return a hosted task URL; submission is unknown. '
                       'Recover its provider ID before resuming; no automatic resubmission.')
    return identity


def bootstrap_bundle(destination):
    """Only reviewed portable source, with no host state, credentials or installed providers."""
    files = [SOURCE_ROOT / 'scripts/ctx.py', SOURCE_ROOT / 'scripts/switchboard_cloud_worker.py',
             SOURCE_ROOT / 'config/project-data-cloud.json', SOURCE_ROOT / 'config/project-data.json',
             *sorted((SOURCE_ROOT / 'scripts/ctxlib').glob('*.py'))]
    total = 0
    with zipfile.ZipFile(destination, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
        for path in files:
            if not path.is_file() or path.is_symlink():
                raise NotReady('portable Cloud bootstrap source is missing or symlinked')
            data = path.read_bytes()
            total += len(data)
            if total > 8 * 1024 * 1024:
                raise NotReady('portable Cloud bootstrap exceeds its reviewed source bound')
            if secrets_scan.kinds_in(data):
                raise NotReady('credential-like value in portable bootstrap source: ' + path.name)
            member = zipfile.ZipInfo(path.relative_to(SOURCE_ROOT).as_posix(), (2026, 1, 1, 0, 0, 0))
            member.external_attr = 0o600 << 16
            member.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(member, data)


def make_dispatch(root, base, envelope, run_dir):
    from . import switchboard as board
    branch = 'codex/' + envelope['ticket'] + '-dispatch'
    worktree = run_dir / 'dispatch'
    if worktree.exists():
        if board.git('symbolic-ref', '--short', 'HEAD', cwd=worktree).stdout.strip() != branch:
            raise NotReady('existing Cloud dispatch worktree has a different branch')
    else:
        board.git('worktree', 'add', '-b', branch, str(worktree), base, cwd=root)
    directory = worktree / '.switchboard-bootstrap'
    directory.mkdir(mode=0o700, exist_ok=True)
    bootstrap_bundle(directory / 'tools.zip')
    atomic_json(directory / 'envelope.json', envelope)
    board.git('add', '-f', '--', '.switchboard-bootstrap', cwd=worktree)
    if board.git('diff', '--cached', '--quiet', cwd=worktree, check=False).returncode:
        board.git('commit', '-m', 'chore(switchboard): stage portable hosted worker dispatch', cwd=worktree)
    board.git('push', 'origin', f'HEAD:refs/heads/{branch}', cwd=worktree)
    return branch, worktree


def dispatch_identity(worktree):
    from . import switchboard as board
    commit = board.git('rev-parse', 'HEAD', cwd=worktree).stdout.strip()
    if not re.fullmatch(r'[0-9a-f]{40}|[0-9a-f]{64}', commit):
        raise NotReady('Cloud dispatch has no exact Git commit identity')
    return commit, hashlib.sha256((worktree / '.switchboard-bootstrap/tools.zip').read_bytes()).hexdigest()


def worker_prompt(issue, fields, focus, provider, envelope, dispatch_commit, bundle_sha256):
    from . import switchboard as board
    ticket = envelope['ticket']
    temporary = '/tmp/' + ticket
    paths = ' '.join('--path ' + shlex.quote(path) for path in envelope['selected_paths'])
    return (
        'Run this task in the hosted Cloud VM. Start in the Git checkout whose origin normalizes to '
        + envelope['repository'] + '; fail explicitly if that approved repository is unavailable. '
        'Fetch only the saved dispatch branch with git fetch origin refs/heads/codex/' + ticket + '-dispatch. '
        'Verify FETCH_HEAD is exactly ' + dispatch_commit + ' before checking it out. '
        'The dispatch branch contains a reviewed portable ctx bundle. Verify .switchboard-bootstrap exists, '
        'that tools.zip SHA-256 is exactly ' + bundle_sha256 + ', and that envelope.json equals this full '
        'expected envelope object: ' + json.dumps(envelope, sort_keys=True) + '. '
        'Do not run tools from any other branch, downloaded source or installed fallback. '
        'Only after these checks extract .switchboard-bootstrap/tools.zip into ' + temporary + '/tools and copy '
        '.switchboard-bootstrap/envelope.json into ' + temporary + '/envelope.json. '
        'Then checkout the exact original base ' + envelope['base'] + ' and create branch codex/' + ticket + '-result. '
        'The bootstrap commit and directory must never enter the producing commit or final Git result. '
        'Use Python 3.11 or newer; install websockets if the bundled ctx imports require it. '
        f'Export CTX_STATE_DIR={temporary}/state and CTX_PROJECT_DATA_PROVIDER={provider}. '
        f'Run python3 {temporary}/tools/scripts/ctx.py project-data configure-cloud --provider {provider} --json. '
        f'Prepare only selected NAS paths with python3 {temporary}/tools/scripts/ctx.py project-data prepare '
        f'--workspace "$PWD" --project {envelope["project"]} --task {ticket} '
        f'--revision {envelope["input_revision"]} {paths} --json. '
        'Use the returned external data workspace for all retained data. Do not put managed data in Git. '
        'Write outputs only within selected_paths; extra files outside that selection cause publication refusal. '
        'Complete all verification, stop all data writers, and commit the task code on the result branch. '
        'Do not push or merge main. '
        f'Write your report to {temporary}/report.md, including evidence, Side effects, '
        'one line SWITCHBOARD-WRITERS: stopped, and final line SWITCHBOARD-OUTCOME: done only after success. '
        f'Then run python3 {temporary}/tools/scripts/switchboard_cloud_worker.py '
        f'--envelope {temporary}/envelope.json --report {temporary}/report.md --workspace "$PWD" --ticket {ticket}. '
        'This wrapper validates the dispatch contract, preserves your producing Git ref and publishes the NAS '
        'checkpoint and receipt. If a step fails, retain all results and report the failure; do not fabricate a receipt. '
        f'\n\nSwitchboard #{issue["number"]}: {issue["title"]}\n\n' + board.task_contract(fields, focus)
    )


def validate_receipt(envelope, receipt, checkpoint):
    if (not isinstance(receipt, dict) or not isinstance(checkpoint, dict)
            or receipt.get('status') != 'complete' or receipt.get('project') != envelope['project']
            or receipt.get('id') != envelope['ticket']):
        raise NotReady('NAS receipt does not belong to this Cloud task')
    request, result = receipt.get('request', {}), receipt.get('result', {})
    revision = receipt.get('revision')
    if (not isinstance(request, dict) or not isinstance(result, dict)
            or not isinstance(revision, str) or not re.fullmatch(r'[0-9a-f]{64}', revision)
            or request != {'action': 'publish', 'project': envelope['project'], 'id': envelope['ticket'],
                           'revision': revision, 'base': envelope['input_revision']}
            or result.get('status') != 'complete' or result.get('revision') != revision
            or checkpoint.get('revision') != revision):
        raise NotReady('NAS publication receipt revision or input baseline differs from dispatch')
    manifest = checkpoint.get('manifest')
    if (not isinstance(manifest, dict) or not isinstance(manifest.get('files'), dict)
            or manifest.get('project') != envelope['project']
            or hashlib.sha256(canonical(manifest)).hexdigest() != revision):
        raise NotReady('NAS checkpoint content does not match its publication receipt')
    packet = manifest.get('switchboard_result', {})
    if (not isinstance(packet, dict) or packet.get('outcome') != 'done'
            or {key: packet.get(key) for key in envelope} != envelope):
        raise NotReady('Cloud completion packet does not match this task contract')
    from .switchboard_cloud_worker import validate_report
    report = validate_report(packet.get('report'))
    provenance = manifest.get('provenance', {})
    if (not isinstance(provenance, dict)
            or provenance.get('ref') != 'refs/heads/ctx-data/' + envelope['ticket']
            or not re.fullmatch(r'[0-9a-f]{40,64}', str(provenance.get('commit', '')))
            or provenance.get('input_revision') != envelope['input_revision']):
        raise NotReady('Cloud producing code provenance differs from dispatched inputs')
    return provenance['commit'], provenance['ref'], report


def poll_receipt(ctx, envelope, run_dir, *, timeout=POLL_TIMEOUT):
    from .project_data_http import Client, TransportError
    from http.client import HTTPException
    config = project_data.settings(ctx)
    if not config.get('endpoint'):
        raise NotReady('Cloud supervision requires the shared HTTPS NAS backend')
    client = Client(config)
    deadline = time.monotonic() + timeout
    while True:
        try:
            value = client.command({'action': 'receipt', 'project': envelope['project'], 'id': envelope['ticket']})
        except TransportError as error:
            if isinstance(error.__cause__, (OSError, HTTPException)):
                atomic_json(run_dir / 'cloud-nas-receipt.json',
                            {'status': 'pending', 'reason': 'NAS connection interrupted; existing Cloud submission retained'})
                return None
            raise
        atomic_json(run_dir / 'cloud-nas-receipt.json', value)
        if value.get('project') != envelope['project'] or value.get('id') != envelope['ticket']:
            raise NotReady('NAS receipt polling returned another task identity')
        if value.get('status') == 'complete':
            return value
        if value.get('status') not in ('pending', 'not_ready'):
            raise NotReady('Cloud NAS publication failed: ' + value.get('reason', value.get('status', 'unknown')))
        if value.get('status') == 'not_ready' and value.get('reason') != 'publication receipt not found':
            raise NotReady('Cloud NAS receipt refused: ' + value.get('reason', 'unknown'))
        if time.monotonic() >= deadline:
            return None
        time.sleep(min(POLL_SECONDS, max(0, deadline - time.monotonic())))


def collect(ctx, issue, fields, root, branch, upstream, focus, run_dir, state):
    from . import switchboard as board
    envelope = state['envelope']
    receipt = poll_receipt(ctx, envelope, run_dir)
    if receipt is None:
        return {'status': 'pending', 'problem': None, 'integration': 'Cloud still running; submission retained',
                'verification': None, 'data_note': 'waiting for the task-bound NAS publication receipt', 'sections': []}
    checkpoint = project_data.command(ctx, {'action': 'inspect', 'project': envelope['project'],
                                            'revision': receipt['revision']})
    commit, ref, report = validate_receipt(envelope, receipt, checkpoint)
    if hashlib.sha256(canonical(project_data.binding(ctx, root))).hexdigest() != checkpoint['manifest']['provenance'].get('config_sha256'):
        raise NotReady('published data binding differs from the M1 approved binding')
    baseline = project_data.command(ctx, {'action': 'inspect', 'project': envelope['project'],
                                          'revision': envelope['input_revision']})
    outside = lambda manifest: {name: entry for name, entry in manifest['files'].items()
                                if not project_data.in_selection(name, envelope['selected_paths'])}
    if outside(baseline['manifest']) != outside(checkpoint['manifest']):
        raise NotReady('Cloud publication changed data outside the dispatched selection')
    state.update(phase='published', revision=receipt['revision'], producing_commit=commit)
    atomic_json(run_dir / 'cloud-state.json', state)
    source_ref = 'refs/ctx-cloud/' + envelope['ticket'] + '/producing'
    board.git('fetch', 'origin', f'{ref}:{source_ref}', cwd=root)
    if board.git('rev-parse', source_ref, cwd=root).stdout.strip() != commit:
        raise NotReady('recoverable Cloud Git ref differs from NAS producing commit; outputs retained')
    if board.git('merge-base', '--is-ancestor', envelope['base'], commit, cwd=root, check=False).returncode:
        raise NotReady('Cloud producing commit is not based on the dispatched Git revision')
    if (board.git('ls-tree', '-r', '--name-only', commit, '--', '.switchboard-bootstrap', cwd=root).stdout.strip()
            or board.git('log', '--format=%H', envelope['base'] + '..' + commit, '--',
                         '.switchboard-bootstrap', cwd=root).stdout.strip()):
        raise NotReady('Cloud producing commit retained its dispatch bootstrap')
    worktree = run_dir / 'result-worktree'
    if not worktree.exists():
        board.git('worktree', 'add', '-b', 'codex/' + envelope['ticket'] + '-result', str(worktree), commit, cwd=root)
    elif board.git('status', '--porcelain', cwd=worktree).stdout.strip():
        raise NotReady('recovery worktree has uncommitted changes; results retained')
    stages = [('Cloud worker report (before M1 integration)', report)]
    readback = project_data.prepare(ctx, root, envelope['ticket'] + '-readback',
                                   pinned={'revision': receipt['revision']}, selected_paths=envelope['selected_paths'])
    provider = state['provider']
    local_fields = {**fields, 'harness': provider, 'model': models.DEFAULTS[provider][0],
                    'effort': models.DEFAULTS[provider][1],
                    'context': fields.get('context', '') + '\nPublished Cloud outputs have been checksum-verified '
                    'and prepared on M1 at ' + readback['workspace'] + '. Use this external workspace for all '
                    'data verification. This is a readback ticket: do not freeze or publish it.'}
    verification = board.verify_final_revision(worktree, local_fields, focus, run_dir, issue, stages)
    binding = project_data.binding(ctx, root)
    def validate_final(candidate):
        changed = board.git('diff', '--name-only', commit, 'HEAD', cwd=candidate).stdout.splitlines()
        if any(project_data.relevant(binding, name) for name in changed):
            raise NotReady('computation code changed after Cloud publication; NAS outputs and Git refs retained '
                           'for validation or rerun; integration refused')
    validate_final(worktree)
    integration, final_check = board.integrate(root, branch, upstream, worktree, envelope['base'], local_fields,
                                               focus, run_dir, issue, stages, cleanup=False,
                                               validate_final=validate_final)
    state.update(phase='integrated', integration=integration, verification=verification + '; ' + final_check)
    atomic_json(run_dir / 'cloud-state.json', state)
    return {'status': 'done', 'problem': None, 'integration': integration, 'verification': state['verification'],
            'data_note': f'published Cloud ticket {envelope["ticket"]}; revision {receipt["revision"]}',
            'sections': stages}


def run(ctx, issue, fields, root, branch, upstream, base, focus, run_dir):
    """Serialize one run's submission and recovery; re-read state under the lock."""
    with project_data.locked_directory(Path(run_dir)):
        return _run_locked(ctx, issue, fields, root, branch, upstream, base, focus, run_dir)


def attach(ctx, issue, fields, root, focus, run_dir, url):
    """Record an authorized existing Jstack web task; this never launches a task."""
    from . import switchboard as board
    if ctx.config.host != 'm1pro' or fields.get('harness') != 'codex-cloud':
        raise NotReady('only M1 may attach a Codex hosted web task')
    match = re.fullmatch(r'https://chatgpt\.com/local/([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})', url)
    if match is None:
        raise NotReady('attach requires the exact existing ChatGPT Work task URL')
    run_dir = Path(run_dir)
    with project_data.locked_directory(run_dir):
        state = json.loads((run_dir / 'cloud-state.json').read_text())
        config = provider_config('codex')
        binding = project_data.binding(ctx, root)
        if binding is None:
            raise NotReady('attached Cloud task has no approved managed data binding')
        repository = project_data_cloud.normalize_repository(board.git('remote', 'get-url', 'origin', cwd=root).stdout.strip())
        envelope = state['envelope']
        contract = hashlib.sha256(canonical({'issue': issue['number'], 'title': issue['title'],
                                              'fields': fields, 'focus': focus})).hexdigest()
        paths = project_data.selection_paths(binding, [line.strip() for line in fields.get('data paths', '').splitlines() if line.strip()], root)
        if (config.get('submission') != 'web' or state.get('provider') != 'codex'
                or state.get('environment_id') != config['environment_id']
                or state.get('submission') != 'web'
                or envelope.get('issue') != issue['number']
                or envelope.get('run_id') != run_dir.name.removeprefix(str(issue['number']) + '-')
                or envelope.get('contract_sha256') != contract or envelope.get('repository') != repository
                or envelope.get('project') != binding['project'] or envelope.get('selected_paths') != paths):
            raise NotReady('attached Cloud task contract differs from the retained dispatch')
        identity = {'id': match[1], 'url': url}
        if state.get('cloud_task'):
            if state['cloud_task'] != identity:
                raise NotReady('this dispatch already belongs to a different Cloud task')
            return {'status': 'complete', 'cloud_task': identity, 'already_attached': True}
        if state.get('phase') != 'awaiting_submission':
            raise NotReady('dispatch is not waiting for an explicitly launched web task')
        state.update(phase='submitted', cloud_task=identity)
        atomic_json(run_dir / 'cloud-state.json', state)
        return {'status': 'complete', 'cloud_task': identity}


def awaiting_web_submission(run_dir):
    return {'status': 'pending', 'problem': None,
            'integration': 'Jstack web task launch required; no automatic M1 submission is available',
            'verification': None, 'data_note': 'prepared dispatch; prompt retained at ' + str(run_dir / 'cloud-prompt.md'),
            'sections': []}


def _run_locked(ctx, issue, fields, root, branch, upstream, base, focus, run_dir):
    """Called only after the board's owner, actor, repository and base authorization gates."""
    from . import switchboard as board
    run_dir = Path(run_dir)
    state_path = run_dir / 'cloud-state.json'
    try:
        if ctx.config.host != 'm1pro':
            raise NotReady('hosted Cloud tasks are supervised only by M1')
        harness = fields.get('harness', '').lower()
        if harness not in ('codex-cloud', 'claude-cloud'):
            raise NotReady('unsupported hosted Cloud harness')
        if fields.get('model') or fields.get('effort'):
            raise NotReady('Cloud model/effort controls are not supported by this adapter; use the pinned environment defaults')
        provider = harness.removesuffix('-cloud')
        provider_settings = provider_config(provider)
        environment = provider_settings['environment_id']
        config = project_data.binding(ctx, root)
        repository = project_data_cloud.normalize_repository(board.git('remote', 'get-url', 'origin', cwd=root).stdout.strip())
        if (config is None or repository is None
                or project_data_cloud.resolve_repository(root) != config['project']):
            raise NotReady('Cloud task requires an approved Cloud-enabled NAS-managed Git project')
        raw_paths = [line.strip() for line in fields.get('data paths', '').splitlines() if line.strip()]
        if not raw_paths:
            raise NotReady('Cloud task requires explicit Data Paths for selected NAS inputs and outputs')
        paths = project_data.selection_paths(config, raw_paths, root)
        contract = hashlib.sha256(canonical({'issue': issue['number'], 'title': issue['title'],
                                              'fields': fields, 'focus': focus})).hexdigest()
        if state_path.exists():
            state = json.loads(state_path.read_text())
            envelope = state['envelope']
            if (state['provider'] != provider or state['environment_id'] != environment
                    or envelope['contract_sha256'] != contract or envelope['repository'] != repository
                    or envelope['project'] != config['project'] or envelope['selected_paths'] != paths):
                raise NotReady('Cloud recovery contract differs from the original dispatch; no resubmission')
            if state['phase'] == 'integrated':
                return {'status': 'done', 'problem': None, 'integration': state['integration'],
                        'verification': state['verification'], 'data_note': 'published revision ' + state['revision'],
                        'sections': []}
            if state['phase'] in ('submitting', 'submission_unknown') and not state.get('cloud_task'):
                raise NotReady('Cloud submission is unknown; recover its provider ID before resuming; no resubmission')
            if state['phase'] == 'awaiting_submission' and not state.get('cloud_task'):
                return awaiting_web_submission(run_dir)
        else:
            current = project_data.command(ctx, {'action': 'inspect', 'project': config['project']})
            revision = current.get('revision')
            if not isinstance(revision, str) or not re.fullmatch(r'[0-9a-f]{64}', revision):
                raise NotReady('Cloud task requires a completed NAS input checkpoint')
            run_id = run_dir.name.removeprefix(str(issue['number']) + '-')
            ticket = component(f'switchboard-{issue["number"]}-{run_id}')
            envelope = {'schema_version': 1, 'issue': int(issue['number']), 'run_id': run_id, 'ticket': ticket,
                        'nonce': uuid.uuid4().hex, 'contract_sha256': contract, 'project': config['project'],
                        'repository': repository, 'base': base, 'input_revision': revision, 'selected_paths': paths}
            state = {'schema_version': 1, 'provider': provider, 'environment_id': environment,
                     'envelope': envelope, 'phase': 'preparing'}
            atomic_json(state_path, state)
        if not state.get('cloud_task'):
            dispatch, worktree = make_dispatch(root, envelope['base'], envelope, run_dir)
            dispatch_commit, bundle_sha256 = dispatch_identity(worktree)
            prompt = worker_prompt(issue, fields, focus, provider, envelope, dispatch_commit, bundle_sha256)
            state.update(dispatch_commit=dispatch_commit, bootstrap_sha256=bundle_sha256)
            board.private_write(run_dir / 'cloud-prompt.md', prompt)
            if provider_settings.get('submission') == 'web':
                state.update(phase='awaiting_submission', dispatch_branch=dispatch, submission='web')
                atomic_json(state_path, state)
                return awaiting_web_submission(run_dir)
            state.update(phase='submitting', dispatch_branch=dispatch)
            atomic_json(state_path, state)
            try:
                identity = submit(provider, environment, dispatch, prompt, worktree, run_dir)
            except (OSError, subprocess.TimeoutExpired, NotReady) as error:
                state.update(phase='submission_unknown', problem=secrets_scan.redact(str(error)))
                atomic_json(state_path, state)
                raise NotReady('Cloud submission could not be confirmed; no automatic resubmission. ' + str(error)) from error
            state.update(phase='submitted', cloud_task=identity)
            atomic_json(state_path, state)
        return collect(ctx, issue, fields, root, branch, upstream, focus, run_dir, state)
    except (NotReady, board.TaskError, OSError, ValueError, KeyError, TypeError) as error:
        return {'status': 'failed', 'problem': secrets_scan.redact(str(error)), 'integration': 'not completed; results retained',
                'verification': None, 'data_note': None, 'sections': []}
