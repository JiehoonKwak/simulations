"""Native Codex/Claude transcripts as dialogue turns, origins, and redacted excerpts."""

from __future__ import annotations

import json
import re
from collections.abc import Iterable, Iterator
from datetime import datetime
from pathlib import Path
from typing import Any

from . import secrets_scan

INJECTED_PREFIXES = (
    "<recommended_plugins>",
    "# AGENTS.md instructions",
    "<environment_context>",
    "<app-context>",
    "<codex_delegation>",
    "Side conversation boundary.",
    "[Your active task list was preserved",
    "[IMPORTANT:",
    "[Workspace::",
    "[Recent channel messages]",
    "[ASYNC DELEGATION",
    "[System note:",
    "<skill>",
    "<subagent_notification>",
    "<turn_aborted>",
    "<hook_prompt",
    "<codex_internal_context",
    "<in-app-browser-context",
    "<external_codex_apps_open_page>",
)
SUMMARY_PREFIXES = ("[PRIOR CONTEXT", "[CONTEXT COMPACTION", "[END OF PRIOR CONTEXT")
CLAUDE_INJECTED_PREFIXES = (
    "<local-command-",
    "<system-reminder>",
    "<task-notification>",
    "<bash-input>",
    "<bash-stdout>",
    "<bash-stderr>",
    "Caveat: ",
    "[Request interrupted",
)
CLAUDE_COMMAND_ARGS = re.compile(r"<command-args>(.*?)</command-args>", re.DOTALL)
SECRET_PATTERNS = (
    *secrets_scan.PATTERNS,
    re.compile(r"\b(?:sk|rk|pk)-[A-Za-z0-9_-]{12,}\b"),
    re.compile(r"\b(?:ghp|github_pat)_[A-Za-z0-9_]{12,}\b"),
    re.compile(r"\bBearer\s+[A-Za-z0-9._~+/=-]{8,}", re.IGNORECASE),
    re.compile(r"\beyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\b"),
    re.compile(
        r"(?i)\b(password|passwd|passcode|api[_ -]?key|access[_ -]?token|refresh[_ -]?token|비밀번호|비번)"
        r"(\s*(?:is|=|:|은|는)?\s*)"
        r"([^\s,;`'\"]{3,})"
    ),
)
ORIGINS = ("interactive", "automation", "headless", "agent")
DEFAULT_ORIGINS = ("interactive", "automation")


def redact(text: str) -> str:
    value = text
    for pattern in SECRET_PATTERNS:
        if pattern.groups >= 3:
            value = pattern.sub(lambda m: f"{m.group(1)}{m.group(2)}[REDACTED]", value)
        else:
            value = pattern.sub("[REDACTED]", value)
    return value


def shorten(text: str, width: int) -> str:
    compact = " ".join(text.split())
    return compact if len(compact) <= width else compact[: width - 1] + "…"


def query_tokens(query: str) -> list[str]:
    return [token.casefold() for token in re.findall(r"[^\W_]+", query, flags=re.UNICODE) if len(token) >= 2]


def excerpt(text: str, query: str, width: int = 180) -> str:
    compact = " ".join(redact(text).split())
    if len(compact) <= width:
        return compact
    folded = compact.casefold()
    needles = [query.casefold().strip(), *query_tokens(query)]
    position = next((folded.find(item) for item in needles if item and item in folded), 0)
    start = max(0, position - width // 4)
    end = min(len(compact), start + width)
    return ("…" if start else "") + compact[start:end] + ("…" if end < len(compact) else "")


def timestamp_value(value: Any) -> float:
    if value in (None, ""):
        return 0.0
    try:
        return float(value)
    except (TypeError, ValueError):
        try:
            return datetime.fromisoformat(str(value).replace("Z", "+00:00")).timestamp()
        except ValueError:
            return 0.0


def _deduplicate(messages: Iterable[dict[str, Any]]) -> list[dict[str, Any]]:
    result, seen = [], set()
    for message in messages:
        key = (message.get("timestamp"), message.get("role"), message.get("text"))
        if key not in seen:
            seen.add(key)
            result.append(message)
    return result


def codex_records(path: Path, *, start_ordinal: int | None = None, end_ordinal_exclusive: int | None = None,
                  byte_limit: int | None = None) -> Iterator[tuple[int, dict[str, Any]]]:
    if not path.is_file():
        return
    byte_end = 0
    with path.open("rb") as handle:
        for line_number, line in enumerate(handle, 1):
            byte_end += len(line)
            if byte_limit is not None and byte_end > byte_limit:
                break
            try:
                record = json.loads(line)
            except (json.JSONDecodeError, UnicodeDecodeError):
                continue
            if not isinstance(record, dict):
                continue
            if start_ordinal is not None or end_ordinal_exclusive is not None:
                ordinal = record.get("ordinal")
                if not isinstance(ordinal, int) or isinstance(ordinal, bool):
                    if end_ordinal_exclusive is None and (start_ordinal or 0) <= 1:
                        yield line_number, record
                        continue
                    raise ValueError(f"Missing native Codex ordinal at {path}:{line_number}")
                if start_ordinal is not None and ordinal < start_ordinal:
                    continue
                if end_ordinal_exclusive is not None and ordinal >= end_ordinal_exclusive:
                    continue
            yield line_number, record


def codex_dialogue(path: Path, **boundaries) -> list[dict[str, Any]]:
    messages: list[dict[str, Any]] = []
    for line_number, record in codex_records(path, **boundaries):
        payload = record.get("payload") or {}
        if record.get("type") != "response_item" or payload.get("type") != "message" or payload.get("role") not in {"user", "assistant"}:
            continue
        pieces = []
        for item in payload.get("content") or []:
            text = item.get("text") if isinstance(item, dict) else None
            if not isinstance(text, str) or not text.strip():
                continue
            if payload.get("role") == "user" and text.lstrip().startswith(INJECTED_PREFIXES):
                continue
            pieces.append(text)
        text = "\n".join(pieces).strip()
        if not text or text.startswith(SUMMARY_PREFIXES):
            continue
        messages.append({"timestamp": record.get("timestamp") or "", "role": payload["role"],
                         "phase": payload.get("phase") or "", "text": redact(text),
                         "native_id": payload.get("id") or record.get("id") or "", "raw_lines": [line_number]})
    return _deduplicate(messages)


def claude_records(path: Path) -> Iterator[dict[str, Any]]:
    with path.open(encoding="utf-8", errors="replace") as handle:
        for line_number, line in enumerate(handle, 1):
            try:
                record = json.loads(line)
            except json.JSONDecodeError:
                continue
            if isinstance(record, dict):
                record["_raw_line"] = line_number
                yield record


def claude_message(record: dict[str, Any]) -> tuple[list[str], bool]:
    """Return a dialogue record's visible text and whether it also called a tool."""
    if record.get("type") not in {"user", "assistant"} or record.get("isMeta") or record.get("isSidechain") or record.get("isCompactSummary"):
        return [], False
    content = (record.get("message") or {}).get("content")
    blocks = [{"type": "text", "text": content}] if isinstance(content, str) else [block for block in content or [] if isinstance(block, dict)]
    texts = []
    for block in blocks:
        text = block.get("text")
        if block.get("type") != "text" or not isinstance(text, str):
            continue
        stripped = text.strip()
        if record["type"] == "user":
            if stripped.startswith("<command-"):
                match = CLAUDE_COMMAND_ARGS.search(stripped)
                stripped = match.group(1).strip() if match else ""
            if stripped.startswith(CLAUDE_INJECTED_PREFIXES):
                continue
        if stripped:
            texts.append(stripped)
    return texts, any(block.get("type") == "tool_use" for block in blocks)


def claude_dialogue(path: Path) -> list[dict[str, Any]]:
    messages: list[dict[str, Any]] = []
    if not path.is_file():
        return messages
    by_id: dict[str, dict[str, Any]] = {}
    for record in claude_records(path):
        texts, used_tool = claude_message(record)
        if not texts and not used_tool:
            continue
        group = (record.get("message") or {}).get("id") or ""
        entry = by_id.get(group) if record["type"] == "assistant" else None
        if entry is None:
            entry = {"timestamp": record.get("timestamp") or "", "role": record["type"], "phase": "", "text": "",
                     "native_id": record.get("uuid") or group, "raw_lines": []}
            messages.append(entry)
            if group and record["type"] == "assistant":
                by_id[group] = entry
        entry["text"] = "\n".join(filter(None, [entry["text"], *texts]))
        entry["raw_lines"].append(record["_raw_line"])
        if used_tool:
            entry["phase"] = "commentary"
    return _deduplicate({**message, "text": redact(message["text"])} for message in messages if message["text"])


def origin(harness: str, path: Path) -> str:
    """Classify a native transcript by who started it; unknown shapes stay discoverable.

    Current Codex clients record a thread source and its creator; a thread with a creator but no
    source was started over the app-server API by a program, not by a person.
    """
    if harness == "codex":
        for _, record in codex_records(path):
            if record.get("type") != "session_meta":
                continue
            meta = record.get("payload") or {}
            source, thread = meta.get("source"), meta.get("thread_source")
            if isinstance(source, dict) or thread in {"subagent", "guardian_review", "agent_created_thread", "self_improvement"}:
                return "agent"
            if source == "exec":
                return "headless"
            if thread == "automation":
                return "automation"
            return "agent" if thread is None and "creator_user_id" in meta else "interactive"
        return "interactive"
    if harness == "claude" and path.is_file():
        for record in claude_records(path):
            if record.get("isSidechain"):
                return "agent"
            entrypoint = record.get("entrypoint")
            if entrypoint:
                return "headless" if entrypoint.startswith("sdk") else "interactive"
    return "interactive"
