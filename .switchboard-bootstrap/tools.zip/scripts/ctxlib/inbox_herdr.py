"""Dismiss exited Herdr sessions, including legacy unread items with bad pane IDs."""
from __future__ import annotations

from collections import Counter
import fcntl
import json
import os
import subprocess
from pathlib import Path
import time

from .core import NotReady, atomic_json
from .herdr_inventory import inventory
from .herdr import _same_folder

STATE = Path(os.environ.get("CTX_HERDR_STATE", Path.home() / ".local/state/ctx/herdr-inbox.json"))
GRACE = 10


def title(pane: dict) -> str:
    value = pane.get("terminal_title_stripped", "").lstrip(" ⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏")
    cwd = pane.get("foreground_cwd") or pane.get("cwd", "")
    suffix = f" | {Path(cwd).name}"
    return value[:-len(suffix)] if cwd and value.endswith(suffix) else ""


def live_for(item: dict, panes: list[dict]) -> list[dict]:
    exact, fallback = [], []
    for pane in panes:
        if not any(p["harness"] == item["harness"] for p in pane["foreground"]):
            continue
        identity = pane.get("agent_session") or {}
        if identity.get("kind") == "id":
            if identity.get("agent") == item["harness"] and identity.get("value") == item["native_id"]:
                exact.append(pane)
        elif item["harness"] == "codex" and item.get("verified_title") and title(pane) == item["title"] and item["cwd"] and _same_folder(pane.get("foreground_cwd") or pane.get("cwd"), item["cwd"]):
            fallback.append(pane)
    return exact or fallback


def attachment(pane: dict, harness: str) -> dict | None:
    processes = [p for p in pane["foreground"] if p["harness"] == harness]
    if len(processes) != 1:
        return None
    return {"server": pane["server"], "terminal": pane["terminal_id"], "pid": processes[0]["pid"], "start": processes[0]["start"]}


def plan(items: list[dict], snapshot: dict, previous: dict, now: float) -> tuple[list[dict], dict, list[dict]]:
    """Use both directions of identity matching; stored legacy pane IDs are never evidence."""
    panes = snapshot["panes"]
    matches = {i["key"]: live_for(i, panes) for i in items}
    reverse = Counter((p["server"], p["terminal_id"]) for found in matches.values() for p in found)
    servers = sorted(snapshot["servers"])
    unknown = set(snapshot["outsiders"])
    for pane in panes:
        for process in pane["foreground"]:
            harness = process["harness"]
            identity = pane.get("agent_session") or {}
            identified = identity.get("kind") == "id" and identity.get("agent") == harness
            if harness and not identified and (harness != "codex" or not title(pane)):
                unknown.add(harness)
        if pane.get("agent") in {"codex", "claude"} and not any(p["harness"] == pane["agent"] for p in pane["foreground"]):
            unknown.add(pane["agent"])
    state = {"bindings": {}, "missing": {}}
    closed, deferred = [], []
    for item in items:
        if item.get("background"):
            continue
        key, found = item["key"], matches[item["key"]]
        if item.get("native_desktop"):
            continue
        binding = previous.get("bindings", {}).get(key)
        if len(found) == 1 and reverse[(found[0]["server"], found[0]["terminal_id"])] == 1:
            current = attachment(found[0], item["harness"])
            if current:
                state["bindings"][key] = {**current, "event_at": item["event_at"]}
                continue
        still_bound = next((p for p in panes if binding and attachment(p, item["harness"]) == {k: binding[k] for k in ("server", "terminal", "pid", "start")}), None)
        if still_bound and not ((still_bound.get("agent_session") or {}).get("kind") == "id" and still_bound["agent_session"].get("value") != item["native_id"]):
            state["bindings"][key] = {**binding, "event_at": item["event_at"]}
            continue
        if item["surface"] != "herdr" or item["state"] == "read":
            continue
        reason = "bound server unavailable" if binding and binding["server"].split(":", 1)[0] in snapshot.get("unavailable", []) else "ambiguous identity" if found else "unidentified live process" if item["harness"] in unknown else "native metadata unavailable" if not binding and not item.get("verified_title") and item["harness"] == "codex" else ""
        if reason:
            if binding:
                state["bindings"][key] = binding
            deferred.append({"id": key[:10], "reason": reason})
            continue
        fingerprint = [item["event_at"], item["title"], item["cwd"], servers]
        missing = previous.get("missing", {}).get(key, {})
        first = missing.get("at", now) if missing.get("fingerprint") == fingerprint else now
        state["missing"][key] = {"fingerprint": fingerprint, "at": first}
        verified_exit = binding and binding["server"] in servers and binding["event_at"] == item["event_at"]
        if not verified_exit and (now - item["event_at"] < GRACE or now - first < GRACE):
            continue
        closed.append({"type": "closed", "host": item["host"], "harness": item["harness"], "native_id": item["native_id"],
                       "expected_event_at": item["event_at"], "at": now})
    return closed, state, deferred


def native(items: list[dict]) -> list[dict]:
    """Codex's own thread name and Desktop origin, from this host's state database."""
    from . import inbox

    for item in items:
        if item["harness"] == "codex":
            thread = inbox.codex_thread(item["native_id"])
            if thread and inbox.DESKTOP_APP and thread.get("originator") == "Codex Desktop":
                item["native_desktop"] = True
            item["verified_title"] = bool(thread and thread.get("name"))
            if item["verified_title"]:
                item["title"] = thread["name"]
                item["cwd"] = thread.get("cwd") or item["cwd"]
    return items


def exits(items: list[dict], previous: dict) -> dict:
    """For M1's pull from a host without a route to M1: plan exits here, return the state instead of writing it."""
    try:
        snapshot = inventory()
    except (OSError, ValueError, KeyError, RuntimeError, subprocess.SubprocessError) as error:
        return {"closed": [], "state": {"bindings": previous.get("bindings", {}), "missing": {}}, "herdr": str(error)[:300]}
    closed, state, deferred = plan(native(items), snapshot, previous, time.time())
    return {"closed": closed, "state": state, "deferred": deferred}


def reconcile(*, host: str, path: Path = STATE, dry_run: bool = False) -> dict:
    from . import inbox

    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    with path.with_suffix(".lock").open("a+") as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            return {"status": "complete", "busy": True}
        if not dry_run:
            inbox.flush(host=host)
        items = native(inbox.run("_sessions", host=host, keys=(host,))["items"])
        previous = json.loads(path.read_text()) if path.is_file() else {}
        now = time.time()
        try:
            snapshot = inventory()
        except (OSError, ValueError, KeyError, RuntimeError, subprocess.SubprocessError) as error:
            if not dry_run:
                atomic_json(path, {"bindings": previous.get("bindings", {}), "missing": {}})
            raise NotReady(str(error)) from error
        closed, state, deferred = plan(items, snapshot, previous, now)
        if not dry_run:
            for event in closed:
                inbox.spool(event)
            inbox.flush(host=host)
            atomic_json(path, state)
        return {"status": "complete", "dry_run": dry_run, "queued_closed": len(closed), "closed_ids": [inbox.session_key(e["host"], e["harness"], e["native_id"])[:10] for e in closed],
                "tracked": len(state["bindings"]), "observing_absence": len(state["missing"]), "deferred": deferred}
