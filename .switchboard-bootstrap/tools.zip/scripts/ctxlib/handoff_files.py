"""Select portable extra files with Git's ignore syntax and detect receiver edits."""

from __future__ import annotations

import os
from pathlib import Path, PurePosixPath
import stat
import subprocess
import tempfile

from .core import NotReady, digest_file, run_git

POLICY = ".ctxignore"


def read_policy(workspace: Path) -> str:
    path = workspace / POLICY
    if path.is_symlink() or not path.is_file():
        raise NotReady(f"{workspace} needs a regular {POLICY}; prepare it with the handoff skill's session steps first")
    try:
        body = path.read_text(encoding="utf-8")
    except (OSError, UnicodeError) as error:
        raise NotReady(f"cannot read {path}: {error}") from error
    if "\0" in body or len(body.encode()) > 65536:
        raise NotReady(f"{POLICY} must be UTF-8 text without NUL bytes, at most 64 KiB")
    return body


def allowed(policy: str, names: list[str]) -> list[str]:
    """Git handles parent-directory exclusions, escapes, globbing and rule order."""
    if not names:
        return []
    with tempfile.TemporaryDirectory(prefix="ctx-ignore-") as directory:
        root = Path(directory)
        run_git(root, "-c", "init.templateDir=", "init", "-q")
        (root / ".gitignore").write_text("*\n" + policy, encoding="utf-8")
        result = subprocess.run(
            ["git", "-C", directory, "-c", "core.excludesFile=/dev/null", "-c", "core.ignoreCase=false",
             "check-ignore", "--no-index", "--stdin", "-z"],
            input=os.fsencode("\0".join(names) + "\0"), capture_output=True, check=False,
        )
    if result.returncode not in (0, 1):
        raise NotReady("cannot interpret .ctxignore: " + result.stderr.decode(errors="replace").strip())
    ignored = set(os.fsdecode(result.stdout).split("\0"))
    return [name for name in names if name not in ignored]


def safe_path(workspace: Path, name: str) -> Path:
    parts = PurePosixPath(name).parts
    if not parts or name.startswith("/") or ".." in parts or ".git" in parts or "\0" in name:
        raise NotReady(f"invalid handoff file path: {name!r}")
    if parts[:2] == (".claude", "worktrees"):
        raise NotReady("handoff worktrees cannot be extra handoff files")
    path = workspace
    for part in parts[:-1]:
        path /= part
        if path.is_symlink() or (path.exists() and not path.is_dir()):
            raise NotReady(f"handoff file has a symlink or non-directory parent: {name}")
    return workspace / name


def fingerprint(workspace: Path, name: str) -> dict | None:
    path = safe_path(workspace, name)
    try:
        info = path.lstat()
    except FileNotFoundError:
        return None
    if stat.S_ISLNK(info.st_mode):
        return {"kind": "link", "target": os.readlink(path)}
    if not stat.S_ISREG(info.st_mode):
        raise NotReady(f"extra handoff file is not a regular file or symlink: {name}")
    return {"kind": "file", "sha256": digest_file(path), "mode": stat.S_IMODE(info.st_mode), "bytes": info.st_size}


def manifest(workspace: Path, policy: str, *, exclude=None) -> dict:
    """List ignored and untracked files, adding the policy as a mandatory control file."""
    names = os.fsdecode(run_git(workspace, "ls-files", "--others", "-z", "--exclude=/.claude/worktrees/")).split("\0")
    names = [name for name in names if name and name != POLICY]
    selected = allowed(policy, [name for name in names if exclude is None or not exclude(name)])
    files = {name: fingerprint(workspace, name) for name in sorted({POLICY, *selected})}
    if any(value is None for value in files.values()):
        raise NotReady("an extra handoff file disappeared while preparing the transfer")
    return files


def check(workspace: Path, incoming: dict, baseline: dict) -> None:
    conflicts = []
    for name, expected in incoming.items():
        current = fingerprint(workspace, name)
        if current is not None and current != expected and current != baseline.get(name):
            conflicts.append(name)
        elif current is None and name in baseline:
            conflicts.append(name)
    if conflicts:
        raise NotReady("extra files changed on the receiver; nothing applied: " + ", ".join(conflicts))


def verify(workspace: Path, expected: dict) -> None:
    changed = [name for name, value in expected.items() if fingerprint(workspace, name) != value]
    if changed:
        raise NotReady("handoff files changed or did not arrive intact: " + ", ".join(changed))
