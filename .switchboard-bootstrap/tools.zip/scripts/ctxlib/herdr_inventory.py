"""Authoritative local Herdr inventory, including foreground process incarnations."""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
import json
import os
from pathlib import Path
import subprocess

from .core import NotReady
from .herdr import _binary


def process_table() -> dict[int, dict]:
    """Every process, so any pane's foreground resolves; only the invoking user's clients count as harnesses,
    because on a shared host another account's `claude` is not one of this user's sessions."""
    result = subprocess.run(["ps", "-axo", "pid=,uid=,lstart=,tty=,command="], check=True,
                            capture_output=True, text=True, timeout=10)
    processes, own = {}, str(os.getuid())
    for line in result.stdout.splitlines():
        fields = line.split(None, 8)
        if len(fields) != 9:
            continue
        pid, uid, *date, tty, command = fields
        executable = Path(command.split()[0]).name
        harness = executable if executable in {"codex", "claude"} else ""
        if uid != own or tty in {"?", "??"} or any(word in command.split()[1:] for word in ("app-server", "exec", "mcp-server", "-p", "--print")):
            harness = ""
        processes[int(pid)] = {"pid": int(pid), "start": " ".join(date), "harness": harness}
    return processes


def inventory() -> dict:
    binary = _binary()
    if not binary:
        raise NotReady("Herdr is not installed")
    env = {k: v for k, v in os.environ.items() if k not in {"HERDR_SESSION", "HERDR_SOCKET_PATH", "HERDR_PANE_ID"}}

    def call(*args):
        result = subprocess.run([binary, *args], check=True, capture_output=True, text=True, timeout=10, env=env)
        return json.loads(result.stdout)

    sessions = call("session", "list", "--json")["sessions"]
    unavailable = [s["name"] for s in sessions if not s["running"]]
    sessions = [s for s in sessions if s["running"]]
    if not sessions:
        raise NotReady("No Herdr server is available; its absence is not an exit signal")
    processes = process_table()
    panes, servers = [], []
    for session in sessions:
        prefix = ["--session", session["name"]]
        socket = Path(session["socket_path"])
        before = socket.stat()
        server = f"{session['name']}:{before.st_dev}:{before.st_ino}"
        servers.append(server)
        snapshot = call(*prefix, "api", "snapshot")["result"]["snapshot"]
        snapshot["agents"] = call(*prefix, "agent", "list")["result"]["agents"]
        agents = {a["pane_id"]: a for a in snapshot["agents"]}

        def describe(pane):
            info = call(*prefix, "pane", "process-info", "--pane", pane["pane_id"])["result"]["process_info"]
            foreground = [processes.get(p["pid"]) for p in info["foreground_processes"]]
            if any(p is None for p in foreground):
                raise NotReady("Herdr processes changed during inventory; retry the snapshot")
            return {**pane, **agents.get(pane["pane_id"], {}), "server": server, "foreground": foreground}

        with ThreadPoolExecutor(max_workers=4) as pool:
            current = list(pool.map(describe, snapshot["panes"]))
        after = socket.stat()
        final = call(*prefix, "api", "snapshot")["result"]["snapshot"]
        final["agents"] = call(*prefix, "agent", "list")["result"]["agents"]
        def signature(value):
            identities = {a["pane_id"]: a for a in value["agents"]}
            return sorted((p["pane_id"], p["terminal_id"], json.dumps({k: identities.get(p["pane_id"], {}).get(k) for k in
                           ("agent", "agent_session", "terminal_title_stripped", "foreground_cwd")}, sort_keys=True)) for p in value["panes"])
        if (before.st_dev, before.st_ino) != (after.st_dev, after.st_ino) or signature(snapshot) != signature(final):
            raise NotReady("Herdr layout or identity changed during inventory; retry")
        panes.extend(current)
    final_processes = process_table()
    clients = lambda table: {(p["pid"], p["start"], p["harness"]) for p in table.values() if p["harness"]}
    if clients(processes) != clients(final_processes):
        raise NotReady("Interactive clients changed during inventory; retry")
    assigned = {p["pid"] for pane in panes for p in pane["foreground"]}
    outsiders = {p["harness"] for pid, p in processes.items() if p["harness"] and pid not in assigned}
    return {"panes": panes, "outsiders": outsiders, "servers": servers, "unavailable": unavailable}
