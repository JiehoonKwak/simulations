"""What a session did since a time, read from its native transcript on the host that owns it.

Stop enrichment stores the files and commits of each turn in the inbox; `ctx show` asks the owning
host for a running turn's progress. Only short derived lines leave the host: agent messages,
one-line actions, edited paths and commit subjects, never tool output.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
import re
import subprocess

from .dialogue import redact, shorten, timestamp_value

TAIL_BYTES = 8 * 1024 * 1024
COMMIT = re.compile(r"^\[([^\]\s]+)(?: \(root-commit\))? ([0-9a-f]{7,40})\] (.+)$", re.M)
EDIT_TOOLS = {"Edit", "Write", "MultiEdit", "NotebookEdit"}
CLAUDE_HOME = Path(os.environ.get("CLAUDE_CONFIG_DIR", Path.home() / ".claude"))
LIMITS = {"messages": 3, "actions": 10, "files": 50, "commits": 20}


def transcript(harness: str, native_id: str) -> Path | None:
    """The native transcript on this host: Claude's project JSONL or the Codex thread's rollout."""
    if harness == "claude":
        if not re.fullmatch(r"[0-9a-f-]{36}", native_id):
            return None
        matches = list((CLAUDE_HOME / "projects").glob(f"*/{native_id}.jsonl"))
        return matches[0] if len(matches) == 1 else None
    from .inbox import codex_thread

    rollout = (codex_thread(native_id) or {}).get("rollout_path")
    return Path(rollout) if rollout and Path(rollout).is_file() else None


def _records(path: Path):
    with path.open("rb") as handle:
        size = path.stat().st_size
        handle.seek(max(0, size - TAIL_BYTES))
        if size > TAIL_BYTES:
            handle.readline()
        for line in handle:
            try:
                record = json.loads(line)
            except (ValueError, UnicodeDecodeError):
                continue
            if isinstance(record, dict):
                yield record


def _home(path: str) -> str:
    return re.sub(r"^(/Users|/home|/var/services/homes|/volume1/homes)/[^/]+", "~", path)


def _line(text: str, width: int = 160) -> str:
    return shorten(redact(" ".join(str(text).split())), width)


def _command(text: str) -> str:
    """The first line of a shell command without a leading `cd DIR;` or `cd DIR &&`."""
    first = (text.strip().splitlines() or [""])[0]
    return "$ " + re.sub(r"^cd \S+ *(?:;|&&) *", "", first)


def _claude_action(block: dict) -> tuple[str, list[str]]:
    name, tool_input = block.get("name") or "tool", block.get("input") or {}
    if name in EDIT_TOOLS:
        path = tool_input.get("file_path") or tool_input.get("notebook_path") or ""
        return f"edit {_home(path)}", [path] if path else []
    if name == "Bash":
        return _command(str(tool_input.get("command", ""))), []
    for field in ("file_path", "pattern", "description", "url", "query", "skill", "prompt"):
        if tool_input.get(field):
            return f"{name} {_home(str(tool_input[field]))}", []
    return name, []


def _texts(content) -> str:
    if isinstance(content, str):
        return content
    return "\n".join(item.get("text", "") for item in content or [] if isinstance(item, dict) and isinstance(item.get("text"), str))


def _codex_action(item: dict) -> tuple[str, list[str]]:
    kind = item.get("type")
    if kind == "CommandExecution":
        command = item.get("command") or []
        return _command(str(command[-1] if isinstance(command, list) and command else command)), []
    if kind == "FileChange":
        paths = list(item.get("changes") or {})
        return "edit " + ", ".join(_home(path) for path in paths), paths
    if kind == "McpToolCall":
        title = (item.get("arguments") or {}).get("title") if isinstance(item.get("arguments"), dict) else ""
        return f"{item.get('server', '')}.{item.get('tool', '')} {title or ''}".strip(), []
    return "", []


def since(harness: str, path: Path, start: float) -> dict:
    """Agent messages, actions, edited files and commits recorded at or after `start` (epoch seconds)."""
    result = {"messages": [], "actions": [], "files": [], "commits": []}

    def add(name, value):
        if value and value not in result[name]:
            result[name].append(value)

    for record in _records(path):
        if timestamp_value(record.get("timestamp")) < start:
            continue
        outputs = []
        if harness == "claude":
            if record.get("isSidechain") or record.get("type") not in {"assistant", "user"}:
                continue
            content = (record.get("message") or {}).get("content")
            for block in content if isinstance(content, list) else []:
                if not isinstance(block, dict):
                    continue
                if record["type"] == "assistant" and block.get("type") == "text" and block.get("text", "").strip():
                    result["messages"].append(redact(block["text"].strip()))
                elif record["type"] == "assistant" and block.get("type") == "tool_use":
                    action, files = _claude_action(block)
                    result["actions"].append(_line(action))
                    for file in files:
                        add("files", file)
                elif block.get("type") == "tool_result":
                    outputs.append(_texts(block.get("content")))
        else:
            payload = record.get("payload") or {}
            if payload.get("type") != "item_completed":
                continue
            item = payload.get("item") or {}
            if item.get("type") == "AgentMessage":
                text = _texts(item.get("content")).strip()
                if text:
                    result["messages"].append(redact(text))
                continue
            action, files = _codex_action(item)
            if action:
                result["actions"].append(_line(action))
            for file in files:
                add("files", file)
            if item.get("type") == "CommandExecution":
                outputs.append(str(item.get("aggregated_output") or ""))
        for output in outputs:
            for branch, sha, subject in COMMIT.findall(output):
                add("commits", {"sha": sha[:10], "subject": _line(subject, 120), "branch": branch})
    for name, limit in LIMITS.items():
        result[name] = result[name][-limit:]
    result["files"] = [_home(path) for path in result["files"]]
    return result


def checkout(cwd: str) -> dict:
    """Branch and short HEAD of the session's directory, when it is a Git checkout."""
    try:
        head, branch = (subprocess.run(["git", "-C", cwd, *command], capture_output=True, text=True, timeout=3)
                        for command in (["rev-parse", "--short", "HEAD"], ["branch", "--show-current"]))
    except (OSError, subprocess.TimeoutExpired):
        return {}
    if head.returncode != 0:
        return {}
    return {"branch": branch.stdout.strip() or "detached", "head": head.stdout.strip()}
