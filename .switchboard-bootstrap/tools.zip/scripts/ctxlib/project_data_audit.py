"""Account for every current ctx registration without copying or probing NAS data."""
from __future__ import annotations

import json
import os
from collections import Counter
from pathlib import Path

from .core import NotReady, remote

SOURCE_ROOT = Path(__file__).resolve().parents[2]
DISPOSITIONS = {'managed', 'parent-covered', 'no-durable-data', 'runtime-config', 'stale', 'needs-review'}


def fresh_registry(ctx):
    if ctx.owns_registry():
        return ctx.registry(cached=False)
    return remote(ctx.config.registry_owner, ['ls', 'projects'], timeout=15)


def audit(ctx, *, scope_file=None, bindings_file=None):
    scope_path = Path(scope_file or os.environ.get('CTX_PROJECT_DATA_SCOPE', SOURCE_ROOT / 'config/project-data-scope.json'))
    bindings_path = Path(bindings_file or os.environ.get('CTX_PROJECT_DATA_BINDINGS', SOURCE_ROOT / 'config/project-data.json'))
    scope = json.loads(scope_path.read_text())
    if scope.get('schema_version') != 1 or not isinstance(scope.get('projects'), list):
        raise NotReady('project data scope requires schema_version 1 and a projects list')
    registry = fresh_registry(ctx)
    return account(registry, scope['projects'], json.loads(bindings_path.read_text()).get('projects', []))


def account(registry, decisions, bindings):
    """Separate classification coverage from unfinished decisions and publication."""
    projects = registry.get('projects', [])
    current = {item['id']: item for item in projects}
    chosen = {item['project']: item for item in decisions}
    configured = {item['project']: item for item in bindings}
    issues = []
    for name, rows, key in (('registry', projects, 'id'), ('scope', decisions, 'project'), ('bindings', bindings, 'project')):
        for identifier, count in Counter(item[key] for item in rows).items():
            if count > 1:
                issues.append({'project': identifier, 'reason': f'duplicate {name} entry'})
    for identifier in sorted(chosen.keys() - current.keys()):
        issues.append({'project': identifier, 'reason': 'scope decision no longer has a registry entry'})
    for identifier in sorted(configured.keys() - current.keys()):
        issues.append({'project': identifier, 'reason': 'data binding no longer has a registry entry'})
    results = []
    for identifier, project in current.items():
        decision = chosen.get(identifier, {})
        disposition = decision.get('disposition', 'unclassified')
        row_issues = []
        if disposition not in DISPOSITIONS:
            row_issues.append('missing or invalid disposition')
        if not isinstance(decision.get('reason'), str) or not decision['reason'].strip():
            row_issues.append('missing decision reason')
        evidence = decision.get('evidence', {})
        if not isinstance(evidence, dict) or not isinstance(evidence.get('summary'), str) or not evidence['summary'].strip():
            row_issues.append('missing evidence summary')
            evidence = {}
        if disposition in {'no-durable-data', 'stale'} and not {'m1pro', 'm3max'} <= set(evidence.get('hosts', [])):
            row_issues.append('both Mac observations required for this exclusion')
        if disposition == 'managed' and identifier not in configured:
            row_issues.append('managed project has no shared data binding')
        if identifier in configured and disposition != 'managed':
            row_issues.append('configured binding conflicts with scope disposition')
        owner = decision.get('owner')
        if disposition == 'parent-covered':
            if owner == identifier or owner not in current or owner not in configured or chosen.get(owner, {}).get('disposition') != 'managed':
                row_issues.append('parent-covered requires a current managed owner with a data binding')
            else:
                paths = project.get('paths', {})
                owner_paths = current[owner].get('paths', {})
                common_hosts = paths.keys() & owner_paths.keys()
                if not common_hosts or any(not Path(paths[host]).is_relative_to(Path(owner_paths[host])) or paths[host] == owner_paths[host] for host in common_hosts):
                    row_issues.append('parent-covered registration is not nested beneath its owner')
                else:
                    for host in common_hosts:
                        relative = Path(paths[host]).relative_to(Path(owner_paths[host])).as_posix()
                        if not any(selected == relative or selected.startswith(relative + '/') or relative.startswith(selected.rstrip('/') + '/') for selected in configured[owner].get('paths', [])):
                            row_issues.append('parent binding selects no data beneath the covered registration')
                            break
        elif owner:
            row_issues.append('owner applies only to parent-covered registrations')
        row = {'project': identifier, 'label': project.get('label', identifier),
               'disposition': disposition, 'reason': decision.get('reason', ''),
               'evidence': evidence, 'binding_configured': identifier in configured,
               'publication': 'not_checked', 'needs_review': disposition in {'needs-review', 'unclassified'}}
        if decision.get('warnings'):
            row['warnings'] = decision['warnings']
        if owner:
            row['owner'] = owner
        if row_issues:
            row['issues'] = row_issues
            issues.extend({'project': identifier, 'reason': reason} for reason in row_issues)
        results.append(row)
    pending = [row['project'] for row in results if row['needs_review'] or row.get('issues')]
    counts = dict(sorted(Counter(row['disposition'] for row in results).items()))
    complete = not issues and not pending
    return {'status': 'complete' if complete else 'not_ready',
            'reason': '' if complete else 'scope audit has unclassified, invalid or pending project decisions',
            'registry_revision': registry.get('revision', ''), 'registry_count': len(projects),
            'accounted_count': sum(row['disposition'] != 'unclassified' and not row.get('issues') for row in results),
            'coverage_complete': not issues, 'review_complete': complete,
            'binding_count': len(configured), 'publication': 'not_checked',
            'counts': counts, 'pending': pending, 'issues': issues, 'projects': results}
