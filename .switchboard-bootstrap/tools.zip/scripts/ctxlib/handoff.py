"""Continue a saved session on another host: copy its project files and native conversation over SSH, then resume it there.

Unmanaged projects transfer directly. Opt-in project data is pinned and prepared separately.
The destination keeps a record per handoff so that a later push from
the received workspace returns the work into the original checkout when that checkout is unchanged.
"""

from __future__ import annotations

import json
import os
import shlex
import shutil
import subprocess
import sys
import tempfile
import time
import uuid
from pathlib import Path, PurePosixPath

from . import claude, codex, herdr, handoff_files, project_data
from .core import NotReady, atomic_json, component, digest_file, remote, run_git

SSH = "ssh -o BatchMode=yes -o ConnectTimeout=5"
LINK_DESTS = 5
LARGE_TRANSFER = 200 * 1024 * 1024
ESTIMATED_RATE = 70 * 1024 * 1024


def _git(root, *args) -> str:
    return run_git(Path(root), *args).decode().strip()


def runtime_roots(ctx) -> list[Path]:
    """Runtime and credential stores, which are never project workspaces."""
    home = Path(ctx.config.native_home or Path.home()).expanduser().resolve()
    protected = [home / name for name in (
        ".codex", ".claude", ".ssh", ".gnupg",
        "Library/Application Support", "Library/Containers", "Library/Group Containers",
        "Library/Keychains", "Library/Safari", ".mozilla",
        ".config/BraveSoftware", ".config/google-chrome", ".config/chromium",
    )]
    protected += [codex.native_root(ctx.config.native_home), claude.native_root(ctx.config.native_home), ctx.config.state]
    return [root.expanduser().resolve() for root in protected]


def _guard_workspace(ctx, *paths) -> None:
    protected = runtime_roots(ctx)
    for path in paths:
        workspace = Path(path).expanduser().resolve()
        for root in protected:
            if workspace.is_relative_to(root) or root.is_relative_to(workspace):
                raise NotReady(f"{workspace} overlaps host-local runtime or credentials ({root}); "
                               "handoff a separate source repository instead")


def _snapshot(workspace) -> dict:
    """Name the tracked working state as a commit on HEAD without touching the branch, index or stash list."""
    head = _git(workspace, "rev-parse", "HEAD")
    with tempfile.TemporaryDirectory(prefix="ctx-index-") as directory:
        index = Path(directory) / "index"
        shutil.copyfile(_git(workspace, "rev-parse", "--path-format=absolute", "--git-path", "index"), index)
        environment = {**os.environ, "GIT_INDEX_FILE": str(index)}
        for command in (["add", "-u", "--", ":/"], ["write-tree"]):
            result = subprocess.run(["git", "-C", str(workspace), *command], capture_output=True, text=True, env=environment, check=False)
            if result.returncode:
                raise NotReady(result.stderr.strip() or "Git could not record the working tree")
    tree = result.stdout.strip()
    if tree == _git(workspace, "rev-parse", "HEAD^{tree}"):
        return {"head": head, "commit": head, "tree": tree}
    commit = _git(workspace, "-c", "user.name=ctx", "-c", "user.email=ctx@localhost", "commit-tree", tree, "-p", head, "-m", "ctx handoff snapshot")
    return {"head": head, "commit": commit, "tree": tree}


def _workspace(ctx, workspace=None) -> tuple[Path, Path]:
    path = Path(workspace or Path.cwd()).expanduser().resolve()
    _guard_workspace(ctx, path)
    path = Path(_git(path, "rev-parse", "--show-toplevel")).resolve()
    common = Path(_git(path, "rev-parse", "--path-format=absolute", "--git-common-dir"))
    _guard_workspace(ctx, path, common.parent)
    return path, common


def files(ctx, workspace=None) -> dict:
    path, _ = _workspace(ctx, workspace)
    policy = handoff_files.read_policy(path)
    config = project_data.binding(ctx, path)
    selected = handoff_files.manifest(path, policy, exclude=lambda name: config is not None and project_data.manages(config, name))
    return {"status": "complete", "workspace": str(path), "policy": handoff_files.POLICY,
            "files": [{"path": name, "bytes": value.get("bytes", 0)} for name, value in selected.items()],
            "bytes": sum(value.get("bytes", 0) for value in selected.values())}


def _records(ctx) -> list[dict]:
    paths = (ctx.config.state / "handoffs").glob("*.json")
    return sorted((json.loads(path.read_text()) for path in paths), key=lambda record: record["at"])


def _last(ctx, workspace) -> dict | None:
    return next((record for record in reversed(_records(ctx)) if record["workspace"] == str(workspace)), None)


def _address(host, path) -> str:
    return f"{host}:{path}"


def _call(host, phase, payload) -> dict:
    return remote(host, ["handoff", "_receive", phase], payload, timeout=600)


def _rsync(options, source, host, target) -> str:
    command = ["rsync", "-a", "--prune-empty-dirs", "-e", SSH, *options, str(source).rstrip("/") + "/", _address(host, str(target).rstrip("/") + "/")]
    result = subprocess.run(command, stdin=subprocess.DEVNULL, capture_output=True, text=True, check=False)
    if result.returncode:
        raise NotReady("file copy to " + host + " failed: " + (result.stderr.strip() or "rsync exit " + str(result.returncode)))
    return result.stdout


def _native_path(base, name, subtrees) -> Path:
    """Confine a native file name from a handoff payload to the harness's session subtrees under `base`.

    The name is peer-provided, so it must be a canonical relative path inside one allowed subtree,
    with no symlinked or non-directory component and no existing non-file at the end."""
    parts = PurePosixPath(name).parts if isinstance(name, str) else ()
    if (len(parts) < 2 or "\0" in name or name != PurePosixPath(name).as_posix() or name.startswith("/")
            or parts[0] not in subtrees or any(part in {".", ".."} for part in parts)):
        raise NotReady(f"native conversation path is outside the allowed native subtrees: {name!r}")
    base = Path(base)
    path = base
    for part in parts[:-1]:
        path /= part
        if path.is_symlink() or (path.exists() and not path.is_dir()):
            raise NotReady(f"native conversation path has a symlink or non-directory parent: {name}")
    path /= parts[-1]
    if path.is_symlink() or (path.exists() and not path.is_file()):
        raise NotReady(f"native conversation path is not a regular file: {name}")
    if not path.resolve().is_relative_to((base / parts[0]).resolve()):
        raise NotReady(f"native conversation path resolves outside its subtree: {name}")
    return path


def _native(ctx, adapter, plan) -> tuple[list[dict], int]:
    """Select captured files that a receiver will accept; the rest count as skipped attachments."""
    root = adapter.native_root(ctx.config.native_home).resolve()
    files, outside = [], 0
    for entry in plan["files"]:
        source = Path(entry["source"])
        try:
            relative = source.resolve().relative_to(root)
            _native_path(root, relative.as_posix(), adapter.NATIVE_SUBTREES)
        except (ValueError, NotReady):
            outside += 1
            continue
        files.append({"path": str(relative), "source": str(source), "bytes": entry.get("byte_count", source.stat().st_size)})
    return files, outside


def _stage_native(native, existing, stage, host) -> None:
    """Copy each saved prefix; the destination copy must be a prefix of it, or the conversation diverged there."""
    for item in native:
        target = stage / item["path"]
        target.parent.mkdir(parents=True, exist_ok=True)
        with open(item["source"], "rb") as source, open(target, "wb") as output:
            remaining = item["bytes"]
            while remaining:
                block = source.read(min(remaining, 1 << 20))
                if not block:
                    raise NotReady("native conversation file shrank during handoff: " + item["path"])
                output.write(block)
                remaining -= len(block)
        known = existing.get(item["path"])
        if known and (known["size"] > item["bytes"] or digest_file(target, limit=known["size"]) != known["sha256"]):
            raise NotReady(f"{host} holds a different copy of this conversation ({item['path']}); "
                           "it continued there after the last handoff. Hand it back from there first")


def push(ctx, *, destination=None, harness=None, session=None, workspace=None, data_ticket=None) -> dict:
    """Hand the saved session and its workspace to `destination`; return safe_to_close once it resumed there."""
    started = time.monotonic()
    workspace, common = _workspace(ctx, workspace)
    policy = handoff_files.read_policy(workspace)
    previous = _last(ctx, workspace)
    selected_ticket = data_ticket
    if selected_ticket is None and (previous or {}).get("direction") == "received":
        selected_ticket = previous.get("data_ticket")
    data = project_data.handoff_state(ctx, workspace, ticket=selected_ticket)
    selected_files = handoff_files.manifest(workspace, policy, exclude=lambda name: data is not None and project_data.manages(data["config"], name))
    origin = previous.get("origin") if previous and previous["direction"] == "received" else None
    destination = component(destination or (origin or {}).get("host") or ctx.config.peers[0])
    if destination == ctx.config.host:
        raise ValueError("choose another host with --to; this is " + destination)
    selected = ctx.select_session(session, harness, {"paths": {ctx.config.host: str(workspace)}})
    adapter = ctx.adapter(selected["harness"])
    plan = adapter.capture(selected["native_id"], home=ctx.config.native_home, require_saved_boundary=True)
    if not plan.get("saved_boundary", {}).get("ready"):
        raise NotReady(plan.get("saved_boundary", {}).get("reason") or "the session has no saved boundary")
    native, outside = _native(ctx, adapter, plan)
    root = (origin or {}).get("root") or str(common.parent)
    identity = uuid.uuid4().hex[:12]
    payload = {"handoff_id": identity, "from": ctx.config.host, "harness": selected["harness"], "native_id": selected["native_id"],
               "root": root, "workspace": str(workspace), **_snapshot(workspace), "origin": origin,
               "native": [item["path"] for item in native], "departed_at": time.time(),
               "file_protocol": 1, "policy": policy, "files": selected_files}
    if data is not None:
        payload["project_data"] = data
        _peer_capabilities(_call(destination, "check", payload), managed=True)
    adapter.release(selected["native_id"], home=ctx.config.native_home)
    plan = adapter.capture(selected["native_id"], home=ctx.config.native_home, require_saved_boundary=True)
    if not plan.get("saved_boundary", {}).get("ready"):
        raise NotReady(plan.get("saved_boundary", {}).get("reason") or "the session has no saved boundary after shutdown")
    if data is not None and project_data.handoff_state(ctx, workspace, ticket=selected_ticket) != data:
        raise NotReady("managed data changed while stopping the source; prepare the handoff again")
    native, outside = _native(ctx, adapter, plan)
    payload.update(_snapshot(workspace))
    payload["native"] = [item["path"] for item in native]
    reply = _call(destination, "check", payload)
    _peer_capabilities(reply, managed=data is not None)
    target, links = reply["target"], [option for path in reply["link_dests"] for option in ("--copy-dest", path)]
    with tempfile.TemporaryDirectory(prefix="handoff-", dir=ctx.config.state) as directory:
        stage, listing = Path(directory) / "native", Path(directory) / "files.list"
        stage.mkdir()
        _stage_native(native, reply["native"], stage, destination)
        listing.write_bytes(os.fsencode("\0".join(selected_files) + "\0"))
        size = sum(value.get("bytes", 0) for value in selected_files.values())
        if size > LARGE_TRANSFER:
            print(f"Copying up to {size / 1e9:.1f} GB of allowed project files to {destination} "
                  f"(about {size / ESTIMATED_RATE / 60:.0f} min)...", file=sys.stderr, flush=True)
        _rsync([*links, "--checksum", "--from0", "--files-from=" + str(listing), "--no-implied-dirs"],
               workspace, destination, reply["incoming"] + "/project")
        _rsync([], stage, destination, reply["incoming"] + "/native")
        environment = {**os.environ, "GIT_SSH_COMMAND": SSH}
        pushed = subprocess.run(["git", "-C", str(workspace), "push", "-q", "--no-verify", _address(destination, root),
                                 payload["commit"] + ":refs/ctx/handoff/" + identity], capture_output=True, text=True, env=environment, check=False)
        if pushed.returncode:
            raise NotReady("Git transfer to " + destination + " failed: " + pushed.stderr.strip())
        _call(destination, "apply", {**payload, "mode": reply["mode"], "target": target})
    delivery = _call(destination, "launch", {**payload, "mode": reply["mode"], "target": target})
    launched = delivery["launch"]
    data_fields = {"project_data": data, "data_ticket": delivery.get("data_ticket")} if data is not None else {}
    atomic_json(ctx.config.state / "handoffs" / (identity + ".json"),
                {"handoff_id": identity, "direction": "sent", "host": ctx.config.host, "peer": destination,
                 "harness": selected["harness"], "native_id": selected["native_id"], "workspace": str(workspace),
                 "tree": payload["tree"], "files": selected_files, "target": target, "mode": reply["mode"], "at": time.time(), **data_fields})
    return {"status": "complete" if launched.get("status") == "started" else "transferred", "handoff_id": identity,
            "source_safe_to_close": True, "destination": destination, "workspace": target, "mode": reply["mode"],
            "note": reply.get("note"), "skipped_attachments": outside,
            "missing": plan.get("missing", []), "elapsed_seconds": time.monotonic() - started,
            **data_fields,
            **{key: launched.get(key) for key in ("native_id", "url", "mobile_url", "reason", "resume_command", "viewer") if launched.get(key)}}


def _peer_capabilities(reply, *, managed) -> None:
    if reply.get("file_protocol") != 1:
        raise NotReady("receiving ctx does not support .ctxignore; update ctx on both hosts")
    if managed and reply.get("data_protocol") != 1:
        raise NotReady("receiving ctx does not support managed project data; update ctx on both hosts")


def receive(ctx, phase, payload) -> dict:
    phases = {"check": _check, "apply": _apply, "launch": _launch}
    if phase not in phases:
        raise ValueError("unknown handoff phase " + phase)
    _guard_workspace(ctx, payload["root"], *([payload["target"]] if "target" in payload else []))
    return phases[phase](ctx, payload)


def _worktree(root, native_id) -> Path:
    """Name it by the ID's random tail; Codex IDs begin with a timestamp that nearby sessions share."""
    return Path(root) / ".claude" / "worktrees" / ("handoff-" + native_id.replace("-", "")[-8:])


def _in_place(ctx, payload) -> tuple[Path | None, str | None]:
    origin = payload.get("origin")
    if not origin or origin["host"] != ctx.config.host:
        return None, None
    place = Path(origin["workspace"])
    _guard_workspace(ctx, place)
    if place.is_dir():
        state = _snapshot(place)
        if (state["head"], state["tree"]) == (origin["head"], origin["tree"]):
            return place, None
    return None, f"{place} changed after the work left it; received into a separate worktree instead"


def _check(ctx, payload) -> dict:
    root = Path(payload["root"])
    if not (root / ".git").exists():
        raise NotReady(f"{root} is not a Git checkout on {ctx.config.host}; clone it there first")
    data = payload.get("project_data")
    if not project_data.check_handoff(ctx, data, root):
        raise NotReady("handoff project-data binding does not match the receiver")
    adapter = ctx.adapter(payload["harness"])
    held = adapter.holder(payload["native_id"], home=ctx.config.native_home)
    if held:
        raise NotReady(ctx.config.host + ": " + held)
    place, note = _in_place(ctx, payload)
    target = place or _worktree(root, payload["native_id"])
    _guard_workspace(ctx, target)
    if payload.get("file_protocol") != 1 or "policy" not in payload or handoff_files.POLICY not in payload.get("files", {}):
        raise NotReady("handoff peer needs the .ctxignore file protocol; update ctx on both hosts")
    names = [name for name in payload["files"] if name != handoff_files.POLICY]
    if handoff_files.allowed(payload["policy"], names) != names:
        raise NotReady("handoff contains extra files not allowed by .ctxignore")
    if data is not None and any(project_data.manages(data["config"], name) for name in names):
        raise NotReady("managed project data cannot be ordinary handoff extras")
    last = _last(ctx, target) if target.exists() else None
    if not place and target.exists():
        if not last or _snapshot(target)["tree"] != last["tree"]:
            raise NotReady(f"{target} on {ctx.config.host} has changes that were never handed back; hand them back or remove that worktree first")
    baseline = payload["origin"].get("files", {}) if place else (last or {}).get("files", {})
    handoff_files.check(target, payload["files"], baseline)
    native_root = adapter.native_root(ctx.config.native_home)
    native = {path: _native_path(native_root, path, adapter.NATIVE_SUBTREES) for path in payload["native"]}
    existing = {path: {"size": local.stat().st_size, "sha256": digest_file(local)}
                for path, local in native.items() if local.is_file()}
    siblings = [path for path in (root / ".claude" / "worktrees").glob("handoff-*") if path.is_dir() and path != target]
    links = [] if place else sorted(siblings, key=lambda path: path.stat().st_mtime, reverse=True)[:LINK_DESTS]
    if target.is_dir():
        links.insert(0, target)
    incoming = ctx.config.state / "incoming" / component(payload["handoff_id"])
    for name in ("project", "native"):
        (incoming / name).mkdir(parents=True, exist_ok=True, mode=0o700)
    return {"status": "complete", "file_protocol": 1, "data_protocol": 1, "mode": "in_place" if place else "worktree", "target": str(target), "note": note,
            "link_dests": [str(path) for path in links], "native": existing,
            "incoming": str(incoming)}


def _apply(ctx, payload) -> dict:
    target, reference = Path(payload["target"]), "refs/ctx/handoff/" + component(payload["handoff_id"])
    checked = _check(ctx, payload)
    if checked["target"] != str(target) or checked["mode"] != payload["mode"]:
        raise NotReady("handoff destination changed during transfer; nothing applied")
    incoming = Path(checked["incoming"]) / "project"
    handoff_files.verify(incoming, payload["files"])
    if handoff_files.read_policy(incoming) != payload["policy"]:
        raise NotReady("the transferred .ctxignore does not match the checked policy")
    if payload["mode"] == "in_place":
        place, _ = _in_place(ctx, payload)
        if place != target:
            raise NotReady(f"{target} changed during the handoff; nothing was applied")
        _git(target, "update-ref", reference + "-before", _snapshot(target)["commit"])
    elif not target.exists():
        root = Path(payload["root"])
        exclude = Path(_git(root, "rev-parse", "--path-format=absolute", "--git-path", "info/exclude"))
        if subprocess.run(["git", "-C", str(root), "check-ignore", "-q", ".claude/worktrees/x"], check=False).returncode:
            exclude.parent.mkdir(parents=True, exist_ok=True)
            with exclude.open("a") as handle:
                handle.write("\n.claude/worktrees/\n")
        _git(root, "worktree", "add", "-q", "-B", target.name, str(target), payload["head"])
    _git(target, "reset", "-q", "--hard", payload["head"])
    if payload["commit"] != payload["head"]:
        _git(target, "restore", "--source", payload["commit"], "--worktree", "--", ".")
    for name in payload["files"]:
        destination = handoff_files.safe_path(target, name)
        destination.parent.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(prefix=".ctx-handoff-", dir=destination.parent) as directory:
            temporary = Path(directory) / "file"
            shutil.copy2(incoming / name, temporary, follow_symlinks=False)
            os.replace(temporary, destination)
    _git(target, "update-ref", "-d", reference)
    _receipt(ctx, payload, target)
    return {"status": "complete", "target": str(target)}


def _receipt(ctx, payload, target, **extra) -> None:
    """Record what this host received, so a retry, a repeat handoff or a return can check against it."""
    atomic_json(ctx.config.state / "handoffs" / (component(payload["handoff_id"]) + ".json"),
                {"handoff_id": payload["handoff_id"], "direction": "received", "host": ctx.config.host, "peer": payload["from"],
                 "harness": payload["harness"], "native_id": payload["native_id"], "workspace": str(target),
                 "tree": _snapshot(target)["tree"], "files": payload["files"], "mode": payload["mode"], "at": time.time(), **extra,
                 **({"project_data": payload["project_data"]} if payload.get("project_data") is not None else {}),
                 "origin": {"host": payload["from"], "workspace": payload["workspace"], "root": payload["root"],
                            "head": payload["head"], "tree": payload["tree"], "files": payload["files"], "departed_at": payload["departed_at"]}})


def _prompt(ctx, payload) -> str:
    place = ("the original checkout; the returned changes were applied there" if payload["mode"] == "in_place"
             else "a Git worktree on branch " + Path(payload["target"]).name + "; commit there")
    data = payload.get("data_ticket")
    prepared = (f" Managed project data is pinned at revision {data['revision']} in {data['workspace']}; "
                "use that external data workspace for managed inputs and outputs. " if data else "")
    return (f"Handoff {payload['handoff_id']}: this conversation moved from {payload['from']} ({payload['workspace']}) "
            f"to {ctx.config.host}. Continue in {payload['target']}, {place}. Tracked changes and the untracked and ignored "
            "project files allowed by .ctxignore were copied; other extra files were left on their host. "
            "Running processes were not copied; recreate environments such as .venv if you need them. A file that seems missing may be "
            "excluded by the project's .ctxignore. "
            f"{prepared}Reply with one short line confirming where you are, then wait for the user's next message.")


def _launch(ctx, payload) -> dict:
    target = Path(payload["target"])
    data = payload.get("project_data")
    ticket = None
    if not project_data.check_handoff(ctx, data, target):
        raise NotReady("handoff project-data binding does not match the receiver")
    if data is not None:
        selection = {'selected_paths': data['selected_paths']} if 'selected_paths' in data else {}
        ticket = project_data.prepare(ctx, target, "handoff-" + component(payload["handoff_id"]), pinned=data, **selection)
        if ticket is None:
            raise NotReady("managed project data was not prepared; native session was not launched")
        payload = {**payload, "data_ticket": ticket}
        _receipt(ctx, payload, target, data_ticket=ticket)
    adapter = ctx.adapter(payload["harness"])
    native_root = adapter.native_root(ctx.config.native_home)
    incoming = ctx.config.state / "incoming" / component(payload["handoff_id"]) / "native"
    moves = [(_native_path(incoming, path, adapter.NATIVE_SUBTREES), _native_path(native_root, path, adapter.NATIVE_SUBTREES))
             for path in payload["native"]]
    for path, (source, _) in zip(payload["native"], moves):
        if not source.is_file():
            raise NotReady("conversation file did not arrive: " + path)
    for source, destination in moves:
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(source), str(destination))
    shutil.rmtree(incoming, ignore_errors=True)
    shutil.rmtree(incoming.parent, ignore_errors=True)
    adapter.release(payload["native_id"], home=ctx.config.native_home)
    result = adapter.launch(target, _prompt(ctx, payload), home=ctx.config.native_home, resume=payload["native_id"])
    if result.get("status") == "started" and result.get("attach_command"):
        repository = Path(run_git(target, "rev-parse", "--path-format=absolute", "--git-common-dir").decode().strip()).parent.name
        result["viewer"] = herdr.show(result["attach_command"], target, "handoff " + payload["handoff_id"][:8], repository)
    else:
        result["resume_command"] = (f"cd {shlex.quote(str(target))} && " +
                                    ("claude --resume " if payload["harness"] == "claude" else "codex resume ") + payload["native_id"])
    _receipt(ctx, payload, target, launch=result, **({"data_ticket": ticket} if ticket is not None else {}))
    return {"status": "complete", "launch": result, **({"data_ticket": ticket} if ticket is not None else {})}


def pull(ctx, identity=None) -> dict:
    """Ask the host that received this host's latest (or the named) handoff to push it back here."""
    records = _records(ctx)
    sent = [record for record in records if record["direction"] == "sent" and identity in (None, record["handoff_id"])]
    if not sent:
        raise NotReady("no handoff was sent from this host" + (" with ID " + identity if identity else ""))
    record = sent[-1]
    if any(other["direction"] == "received" and other["native_id"] == record["native_id"] and other["at"] > record["at"] for other in records):
        raise NotReady("handoff " + record["handoff_id"] + " already came back to this host")
    command = ["handoff", "push", "--to", ctx.config.host, "--workspace", record["target"],
               "--session", record["native_id"], "--harness", record["harness"]]
    return remote(record["peer"], command, timeout=3600)


def listing(ctx, limit=30) -> dict:
    return {"status": "complete", "handoffs": list(reversed(_records(ctx)))[:limit]}
