"""Project identity, native session selection, and the small ctx caller boundary."""

from __future__ import annotations

from dataclasses import dataclass, field
import hashlib
import importlib
import json
import math
import os
from pathlib import Path
import re
import shlex
import socket
import subprocess
import sys
import tempfile
import time
import tomllib
import uuid


class NotReady(RuntimeError):
    pass


class ProjectNotRegistered(NotReady):
    pass


class ProjectDiscoveryUnavailable(NotReady):
    pass


HOSTS = ("m3max", "m1pro")


def component(value: str) -> str:
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,127}", value):
        raise ValueError("identity must use letters, numbers, dots, dashes or underscores")
    return value


def host_alias() -> str:
    hostname = socket.gethostname().split(".", 1)[0]
    return {"jiehoonk-mac-m3max": "m3max", "jiehoonk-mac-m1pro": "m1pro", "jjhouse": "nas", "tnl-b": "bv"}.get(hostname, hostname)


def canonical(value) -> bytes:
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode()


def digest_file(path: Path, *, limit: int | None = None) -> str:
    result = hashlib.sha256()
    with path.open("rb") as handle:
        remaining = limit
        while remaining is None or remaining > 0:
            block = handle.read(1024 * 1024 if remaining is None else min(remaining, 1024 * 1024))
            if not block:
                break
            result.update(block)
            if remaining is not None:
                remaining -= len(block)
        if remaining:
            raise ValueError("file is shorter than its recorded prefix")
    return result.hexdigest()


def atomic_write(path: Path, body: bytes, mode=0o600) -> None:
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    descriptor, name = tempfile.mkstemp(prefix=".ctx-", dir=path.parent)
    try:
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(body)
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(name, mode)
        os.replace(name, path)
    finally:
        if os.path.exists(name):
            os.unlink(name)


def atomic_json(path: Path, value) -> None:
    atomic_write(path, canonical(value) + b"\n")


def run_git(root: Path, *args: str, deadline: float | None = None, data=None) -> bytes:
    timeout = max(0.01, deadline - time.monotonic()) if deadline is not None else 120
    result = subprocess.run(["git", "-C", str(root), *args], input=data, stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE, timeout=timeout)
    if result.returncode:
        raise NotReady(result.stderr.decode(errors="replace").strip() or "Git operation failed")
    return result.stdout


def primary_checkout(cwd: str | Path) -> Path | None:
    """The main checkout of the repository containing cwd; worktrees count toward their repository."""
    path = Path(cwd)
    if not path.is_dir():
        return None
    deadline = time.monotonic() + 2
    git = lambda *args: run_git(path, *args, deadline=deadline).decode().strip()
    try:
        own, common = git("rev-parse", "--absolute-git-dir"), git("rev-parse", "--path-format=absolute", "--git-common-dir")
        if Path(own).resolve() == Path(common).resolve():
            return None if git("rev-parse", "--is-bare-repository") == "true" else Path(git("rev-parse", "--show-toplevel")).resolve()
        main = git("worktree", "list", "--porcelain").splitlines()[0].removeprefix("worktree ")
        if Path(main).resolve() == Path(common).resolve():
            main = run_git(Path(common), "config", "core.worktree", deadline=deadline).decode().strip()
    except (NotReady, OSError, subprocess.TimeoutExpired, IndexError):
        return None
    return Path(main).resolve() if main and Path(main).is_dir() else None


def remote(host, args, payload=None, timeout=120):
    """Run a ctx subcommand on another host with a JSON payload on stdin; raise its not_ready reason.

    `args` is the argument list after `ctx`; each word is shell-quoted because ssh hands the
    remote command to a shell, so a value can never add words or shell syntax there."""
    if isinstance(args, str):
        raise TypeError("remote() takes an argument list, not a command string")
    command = '"$HOME/.local/bin/ctx" ' + shlex.join([*args, "--json"])
    result = subprocess.run(["ssh", "-o", "BatchMode=yes", "-o", "ConnectTimeout=5", host, command],
                            input=canonical(payload) if payload is not None else None, capture_output=True, timeout=timeout)
    try:
        value = json.loads(result.stdout)
    except ValueError:
        raise NotReady(f"{host} ctx did not answer: " + (result.stderr.decode(errors="replace").strip() or "no output")) from None
    if value.get("status") == "not_ready":
        raise NotReady(f"{host}: " + value.get("reason", "not ready"))
    return value


@dataclass
class Config:
    state: Path = Path.home() / ".local/share/ctx"
    host: str = ""
    native_home: Path | None = None
    registry_owner: str = "m1pro"
    peers: tuple = field(default=None)

    def __post_init__(self):
        self.state = Path(self.state).expanduser()
        self.host = component(self.host or host_alias())
        if self.peers is None:
            self.peers = tuple(host for host in HOSTS if host != self.host) if self.host in HOSTS else ()
        self.state.mkdir(parents=True, exist_ok=True, mode=0o700)


def registry_text(value: dict) -> str:
    quote = lambda item: json.dumps(item, ensure_ascii=False)
    lines = ["schema_version = 1", "revision = " + quote(value.get("revision", "")), ""]
    for project in value.get("projects", []):
        lines.append("[[projects]]")
        for key in ("id", "repo_id", "origin"):
            lines.append(f"{key} = {quote(project.get(key, ''))}")
        lines.append("mode = " + quote(project.get("mode", "workspace")))
        lines.append("label = " + quote(project.get("label", project["id"])))
        lines.append("aliases = " + quote(project.get("aliases", [])))
        if project.get("git_owner"):
            lines.append("git_owner = " + quote(project["git_owner"]))
        paths = ", ".join(quote(key) + " = " + quote(path) for key, path in project["paths"].items())
        lines.append("paths = { " + paths + " }")
        lines.append("")
    return "\n".join(lines)


class Context:
    def __init__(self, config: Config):
        self.config = config
        self._project_discovery = {}
        self._assignments = {}

    @property
    def index_path(self) -> Path:
        return self.config.state / "index.sqlite"

    def owns_registry(self) -> bool:
        return self.config.host == self.config.registry_owner

    def registry(self, *, cached: bool = False) -> dict:
        """M1 owns registry.toml; the other Mac reads it over SSH and keeps the last copy for offline use.
        Hosts outside HOSTS (NAS) cannot reach the owner and use only a copy placed there, if any."""
        path = self.config.state / "registry.toml"
        if self.owns_registry() or (cached and path.exists()) or self.config.host not in HOSTS:
            return tomllib.loads(path.read_text()) if path.exists() else {"schema_version": 1, "revision": "", "projects": []}
        try:
            value = remote(self.config.registry_owner, ["ls", "projects"], timeout=15)
        except (NotReady, OSError, subprocess.TimeoutExpired) as error:
            if path.exists():
                return tomllib.loads(path.read_text())
            raise NotReady(f"registry owner {self.config.registry_owner} unreachable and no cached registry: {error}") from None
        value = {"schema_version": 1, "revision": value.get("revision", ""), "projects": value.get("projects", [])}
        atomic_write(path, registry_text(value).encode())
        return value

    def receive_registry(self, value: dict) -> dict:
        """Store the registry copy a Mac pushes to a host outside HOSTS before asking it for places."""
        if self.config.host in HOSTS:
            raise NotReady("Macs read the registry from its owner")
        text = registry_text({"schema_version": 1, "revision": value.get("revision", ""), "projects": value.get("projects", [])}).encode()
        path = self.config.state / "registry.toml"
        if not path.exists() or path.read_bytes() != text:
            atomic_write(path, text)
        return {"status": "complete", "revision": value.get("revision", "")}

    def register(self, root: str, project_id: str, *, mode="workspace", label=None, aliases=(), promote=False,
                 git_owner=None) -> dict:
        root_path = Path(root).expanduser().resolve()
        if mode not in {"workspace", "catalog"}:
            raise ValueError("project mode must be workspace or catalog")
        origin = ""
        if mode == "workspace":
            actual = Path(run_git(root_path, "rev-parse", "--show-toplevel").decode().strip()).resolve()
            if actual != root_path:
                raise ValueError("register the verified repository/workspace root, not a nested directory")
            try:
                origin = run_git(root_path, "remote", "get-url", "origin").decode().strip()
            except NotReady:
                pass
        if "://" in origin:
            from urllib.parse import urlsplit, urlunsplit
            parsed = urlsplit(origin)
            origin = urlunsplit((parsed.scheme, parsed.hostname or "", parsed.path, "", ""))
        entry = {"id": component(project_id), "paths": {self.config.host: str(root_path)},
                 "mode": mode, "label": label or project_id, "aliases": list(aliases), "promote": promote,
                 "origin": origin, **({"git_owner": component(git_owner)} if git_owner else {})}
        if not self.owns_registry():
            result = remote(self.config.registry_owner, ["_register"], entry, timeout=30)
            self.registry()
            return result
        return self.register_entry(entry)

    def register_entry(self, entry: dict) -> dict:
        if not self.owns_registry():
            raise NotReady(f"registry edits are owned by {self.config.registry_owner}")
        component(entry["id"])
        mode = entry.get("mode", "workspace")
        if mode not in {"workspace", "catalog"}:
            raise ValueError("project mode must be workspace or catalog")
        if not entry.get("paths"):
            raise ValueError("project requires at least one host path")
        for host, path in entry["paths"].items():
            component(host)
            if not Path(path).is_absolute():
                raise ValueError("project mappings must be absolute")
        label = entry.get("label", entry["id"])
        aliases = entry.get("aliases", [])
        if not isinstance(label, str) or not label or not isinstance(aliases, list) or any(
                not isinstance(alias, str) or not alias for alias in aliases):
            raise ValueError("project label and aliases must be nonempty strings")
        if entry.get("git_owner"):
            component(entry["git_owner"])
        import fcntl
        with (self.config.state / "registry.lock").open("a+") as handle:
            fcntl.flock(handle, fcntl.LOCK_EX)
            registry = self.registry()
            matches = [item for item in registry["projects"] if item["id"] == entry["id"] or any(
                item["paths"].get(host) == path for host, path in entry["paths"].items())]
            if len(matches) > 1:
                raise ValueError("project identity and host path refer to different registered projects")
            existing = matches[0] if matches else None
            if existing:
                if entry.get("promote") and mode == "workspace":
                    existing["mode"] = "workspace"
                    existing["origin"] = entry.get("origin", "")
                for host, path in entry["paths"].items():
                    existing["paths"][host] = path
                existing.setdefault("label", label)
                if entry.get("git_owner"):
                    existing["git_owner"] = entry["git_owner"]
                names = [*existing.get("aliases", []), label, *aliases]
                existing["aliases"] = list(dict.fromkeys(name for name in names if name != existing["label"]))
                registered = existing
            else:
                registered = {**entry, "mode": mode, "label": label,
                              "aliases": list(dict.fromkeys(alias for alias in aliases if alias != label)),
                              "repo_id": str(uuid.uuid4())}
                registry["projects"].append(registered)
            registry["revision"] = str(uuid.uuid4())
            path = self.config.state / "registry.toml"
            if path.exists():
                atomic_write(self.config.state / "registry.previous.toml", path.read_bytes())
            atomic_write(path, registry_text(registry).encode())
            return {"status": "registered", "revision": registry["revision"], "project": registered["id"]}

    def project_id_for(self, cwd: str) -> str | None:
        """The registered project of a session's working directory, or None when unregistered or unreachable."""
        if not cwd:
            return None
        if cwd not in self._assignments:
            try:
                self._assignments[cwd] = self.project(cwd=Path(cwd), cached=True)["id"]
            except (NotReady, OSError, ValueError, subprocess.TimeoutExpired):
                self._assignments[cwd] = None
        return self._assignments[cwd]

    def project(self, project_id: str | None = None, *, cwd: Path | None = None, cached=False) -> dict:
        registry = self.registry(cached=cached)
        projects = registry.get("projects", [])
        if project_id:
            matches = [item for item in projects if item["id"] == project_id]
        else:
            location = (cwd or Path.cwd()).resolve()
            mapped = [(item, Path(item["paths"][self.config.host]).resolve())
                      for item in projects if item["paths"].get(self.config.host)]
            matches = [(item, path) for item, path in mapped if location == path or path in location.parents]
            workspace_ancestor = any(item.get("mode", "workspace") == "workspace" for item, _ in matches)
            deepest = max((len(path.parts) for _, path in matches), default=0)
            matches = [item for item, path in matches if len(path.parts) == deepest]
            if not matches or (not workspace_ancestor and all(item.get("mode", "workspace") == "catalog" for item in matches)):
                key = (registry.get("revision"), str(location))
                if key not in self._project_discovery:
                    found, unavailable = [], None
                    deadline = time.monotonic() + 2
                    try:
                        common = (location / run_git(location, "rev-parse", "--git-common-dir", deadline=deadline).decode().strip()).resolve()
                        for item in projects:
                            if item.get("mode", "workspace") == "catalog":
                                continue
                            root = item["paths"].get(self.config.host)
                            if root and (Path(root) / run_git(Path(root), "rev-parse", "--git-common-dir", deadline=deadline).decode().strip()).resolve() == common:
                                found.append(item["id"])
                    except subprocess.TimeoutExpired as error:
                        unavailable = ("project Git discovery timed out for cwd: " + str(location)
                                       + f"; elapsed={time.monotonic() - (deadline - 2):.3f}s; {error}")
                    except OSError as error:
                        unavailable = "project Git discovery unavailable for cwd " + str(location) + ": " + str(error)
                    except NotReady as error:
                        if any(reason in str(error).lower() for reason in ("permission denied", "operation not permitted", "cannot change to")):
                            unavailable = "project Git discovery unavailable for cwd " + str(location) + ": " + str(error)
                    self._project_discovery[key] = (found, unavailable)
                found, unavailable = self._project_discovery[key]
                if unavailable and not matches:
                    raise ProjectDiscoveryUnavailable(unavailable)
                if found:
                    matches = [item for item in projects if item["id"] in found]
        if not matches:
            raise ProjectNotRegistered("no registered project for " + (project_id or str(location)))
        if len(matches) != 1:
            raise NotReady("select --project explicitly; candidates: " + ", ".join(item["id"] for item in matches or projects))
        return matches[0]

    def current_workspace_root(self, project: dict) -> Path | None:
        if not project.get("id") or project.get("mode", "workspace") == "catalog":
            return None
        location = Path.cwd().resolve()
        try:
            current = self.project(cwd=location, cached=True)
        except NotReady:
            return None
        if current["id"] != project["id"]:
            return None
        return Path(run_git(location, "rev-parse", "--show-toplevel",
                            deadline=time.monotonic() + 2).decode().strip()).resolve()

    def adapter(self, harness: str):
        if harness not in {"claude", "codex"}:
            raise ValueError("choose --harness claude or codex")
        return importlib.import_module("ctxlib." + harness)

    def sessions(self, harness: str | None = None) -> list[dict]:
        result = []
        for name in ([harness] if harness else ["claude", "codex"]):
            module = self.adapter(name)
            result.extend({**item, "harness": name} for item in module.discover(home=self.config.native_home))
        return result

    def select_session(self, session: str | None, harness: str | None, project: dict | None = None) -> dict:
        explicit_session = bool(session)
        if session and session.count(":") == 2:
            host, named_harness, session = session.split(":", 2)
            if host != self.config.host:
                raise NotReady("the selected native session belongs to another source host")
            harness = harness or named_harness
        if not session:
            if harness in (None, "codex") and os.environ.get("CODEX_THREAD_ID"):
                session, harness = os.environ["CODEX_THREAD_ID"], "codex"
            elif harness in (None, "claude") and os.environ.get("CLAUDE_CODE_SESSION_ID"):
                session, harness = os.environ["CLAUDE_CODE_SESSION_ID"], "claude"
        if explicit_session and session and harness:
            return {"native_id": component(session), "harness": harness}
        candidates = self.sessions(harness)
        if session:
            candidates = [item for item in candidates if item["native_id"] == session]
        elif project:
            current_root = self.current_workspace_root(project)
            roots = [current_root] if current_root else [
                Path(value).resolve() for key, value in project["paths"].items() if key == self.config.host]
            candidates = [item for item in candidates if item.get("cwd") and any(
                Path(item["cwd"]).resolve() == root or root in Path(item["cwd"]).resolve().parents for root in roots)]
        if not session and harness and project:
            candidates = [item for item in candidates if not self._subagent_session(item)]
            timestamps = [item.get("updated_at") for item in candidates]
            if timestamps and all(isinstance(value, (int, float)) and not isinstance(value, bool)
                                  and math.isfinite(value) and value > 0 for value in timestamps):
                latest = max(timestamps)
                candidates = [item for item in candidates if item["updated_at"] == latest]
        if session and harness and not candidates:
            selected = {"native_id": component(session), "harness": harness}
        elif len(candidates) == 1:
            selected = candidates[0]
        else:
            selected = self._choose_session(candidates)
        print("Selected source: " + json.dumps(
            {key: selected.get(key) for key in ("harness", "native_id", "title")}, ensure_ascii=False), file=sys.stderr)
        return selected

    @staticmethod
    def _subagent_session(session: dict) -> bool:
        source = session.get("source")
        if isinstance(source, str) and source.startswith("{"):
            try:
                source = json.loads(source)
            except ValueError:
                return True
        return isinstance(source, dict) and "subagent" in source

    @staticmethod
    def _choose_session(candidates: list[dict]) -> dict:
        summaries = [{key: item.get(key) for key in ("native_id", "harness", "title", "cwd", "updated_at")}
                     for item in candidates]
        if not candidates or not sys.stdin.isatty():
            raise NotReady("select --session and --harness explicitly; candidates: " + json.dumps(summaries))
        print("Select source session:", file=sys.stderr)
        for number, item in enumerate(summaries, 1):
            print(f"  {number}. " + json.dumps(item, ensure_ascii=False), file=sys.stderr)
        print("Session number: ", end="", flush=True, file=sys.stderr)
        answer = sys.stdin.readline().strip()
        if not answer.isdecimal() or not 1 <= int(answer) <= len(candidates):
            raise NotReady("no source selected; enter one listed session number")
        return candidates[int(answer) - 1]
