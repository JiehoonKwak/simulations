"""Private implementation of the ctx command; payloads live outside this repo."""

SCHEMA_VERSION = 1
