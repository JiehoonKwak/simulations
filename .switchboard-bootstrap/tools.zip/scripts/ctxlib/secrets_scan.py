"""Credential formats shared by redaction and pre-publication scans.

The patterns match token shapes issued by providers, not generic words like "password",
so a scan can fail a publication on a match without drowning in false positives.
Reports name the file and credential kind only; matched values are never returned.
Standard library only, so transcript redaction (`dialogue`) can share it.
"""

from __future__ import annotations

import fnmatch
from pathlib import Path
import re

API_KEY = "OpenAI/Anthropic/OpenRouter-style key"
_LINE = r"(?:\r?\n|(?:\\r)?\\n)"
_LINE_END = rf"(?={_LINE}|[\"']|\Z)"
_WS = r"[ \t]*"
_PEM = (r"-----BEGIN (?:[A-Z0-9]+ )*PRIVATE KEY-----"
        rf"(?:{_LINE}{_WS}(?:Proc-Type|DEK-Info):[^\r\n\\\"']*)*(?:{_LINE}{_WS}(?={_LINE}))?"
        rf"(?:(?:{_LINE}{_WS}[A-Za-z0-9+/=]+{_WS})+{_LINE}{_WS}-----END (?:[A-Z0-9]+ )*PRIVATE KEY-----"
        rf"|(?:{_LINE}{_WS}[A-Za-z0-9+/=]{{16,}}{_WS}{_LINE_END})+(?:{_LINE}{_WS}[A-Za-z0-9+/=]{{1,15}}{_WS}{_LINE_END})?)")
FORMATS = (
    ("private-key", "PEM private key", re.compile(_PEM), True),
    ("github-token", "GitHub token", re.compile(r"(?<![A-Za-z0-9])(?:gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,})"), True),
    ("slack-token", "Slack token", re.compile(r"(?<![A-Za-z0-9])xox[abeprs]-[A-Za-z0-9-]{10,}"), True),
    ("anthropic-key", API_KEY, re.compile(r"(?<![A-Za-z0-9])sk-ant-[A-Za-z0-9_-]{20,}"), True),
    ("openrouter-key", API_KEY, re.compile(r"(?<![A-Za-z0-9])sk-or-v1-[A-Za-z0-9]{20,}"), True),
    ("openai-key", API_KEY, re.compile(r"(?<![A-Za-z0-9])sk-[A-Za-z0-9_-]{20,}"), True),
    ("google-api-key", "Google API key", re.compile(r"(?<![A-Za-z0-9])AIza[0-9A-Za-z_-]{35}"), True),
    ("telegram-bot-token", "Telegram bot token", re.compile(r"(?<![0-9])[0-9]{8,10}:[A-Za-z0-9_-]{35}(?![A-Za-z0-9_-])"), True),
    ("aws-access-key", "AWS access key ID", re.compile(r"(?<![A-Z0-9])(?:AKIA|ASIA)[0-9A-Z]{16}(?![A-Z0-9])"), True),
    ("bearer-token", "Bearer token", re.compile(r"(?P<keep>\bBearer\s+)[A-Za-z0-9._~+/=-]{16,}", re.I), False),
)
CREDENTIALS = tuple((label, pattern) for _, label, pattern, scanned in FORMATS if scanned)
PATTERNS = tuple(pattern for _, pattern in CREDENTIALS)
MAX_BYTES = 8 * 1024 * 1024
SNIFF_BYTES = 8192


def kinds(text: str) -> list[str]:
    return list(dict.fromkeys(label for label, pattern in CREDENTIALS if pattern.search(text)))


def redact(text: str) -> str:
    """Replace credential-shaped substrings in place; the text itself is always kept.

    A format's `keep` group (the `Bearer ` prefix) stays in the output."""
    for slug, _, pattern, _ in FORMATS:
        text = pattern.sub(lambda match, slug=slug: (match.groupdict().get("keep") or "") + f"[REDACTED:{slug}]", text)
    return text


def readable(path, limit=MAX_BYTES) -> bytes | None:
    """The bytes of a text-like file, or None when it is larger than `limit` or binary
    (a NUL byte in the first 8 KiB, which covers SQLite and media)."""
    path = Path(path)
    if path.stat().st_size > limit:
        return None
    data = path.read_bytes()
    return None if b"\0" in data[:SNIFF_BYTES] else data


def kinds_in(data: bytes) -> list[str]:
    return kinds(data.decode("utf-8", errors="replace"))


def scan(root, names, *, allow=(), limit=MAX_BYTES) -> dict[str, list[str]]:
    """Map each text-like file under `root` that holds a credential to the kinds found.

    Files matching an `allow` glob and files `readable` refuses are not scanned."""
    findings = {}
    for name in names:
        if allowed(name, allow):
            continue
        data = readable(Path(root) / name, limit)
        found = kinds_in(data) if data is not None else []
        if found:
            findings[name] = found
    return findings


def allowed(name, allow) -> bool:
    return any(fnmatch.fnmatchcase(name, pattern) for pattern in allow)

