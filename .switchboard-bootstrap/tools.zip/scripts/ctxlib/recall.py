"""Agent-facing retrieval over the host-local index: find sessions, then read selected turns."""

from __future__ import annotations

import os
import re

from . import dialogue, index
from .core import HOSTS, NotReady, remote
from .inbox import PULLED

REFERENCE = re.compile(r"(?P<id>[0-9a-f]{6,64})(?:@(?P<turn>\d+))?")


def _path(ctx):
    if not ctx.index_path.exists():
        raise NotReady("context index has not been built; run ctx sync")
    return ctx.index_path


def _scope(everything: bool) -> dict:
    current = tuple(value for value in (os.environ.get("CODEX_THREAD_ID"), os.environ.get("CLAUDE_CODE_SESSION_ID")) if value)
    return {"origins": () if everything else dialogue.DEFAULT_ORIGINS, "exclude": current}


def find(ctx, text, *, project=None, since=None, everything=False, limit=10, session=None) -> dict:
    """Matching sessions, or with `session` the matching turns inside that one session."""
    if session:
        source = index.resolve(_path(ctx), session)
        return {"status": "complete", "session": source, **index.search(_path(ctx), text, limit=limit, session_key=source["id"])}
    return {"status": "complete", **index.search(_path(ctx), text, project=project, since=since, limit=limit, **_scope(everything))}


def sessions(ctx, *, project=None, since=None, everything=False, limit=30) -> dict:
    return {"status": "complete", **index.sessions(_path(ctx), project=project, since=since, limit=limit, **_scope(everything))}


def read(ctx, reference, *, turns=None, raw=False) -> dict:
    """Read around `ID@TURN`, an explicit `START:END`, or the latest turns; native records come from the owning host."""
    match = REFERENCE.fullmatch(reference or "")
    if not match:
        raise ValueError("read needs ID or ID@TURN from ctx find")
    source = index.resolve(_path(ctx), match["id"])
    around = int(match["turn"]) if match["turn"] else None
    if raw and source["host"] != ctx.config.host:
        command = ["read", source["id"] + ("@" + match["turn"] if match["turn"] else ""), *([turns] if turns else []), "--raw"]
        return remote(source["host"], command, timeout=60)
    return {"status": "complete", **index.read(_path(ctx), source["id"], turns=turns, around=around, raw=raw)}


def status(ctx) -> dict:
    return {"status": "complete", **index.status(_path(ctx))}


def sync(ctx, *, budget=300) -> dict:
    """Index this host's changed sessions, then pull each peer's changes; a Mac also pulls the Linux hosts, which cannot reach it."""
    result = {"status": "complete", "local": index.refresh(ctx, budget=budget), "peers": {}}
    for peer in (*ctx.config.peers, *(PULLED if ctx.config.host in HOSTS else ())):
        result["peers"][peer] = index.pull(ctx, peer, budget=max(30, budget / 2))
    if result["local"]["pending_sessions"] or any(value["status"] == "catching_up" for value in result["peers"].values()):
        result["status"] = "catching_up"
    return result
