"""Revocable bootstrap grants and short-lived, project-scoped NAS sessions.

The provider supplies the bootstrap bearer on every request. A signed session
adds a bounded grant; it never substitutes for a currently valid bootstrap.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import math
import re
import time
from pathlib import Path


class ExpiredSession(PermissionError):
    """An authentic session expired while its bootstrap and grant remain valid."""


def _deny():
    raise PermissionError('unauthorized')


def _identifier(value):
    return isinstance(value, str) and re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,127}', value) is not None


def _digest(value):
    return isinstance(value, str) and re.fullmatch(r'[0-9a-f]{64}', value) is not None


def _timestamp(value):
    return (type(value) is int and value >= 0
            or type(value) is float and math.isfinite(value) and value >= 0)


def _unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            _deny()
        result[key] = value
    return result


def _json(data):
    try:
        return json.loads(data, object_pairs_hook=_unique_object)
    except (ValueError, UnicodeError, TypeError, RecursionError):
        _deny()


def _configuration(auth_file):
    try:
        with Path(auth_file).open('rb') as handle:
            data = handle.read(1024 * 1024 + 1)
    except OSError:
        _deny()
    if len(data) > 1024 * 1024:
        _deny()
    config = _json(data)
    if not isinstance(config, dict) or set(config) - {'tokens', 'session_signing_key'}:
        _deny()
    tokens = config.get('tokens')
    if not isinstance(tokens, list):
        _deny()
    key = config.get('session_signing_key')
    if 'session_signing_key' in config and not _digest(key):
        _deny()
    fingerprints, principals = set(), set()
    for grant in tokens:
        if not isinstance(grant, dict) or set(grant) - {
            'sha256', 'expires_at', 'projects', 'kind', 'principal',
            'session_ttl', 'legacy_owners', 'denied_revisions',
        }:
            _deny()
        fingerprint = grant.get('sha256')
        if not _digest(fingerprint) or fingerprint in fingerprints:
            _deny()
        fingerprints.add(fingerprint)
        kind = grant.get('kind', 'legacy')
        if kind not in ('legacy', 'bootstrap'):
            _deny()
        if 'expires_at' in grant and not _timestamp(grant['expires_at']):
            _deny()
        if kind == 'bootstrap':
            principal = grant.get('principal')
            ttl = grant.get('session_ttl', 900)
            if not _identifier(principal) or principal in principals or not _digest(key):
                _deny()
            if type(ttl) is not int or not 30 <= ttl <= 3600:
                _deny()
            principals.add(principal)
            legacy = grant.get('legacy_owners', [])
            if not isinstance(legacy, list) or any(not _digest(item) for item in legacy) or len(set(legacy)) != len(legacy):
                _deny()
        elif 'expires_at' not in grant or any(item in grant for item in ('principal', 'session_ttl', 'legacy_owners')):
            _deny()
        projects = grant.get('projects')
        if not isinstance(projects, dict):
            _deny()
        for project, permissions in projects.items():
            if not _identifier(project) or not isinstance(permissions, list):
                _deny()
            if any(item not in ('read', 'write') for item in permissions) or len(set(permissions)) != len(permissions):
                _deny()
        denials = grant.get('denied_revisions', {})
        if not isinstance(denials, dict):
            _deny()
        for project, revisions in denials.items():
            if project not in projects or not isinstance(revisions, list):
                _deny()
            if any(not _digest(revision) for revision in revisions) or len(set(revisions)) != len(revisions):
                _deny()
    return config


def _active(grant, now):
    return 'expires_at' not in grant or grant['expires_at'] > now


def _root(config, authorization, now):
    if not isinstance(authorization, str) or not authorization.startswith('Bearer '):
        _deny()
    token = authorization[7:]
    if not token or len(token) > 8192 or any(character.isspace() for character in token):
        _deny()
    try:
        fingerprint = hashlib.sha256(token.encode()).hexdigest()
    except UnicodeError:
        _deny()
    for grant in config['tokens']:
        if hmac.compare_digest(fingerprint, grant['sha256']) and _active(grant, now):
            owner = 'principal:' + grant['principal'] if grant.get('kind') == 'bootstrap' else fingerprint
            return owner, grant
    _deny()


def _scope(grant, project, permission):
    if project is not None:
        if not _identifier(project) or not grant['projects'].get(project):
            _deny()
        if permission is not None and permission not in grant['projects'][project]:
            _deny()
    elif permission is not None:
        _deny()


def _session(config, grant, session, now):
    if not isinstance(session, str) or len(session) > 4096:
        _deny()
    parts = session.split('.')
    if len(parts) != 3 or parts[0] != 'ctx1' or not _digest(parts[2]):
        _deny()
    encoded = parts[1]
    if not re.fullmatch(r'[A-Za-z0-9_-]+', encoded):
        _deny()
    signature = hmac.new(bytes.fromhex(config['session_signing_key']), ('ctx1.' + encoded).encode(), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(signature, parts[2]):
        _deny()
    try:
        payload = _json(base64.b64decode(encoded + '=' * (-len(encoded) % 4), altchars=b'-_', validate=True))
    except ValueError:
        _deny()
    if not isinstance(payload, dict) or set(payload) != {'root', 'principal', 'project', 'permissions', 'iat', 'exp'}:
        _deny()
    permissions = payload['permissions']
    if not isinstance(permissions, list) or not permissions or any(item not in ('read', 'write') for item in permissions):
        _deny()
    if len(set(permissions)) != len(permissions) or not _identifier(payload['project']):
        _deny()
    if not _digest(payload['root']) or not hmac.compare_digest(payload['root'], grant['sha256']) or payload['principal'] != grant['principal']:
        _deny()
    if type(payload['iat']) is not int or type(payload['exp']) is not int:
        _deny()
    if payload['iat'] < 0 or payload['iat'] > now or not 0 < payload['exp'] - payload['iat'] <= 3600:
        _deny()
    effective = dict(grant)
    effective['projects'] = {payload['project']: [item for item in permissions if item in grant['projects'].get(payload['project'], [])]}
    return payload, effective


def authenticate(auth_file, authorization, session=None, *, project=None, permission=None, exchange=False):
    """Authenticate the root and restrict bootstrap requests to their session."""
    config, now = _configuration(auth_file), time.time()
    owner, grant = _root(config, authorization, now)
    if exchange:
        if grant.get('kind') != 'bootstrap' or session is not None or project is None:
            _deny()
        _scope(grant, project, permission)
        return owner, grant
    if grant.get('kind') != 'bootstrap':
        if session is not None:
            _deny()
        _scope(grant, project, permission)
        return owner, grant
    payload, effective = _session(config, grant, session, now)
    if project is not None and project != payload['project']:
        _deny()
    _scope(effective, payload['project'], permission)
    if payload['exp'] <= now:
        raise ExpiredSession('session expired')
    return owner, effective


def issue_session(auth_file, authorization, project):
    """Exchange a currently valid provider bootstrap for one project session."""
    config, now = _configuration(auth_file), time.time()
    _, grant = _root(config, authorization, now)
    if grant.get('kind') != 'bootstrap':
        _deny()
    _scope(grant, project, None)
    issued = int(now)
    expires = issued + grant.get('session_ttl', 900)
    if 'expires_at' in grant:
        expires = min(expires, int(grant['expires_at']))
    if expires <= now:
        _deny()
    payload = {'root': grant['sha256'], 'principal': grant['principal'], 'project': project,
               'permissions': list(grant['projects'][project]), 'iat': issued, 'exp': expires}
    encoded = base64.urlsafe_b64encode(json.dumps(payload, sort_keys=True, separators=(',', ':')).encode()).decode().rstrip('=')
    message = 'ctx1.' + encoded
    signature = hmac.new(bytes.fromhex(config['session_signing_key']), message.encode(), hashlib.sha256).hexdigest()
    return {'status': 'complete', 'session': message + '.' + signature,
            'expires_at': expires, 'principal': grant['principal'], 'project': project}


def authorize_revision(grant, project, revision):
    """Keep quarantined immutable checkpoints inaccessible to a scoped grant."""
    _scope(grant, project, None)
    if revision is not None and revision in grant.get('denied_revisions', {}).get(project, []):
        _deny()


def revalidate(auth_file, owner, project, permission, *, revisions=()):
    """Recheck a delayed publication against the owner's current root grant."""
    config, now = _configuration(auth_file), time.time()
    if not isinstance(owner, str) or not (_digest(owner) or owner.startswith('principal:') and _identifier(owner[10:])):
        _deny()
    if not _identifier(project) or permission not in ('read', 'write'):
        _deny()
    for grant in config['tokens']:
        actual = 'principal:' + grant['principal'] if grant.get('kind') == 'bootstrap' else grant['sha256']
        matches = hmac.compare_digest(actual, owner)
        if grant.get('kind') == 'bootstrap' and owner in grant.get('legacy_owners', []):
            matches = True
        if matches and _active(grant, now):
            _scope(grant, project, permission)
            for revision in revisions:
                authorize_revision(grant, project, revision)
            return True
    _deny()


def owns(grant, owner, actualowner):
    """Honor only explicitly curated legacy ticket owners for this principal."""
    if not isinstance(owner, str) or not isinstance(actualowner, str):
        return False
    if not owner.isascii() or not actualowner.isascii():
        return False
    if hmac.compare_digest(owner, actualowner):
        return True
    return (grant.get('kind') == 'bootstrap'
            and owner == 'principal:' + grant.get('principal', '')
            and _digest(actualowner) and actualowner in grant.get('legacy_owners', []))
