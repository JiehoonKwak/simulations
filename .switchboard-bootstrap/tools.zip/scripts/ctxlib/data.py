"""Personal data in the Vault's `data/` folder: export on the owning host, query anywhere.

Each source is exported by code on the host that owns it, without a model, into
files that Git carries to GitHub. Agents query them with `ctx data <source>` or
read the files directly, including from a cloud checkout of the Vault. On the
Vault's Git owner, `ctx data sync` also sends one combined daily-note and
Reminders diff to Cloud (`context_diffs`) and commits and pushes the Vault once it
has been quiet for a few minutes.
"""

from __future__ import annotations

import csv
import json
import os
import re
import sqlite3
import subprocess
import sys
import time
import urllib.request
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from zoneinfo import ZoneInfo

from . import health as health_tables
from . import context_diffs
from . import reminders as reminder_snapshots
from .core import NotReady, atomic_json, atomic_write

VAULT = Path(os.environ.get("CTX_VAULT", Path.home() / "Library/Mobile Documents/iCloud~md~obsidian/Documents/Database"))
VAULT_OWNER = "m1pro"
SEOUL = ZoneInfo("Asia/Seoul")
QUIET_SECONDS = 300
SENDER = Path(__file__).resolve().parents[1] / "send2cloud"
TELEGRAM_CREDENTIALS = Path.home() / ".codex/hooks/telegram-automation-credentials.json"
DAYFLOW_FIELDS = ("record_id", "start", "end", "title", "summary")
HEALTH_KINDS = {"days": "day", "sleep": "night", "workouts": "date", "samples": "ts_utc"}


def vault(path=None) -> Path:
    root = Path(path).expanduser() if path else VAULT
    if not (root / "data").is_dir():
        raise NotReady(f"no Vault data folder at {root}; pass --vault or set CTX_VAULT to a Database checkout")
    return root


def _write(path: Path, body: bytes) -> bool:
    if path.is_file() and path.read_bytes() == body:
        return False
    atomic_write(path, body, mode=0o644)
    return True


def logical_day(now=None) -> date:
    """Dayflow's day: Asia/Seoul with a 04:00 boundary."""
    return ((now or datetime.now(SEOUL)).astimezone(SEOUL) - timedelta(hours=4)).date()


def _dayflow_day(root: Path, day: date, runner=subprocess.run) -> int:
    result = runner(["/usr/local/bin/dayflow", "timeline", day.isoformat(), "--summary", "--json"],
                    capture_output=True, text=True, check=True, timeout=60)
    doc = json.loads(result.stdout)
    if not isinstance(doc.get("cards"), list):
        raise ValueError("Dayflow returned no card list")
    target = root / "data/dayflow" / (day.isoformat() + ".json")
    if not doc["cards"] and not target.exists():
        return 0
    output = {key: doc[key] for key in ("schema_version", "date", "time_zone", "day_boundary_hour")}
    output["cards"] = [{key: card[key] for key in DAYFLOW_FIELDS} for card in doc["cards"]]
    _write(target, (json.dumps(output, ensure_ascii=False, indent=2) + "\n").encode())
    return len(output["cards"])


def export_dayflow(root: Path, *, full=False, runner=subprocess.run) -> dict:
    today = logical_day()
    if not full:
        cards = {day.isoformat(): _dayflow_day(root, day, runner) for day in (today - timedelta(days=1), today)}
        return {"status": "complete", "cards": cards}
    days, empty, day = 0, 0, today
    while empty < 60:
        found = _dayflow_day(root, day, runner)
        days, empty = days + bool(found), 0 if found else empty + 1
        day -= timedelta(days=1)
    return {"status": "complete", "days": days, "earliest_checked": (day + timedelta(days=1)).isoformat()}


def _health_db() -> Path:
    return Path(os.environ.get("HEALTH_EXPORT_KIT_DB", Path.home() / ".local/share/health-export-kit/health.sqlite"))


def export_health(root: Path, *, full=False, state: dict | None = None, db_path: Path | None = None) -> dict:
    """Rewrite the agent tables from the Health Export Kit store when it changed, touching only files whose bytes differ."""
    db_path = db_path or _health_db()
    stamp = [round(path.stat().st_mtime, 3) for path in (db_path, db_path.with_name(db_path.name + "-wal")) if path.exists()]
    if not full and state is not None and state.get("health_stamp") == stamp:
        return {"status": "unchanged"}
    files, folder, changed = health_tables.build(db_path), root / "data/health", 0
    for relative, body in files.items():
        changed += _write(folder / relative, body)
    for stale in [path for path in folder.rglob("*") if path.is_file()]:
        if str(stale.relative_to(folder)) not in files:
            stale.unlink()
            changed += 1
    for directory in sorted((path for path in folder.rglob("*") if path.is_dir()), reverse=True):
        if not any(directory.iterdir()):
            directory.rmdir()
    if state is not None:
        state["health_stamp"] = stamp
    return {"status": "complete", "changed_files": changed, "files": len(files)}


def publish(body: str, event_id: str) -> str:
    """Send a pre-formatted body to Cloud through send2cloud; return the Slack receipt."""
    sys.path.insert(0, str(SENDER))
    from agent_events import DeliveryError, publish_event
    try:
        return publish_event(body, source="context", event_id=event_id, resend=True)["receipt"]
    except DeliveryError as error:
        raise NotReady(f"Slack delivery {error.status} for {event_id}: {error}") from None


def alert(text: str) -> None:
    """Tell the user directly through the existing automation Telegram bot."""
    credentials = json.loads(TELEGRAM_CREDENTIALS.read_text())
    request = urllib.request.Request(
        f"https://api.telegram.org/bot{credentials['bot_token']}/sendMessage",
        data=json.dumps({"chat_id": credentials["chat_id"], "text": text}).encode(),
        headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(request, timeout=15) as response:
        if not json.loads(response.read()).get("ok"):
            raise NotReady("Telegram rejected the alert")


def export_reminders(root: Path, *, runner=subprocess.run) -> dict:
    current = reminder_snapshots.snapshot(runner)
    _write(root / "data/reminders/open.json", (json.dumps(current, ensure_ascii=False, indent=2) + "\n").encode())
    return {"status": "complete", "open": len(current)}


SOURCES = {
    "dayflow": {"host": "m3max", "export": lambda root, full, state: export_dayflow(root, full=full)},
    "reminders": {"host": "m1pro", "export": lambda root, full, state: export_reminders(root)},
    "health": {"host": "m1pro", "export": lambda root, full, state: export_health(root, full=full, state=state)},
}


def _git(root: Path, *args, timeout=60) -> subprocess.CompletedProcess:
    return subprocess.run(["git", "-C", str(root), *args], capture_output=True, text=True, timeout=timeout)


def _nested_checkout(root: Path, path: str) -> str | None:
    """The top of the nested checkout holding `path`: a Claude worktree or any directory with its own `.git`.

    Agent worktrees in the iCloud Vault reach other Macs with a `.git` file whose gitdir exists only on the
    Mac that made them (or before that file syncs), so Git would stage their files as ordinary Vault content.
    """
    parts = Path(path).parts
    if parts[:2] == (".claude", "worktrees"):
        return ".claude/worktrees"
    return next(("/".join(parts[:i]) for i in range(1, len(parts) + 1) if (root.joinpath(*parts[:i]) / ".git").exists()), None)


def autosave(root: Path, *, quiet=QUIET_SECONDS, now=None) -> dict:
    """Commit and push all Vault changes, never nested checkouts, once nothing has changed for `quiet` seconds."""
    now = now or time.time()
    git_dir = Path(_git(root, "rev-parse", "--absolute-git-dir").stdout.strip())
    if (git_dir / "index.lock").exists():
        return {"status": "busy"}
    listing = _git(root, "status", "--porcelain", "-z", "--untracked-files=all").stdout
    tops = {entry[3:]: _nested_checkout(root, entry[3:]) for entry in listing.split("\0") if len(entry) > 3}
    paths = [path for path, top in tops.items() if not top]
    skip = [f":(exclude,literal){top}" for top in sorted(set(filter(None, tops.values())))]
    if paths:
        newest = max(((root / path).stat().st_mtime for path in paths if (root / path).exists()), default=0)
        if now - newest < quiet:
            return {"status": "waiting", "changed": len(paths)}
        for step in (("add", "-A", "--", ".", *skip), ("commit", "-q", "-m", "autosave")):
            result = _git(root, *step)
            if result.returncode:
                return {"status": "error", "step": step[0], "reason": (result.stderr or result.stdout).strip()[-300:]}
    ahead = _git(root, "rev-list", "--count", "@{upstream}..HEAD")
    if ahead.returncode or ahead.stdout.strip() == "0":
        return {"status": "clean" if not paths else "committed", "changed": len(paths)}
    pushed = _git(root, "push", "-q", timeout=120)
    if pushed.returncode:
        return {"status": "push_failed", "reason": pushed.stderr.strip()[-300:]}
    return {"status": "pushed", "changed": len(paths), "commits": int(ahead.stdout.strip())}


def sync(ctx, *, root=None, full=False, sources=None) -> dict:
    """Export this host's sources; on the Vault owner, also send context diffs to Cloud and autosave."""
    root = vault(root)
    state_path = ctx.config.state / "data-state.json"
    try:
        state = json.loads(state_path.read_text())
    except (OSError, ValueError):
        state = {}
    result = {"status": "complete", "host": ctx.config.host, "checked_at": datetime.now(timezone.utc).isoformat(), "sources": {}}
    for name, source in SOURCES.items():
        if source["host"] != ctx.config.host or (sources and name not in sources):
            continue
        try:
            result["sources"][name] = source["export"](root, full, state)
        except (OSError, ValueError, KeyError, sqlite3.Error, subprocess.SubprocessError, NotReady) as error:
            result["sources"][name] = {"status": "error", "reason": f"{type(error).__name__}: {str(error)[:200]}"}
            result["status"] = "partial"
    if ctx.config.host == VAULT_OWNER and not sources:
        steps = (("context_diffs", lambda: context_diffs.deliver(root, state, now=time.time(), publish=publish, alert=alert)),
                 ("autosave", lambda: autosave(root)))
        for name, step in steps:
            try:
                result[name] = step()
            except (OSError, ValueError, KeyError, subprocess.SubprocessError, NotReady) as error:
                result[name] = {"status": "error", "reason": f"{type(error).__name__}: {str(error)[:200]}"}
            if result[name]["status"] in {"error", "push_failed"}:
                result["status"] = "partial"
    atomic_json(state_path, state)
    atomic_json(ctx.config.state / "data.json", result)
    return result


def _since(value: str) -> date:
    match = re.fullmatch(r"(\d+)([dw])", value or "")
    if match:
        return logical_day() - timedelta(days=int(match[1]) * (7 if match[2] == "w" else 1))
    return date.fromisoformat(value)


def _window(day=None, since=None, until=None, default_days=0) -> tuple[date, date]:
    if day:
        start = end = logical_day() if day == "today" else logical_day() - timedelta(days=1) if day == "yesterday" else date.fromisoformat(day)
        return start, end
    end = date.fromisoformat(until) if until else logical_day()
    return (_since(since) if since else end - timedelta(days=default_days)), end


def dayflow(root=None, *, day=None, since=None, until=None, text=None) -> dict:
    start, end = _window(day, since, until)
    folder, cards = vault(root) / "data/dayflow", []
    current = start
    while current <= end:
        path = folder / (current.isoformat() + ".json")
        if path.is_file():
            for card in json.loads(path.read_text())["cards"]:
                if not text or text.casefold() in (card["title"] + " " + card["summary"]).casefold():
                    cards.append({"date": current.isoformat(), **card})
        current += timedelta(days=1)
    return {"status": "complete", "from": start.isoformat(), "to": end.isoformat(), "cards": cards}


def health(root=None, *, kind="days", since=None, until=None, metric=None, limit=2000) -> dict:
    """Rows of one health table in a date window; `metric` narrows day columns, workout kinds or sample metrics."""
    if kind not in HEALTH_KINDS:
        raise ValueError("kind must be one of " + ", ".join(HEALTH_KINDS))
    start, end = _window(None, since or "7d", until)
    folder, key, rows = vault(root) / "data/health", HEALTH_KINDS[kind], []
    paths = [folder / (kind + ".csv")] if kind != "samples" else [
        path for path in sorted((folder / "samples").glob("*.csv")) if start.isoformat()[:7] <= path.stem <= end.isoformat()[:7]]
    needle = (metric or "").casefold()
    for path in paths:
        with path.open(newline="") as handle:
            for row in csv.DictReader(handle):
                if not start.isoformat() <= row[key][:10] <= end.isoformat():
                    continue
                if kind == "days" and needle:
                    row = {name: value for name, value in row.items() if name == "day" or needle in name}
                elif needle and needle not in (row.get("metric") or row.get("kind") or "").casefold():
                    continue
                rows.append(row)
    return {"status": "complete", "kind": kind, "from": start.isoformat(), "to": end.isoformat(),
            "rows": rows[-limit:], "omitted": max(0, len(rows) - limit)}


def reminders(root=None, *, text=None, list_name=None, diff=None, ctx=None) -> dict:
    """Open reminders, or with `diff` the changes from an older open.json (`sent`: M1's last delivered snapshot)."""
    current = json.loads((vault(root) / "data/reminders/open.json").read_text())
    if diff:
        if diff == "sent":
            state_path = ctx.config.state / "data-state.json" if ctx else None
            baseline = json.loads(state_path.read_text()).get("reminders", {}).get("baseline") if state_path and state_path.is_file() else None
            if baseline is None:
                raise NotReady("no delivered Reminders snapshot on this host; pass an older open.json path")
        else:
            baseline = json.loads(Path(diff).expanduser().read_text())
        found = reminder_snapshots.changes(baseline, current)
        return {"status": "complete", "changes": found, "lines": reminder_snapshots.change_lines(found)}
    items = [{"id": key, **reminder_snapshots.display(item)} for key, item in current.items()]
    return {"status": "complete", "reminders": [item for item in items
            if (not list_name or item["list"] == list_name)
            and (not text or text.casefold() in (item["title"] + " " + item.get("notes", "")).casefold())]}


def listing(root=None) -> dict:
    root, result = vault(root), {}
    for name, source in SOURCES.items():
        files = [path for path in (root / "data" / name).rglob("*") if path.is_file()]
        stems = sorted(path.stem for path in files if re.fullmatch(r"\d{4}-\d{2}(-\d{2})?", path.stem)) or sorted(path.stem for path in files)
        result[name] = {"host": source["host"], "files": len(files),
                        "first": stems[0] if stems else None, "last": stems[-1] if stems else None,
                        "modified_at": datetime.fromtimestamp(max(path.stat().st_mtime for path in files), timezone.utc).isoformat() if files else None}
    return {"status": "complete", "vault": str(root), "sources": result}
