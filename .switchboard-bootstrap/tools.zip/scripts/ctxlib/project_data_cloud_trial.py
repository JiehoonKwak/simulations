"""Forced-command SSH gateway for one synthetic Codex Cloud trial.

This bounded JSON/base64 helper is not production large-file transport. Its
server-owned argv fixes the root and project, and every trial writer must use
this gateway so uploads and publication share its lock. Compatible with NAS
Python 3.8 and the standard library; deploy beside project_data_store.py.
The fixed deadline includes response delivery; timeout exits 124 without retrying
output or flushing a blocked stdout during interpreter shutdown.
"""
from __future__ import annotations

import base64
from contextlib import contextmanager
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import stat
import sys
import tempfile
import time

try:
    from . import project_data_store as store
except ImportError:
    import project_data_store as store


PROJECT = 'cloud-trial-20261010'
COMMAND = 'ctx-cloud-trial'
MAX_REQUEST = 2 * 1024 * 1024
MAX_CONTENT = 1024 * 1024
MAX_STAGE_BYTES = 4 * 1024 * 1024
MAX_STORE_BYTES = 16 * 1024 * 1024
MAX_FILES = 16
MAX_STAGES = 8
MAX_CHECKPOINTS = 8
MAX_STAGE_DIRS = 128
MAX_STORE_DIRS = 1024
DEADLINE_SECONDS = 60
FIELDS = {
    'inspect': {'revision'},
    'stage': {'id'},
    'publish': {'id', 'revision', 'base'},
    'read': {'revision', 'path'},
    'upload': {'id', 'path', 'content'},
}


class TrialDeadlineExceeded(TimeoutError):
    pass


def trial_path(value):
    path = store.safe_path(value)
    if '\0' in value or any(len(part.encode('utf-8')) > 240 for part in path.parts):
        raise ValueError('invalid trial path component')
    if len(value) > 512 or len(path.parts) > 8:
        raise ValueError('trial path length limit exceeded')
    return path


def safe_chain(path):
    path = Path(path)
    for candidate in [*reversed(path.parents), path]:
        if candidate.is_symlink():
            raise ValueError('symlink in trial path')
        if candidate.exists():
            info = candidate.stat()
            if not stat.S_ISDIR(info.st_mode) and (not stat.S_ISREG(info.st_mode) or info.st_nlink != 1):
                raise ValueError('trial files must be regular files with one link')
    return path


@contextmanager
def deadline():
    previous_handler = signal.getsignal(signal.SIGALRM)
    previous_timer = signal.getitimer(signal.ITIMER_REAL)
    started = time.monotonic()

    def expired(signum, frame):
        raise TrialDeadlineExceeded('trial request deadline exceeded')

    signal.signal(signal.SIGALRM, expired)
    signal.setitimer(signal.ITIMER_REAL, DEADLINE_SECONDS)
    try:
        yield
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        signal.signal(signal.SIGALRM, previous_handler)
        if previous_timer[0]:
            signal.setitimer(signal.ITIMER_REAL, max(0.001, previous_timer[0] - (time.monotonic() - started)), previous_timer[1])


def validate_manifest(value):
    if not isinstance(value, dict) or value.get('project') != PROJECT or value.get('schema_version') != 1:
        raise ValueError('invalid trial manifest identity')
    files = value.get('files')
    if not isinstance(files, dict) or len(files) > MAX_FILES:
        raise ValueError('trial manifest file limit exceeded')
    total = 0
    for name, entry in files.items():
        trial_path(name)
        if not isinstance(entry, dict):
            raise ValueError('invalid manifest file entry')
        size = entry.get('size')
        if type(size) is not int or not 0 <= size <= MAX_CONTENT:
            raise ValueError('manifest file size limit exceeded')
        if not isinstance(entry.get('sha256'), str) or not re.fullmatch(r'[0-9a-f]{64}', entry['sha256']):
            raise ValueError('invalid manifest checksum')
        total += size
    if total > MAX_STAGE_BYTES:
        raise ValueError('trial manifest size limit exceeded')
    return value


class Gateway:
    def __init__(self, root, project=PROJECT):
        self.root = Path(root)
        if not self.root.is_absolute() or project != PROJECT:
            raise ValueError('invalid server trial scope')
        safe_chain(self.root)
        self.project = safe_chain(self.root / 'projects' / PROJECT)
        self.project.mkdir(parents=True, exist_ok=True, mode=0o700)

    @contextmanager
    def locked(self):
        lock_path = safe_chain(self.project / '.cloud-trial.lock')
        with lock_path.open('a') as lock:
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
            try:
                self.check_tree(self.project)
                yield
            finally:
                fcntl.flock(lock.fileno(), fcntl.LOCK_UN)

    def check_tree(self, root):
        safe_chain(root)
        for folder, directories, files in os.walk(root, followlinks=False):
            for name in directories + files:
                safe_chain(Path(folder) / name)

    def usage(self, root):
        files = [path for path in root.rglob('*') if path.is_file()]
        return len(files), sum(path.stat().st_size for path in files)

    def check_directories(self, destinations, stage=None):
        missing = set()
        for destination in destinations:
            path = destination
            while path != self.project:
                if self.project not in path.parents:
                    raise ValueError('directory exceeds trial scope')
                if not path.exists():
                    missing.add(path)
                path = path.parent
        count = 1 + sum(path.is_dir() for path in self.project.rglob('*'))
        if count + len(missing) > MAX_STORE_DIRS:
            raise ValueError('trial directory quota exceeded')
        if stage:
            count = int(stage.exists()) + sum(path.is_dir() for path in stage.rglob('*'))
            if count + sum(path == stage or stage in path.parents for path in missing) > MAX_STAGE_DIRS:
                raise ValueError('trial stage directory quota exceeded')

    def stage(self, identifier):
        path = safe_chain(self.project / 'staging' / store.component(identifier))
        if not path.is_dir():
            raise ValueError('create the trial stage before uploading')
        return path

    def dispatch(self, request):
        if not isinstance(request, dict) or request.get('action') not in FIELDS:
            raise ValueError('unsupported trial action')
        if request.get('project', PROJECT) != PROJECT or request.get('root', str(self.root)) != str(self.root):
            raise ValueError('request exceeds fixed trial scope')
        action = request['action']
        if set(request) - {'action', 'root', 'project'} - FIELDS[action]:
            raise ValueError('unsupported trial request fields')
        request = {key: value for key, value in request.items() if key not in ('root', 'project')}
        request['project'] = PROJECT
        with self.locked():
            base_directories = [self.project / name for name in ('refs', 'checkpoints', 'staging')]
            self.check_directories(base_directories)
            if action == 'upload':
                return self.upload(request)
            if action == 'read':
                return self.read(request)
            if action == 'stage':
                identifier = store.component(request['id'])
                directory = self.project / 'staging'
                count = len(list(directory.iterdir())) if directory.exists() else 0
                if not (directory / identifier).exists() and count >= MAX_STAGES:
                    raise ValueError('trial stage limit exceeded')
                self.check_directories([*base_directories, directory / identifier / 'payload'], directory / identifier)
            if action == 'publish':
                revision = store.component(request['revision'])
                destination = self.project / 'checkpoints' / revision
                if not destination.exists():
                    directory = self.project / 'checkpoints'
                    if directory.exists() and len(list(directory.iterdir())) >= MAX_CHECKPOINTS:
                        raise ValueError('trial checkpoint limit exceeded')
                    stage = self.stage(request['id'])
                    validate_manifest(json.loads((stage / 'manifest.json').read_text()))
            result = store.dispatch(self.root, request)
            result.pop('payload', None)
            result.pop('stage', None)
            if action == 'stage':
                result['id'] = request['id']
            return result

    def upload(self, request):
        stage = self.stage(request['id'])
        relative = trial_path(request['path'])
        if str(relative) != 'manifest.json' and (len(relative.parts) < 2 or relative.parts[0] != 'payload'):
            raise ValueError('upload is limited to staged payload and manifest')
        encoded = request['content']
        if not isinstance(encoded, str) or len(encoded) > ((MAX_CONTENT + 2) // 3) * 4:
            raise ValueError('trial content size limit exceeded')
        content = base64.b64decode(encoded, validate=True)
        if len(content) > MAX_CONTENT:
            raise ValueError('trial content size limit exceeded')
        if str(relative) == 'manifest.json':
            validate_manifest(json.loads(content))
        target = safe_chain(stage / relative)
        if target.exists() and not target.is_file():
            raise ValueError('upload destination is not a regular file')
        old_size = target.stat().st_size if target.exists() else 0
        count, stage_bytes = self.usage(stage)
        _, store_bytes = self.usage(self.project)
        payload_count, _ = self.usage(stage / 'payload')
        if (count + (not target.exists()) > MAX_FILES + 1
                or (relative.parts[0] == 'payload' and payload_count + (not target.exists()) > MAX_FILES)):
            raise ValueError('trial stage file limit exceeded')
        if stage_bytes - old_size + len(content) > MAX_STAGE_BYTES or store_bytes - old_size + len(content) > MAX_STORE_BYTES:
            raise ValueError('trial storage quota exceeded')
        self.check_directories([target.parent], stage)
        target.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        descriptor, temporary = tempfile.mkstemp(prefix='.upload-', dir=target.parent)
        try:
            with os.fdopen(descriptor, 'wb') as output:
                output.write(content)
                output.flush()
                os.fsync(output.fileno())
            os.chmod(temporary, 0o600)
            os.replace(temporary, target)
            store.sync_directory(target.parent)
        finally:
            if os.path.exists(temporary):
                os.unlink(temporary)
        return {'status': 'complete', 'id': request['id'], 'path': str(relative), 'size': len(content),
                'sha256': hashlib.sha256(content).hexdigest()}

    def read(self, request):
        current = store.dispatch(self.root, {'action': 'inspect', 'project': PROJECT, 'revision': request.get('revision')})
        if not current['revision']:
            raise ValueError('trial has no published checkpoint')
        relative = trial_path(request['path'])
        checkpoint = self.project / 'checkpoints' / current['revision']
        if str(relative) == 'manifest.json':
            target = safe_chain(checkpoint / 'manifest.json')
        elif len(relative.parts) >= 2 and relative.parts[0] == 'payload':
            name = str(relative.relative_to('payload'))
            if name not in current['manifest']['files']:
                raise ValueError('read path is not in the published manifest')
            target = safe_chain(checkpoint / relative)
            entry = current['manifest']['files'][name]
            if target.stat().st_size != entry['size'] or store.sha(target) != entry['sha256']:
                raise ValueError('published payload checksum mismatch')
        else:
            raise ValueError('read is limited to published payload and manifest')
        if target.stat().st_size > MAX_CONTENT:
            raise ValueError('trial read size limit exceeded')
        content = target.read_bytes()
        return {'status': 'complete', 'revision': current['revision'], 'path': str(relative),
                'content': base64.b64encode(content).decode('ascii'), 'sha256': hashlib.sha256(content).hexdigest()}


def main(argv=None, environ=None, incoming=None, outgoing=None):
    argv = sys.argv[1:] if argv is None else argv
    environ = os.environ if environ is None else environ
    incoming = sys.stdin.buffer if incoming is None else incoming
    outgoing = sys.stdout if outgoing is None else outgoing
    os.umask(0o077)
    try:
        with deadline():
            try:
                if environ.get('SSH_ORIGINAL_COMMAND') != COMMAND:
                    raise ValueError('only the exact trial command is accepted')
                if len(argv) != 2:
                    raise ValueError('server requires a fixed root and project')
                body = incoming.read(MAX_REQUEST + 1)
                if len(body) > MAX_REQUEST:
                    raise ValueError('trial request size limit exceeded')
                result = Gateway(argv[0], argv[1]).dispatch(json.loads(body))
            except TrialDeadlineExceeded:
                raise
            except (ValueError, OSError, KeyError, TypeError) as error:
                result = {'status': 'not_ready', 'reason': str(error)}
            outgoing.write(json.dumps(result, ensure_ascii=False) + '\n')
            outgoing.flush()
            return 0 if result['status'] == 'complete' else 1
    except TrialDeadlineExceeded:
        os._exit(124)
    except OSError:
        os._exit(1)


if __name__ == '__main__':
    raise SystemExit(main())
