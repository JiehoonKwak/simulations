"""Switchboard: tasks on the GitHub issue board `BOARD`, run by self-hosted runners on each machine.

Orchestrators create tasks (`ctx task create`, or an issue with `### Field`
sections, see the board's README); a runner on the labelled machine calls
`ctx task _run`. State labels make a repeated trigger a no-op: a task runs once
unless a person removes its `done` or `failed` label and triggers it again.

A repository whose registry entry names a `git_owner` (the Vault: M1) runs tasks
only on that host: `create` rejects another machine, and `_claim` and `_run`
refuse such a task.

A task runs in its own Git worktree, so it never edits a checkout that the
user or another agent is working in. Switchboard adds it on a task branch under
`TASK_WORKTREES`, outside the repository, for every harness: `claude -p
--worktree` nests it inside the checkout, where a synced repository (the iCloud
Vault) would copy it to other Macs, and `codex exec --worktree` cannot choose
its base. The base is the freshly fetched upstream when the checkout's branch is
only behind it, so a stale checkout never hands the worker old content; otherwise
it is the checkout's HEAD. When the worker declares success
and leaves its worktree clean, the work is rebased onto the checkout's upstream
(or local branch). If the rebase conflicts, the same harness resolves it once
inside the worktree with the task's contract; if it brought in newer upstream
changes cleanly, the harness re-runs the task's verification on that final
revision. The work is then pushed, and the primary checkout is fast-forwarded
when it can be. If the checkout could not follow (local unpushed commits or
overlapping uncommitted changes) or verification fails, nothing is pushed and
the work stays in its worktree. Only integration is serialized per repository.
Non-Git directories are not supported yet.

Opt-in project data is prepared in a task workspace outside Git. A successful
worker's output is frozen before integration and published afterward; only then
is its disposable Git worktree removed and the task marked done. Failed tasks
retain their data workspace, and publication can be retried from its ticket.

The issue comment and the Cloud wake carry the same result: final state,
integration, which verification ran on the final revision, the side effects the
worker reported outside its worktree, then the worker's own report. Credential-shaped
substrings are replaced in place (`[REDACTED:kind]`) in everything that leaves the host;
the result is always delivered, and the original stays in the private run directory
(directories 0700, files 0600).

`_run` reads the issue once (`snapshot`, timeline paged to its end) and runs exactly that
body, and only if its author, last body editor, the adder of its machine label (matched by
label node id) and every title renamer are allowlisted (`AUTHORIZED`), as are the workflow's
actor and triggering actor (`SWITCHBOARD_ACTOR`, `SWITCHBOARD_TRIGGERING_ACTOR`). Lab hosts
(`LAB_LABELS`, shared with other people) get a read-only board token and never write to the
board: M1 claims the task (`_claim`), and after the lab job reads its `result.md` over SSH,
relays it as untrusted output and sets the state (`_finish`). A trusted host without Cloud
credentials (`WAKE_CONFIG`) leaves `wake-pending` for M1's `_wake` job. The sweep re-queues
only tasks that never ran and forwards only result comments from verified runs.

The sweep (`ctx task _sweep`, run every 15 minutes by a LaunchAgent on M1)
re-queues open tasks that lost their queued job (GitHub expires jobs after 24
hours, e.g. while M3 sleeps), queues a reconciliation in the issue's
concurrency group for tasks left `running` without an active run (which marks
them failed without retrying, because their side effects are unknown), retries
failed Cloud wakes, and publishes the places and models lists.
"""

from __future__ import annotations

import collections
import contextlib
import datetime
import fcntl
import hashlib
import json
import os
import re
import socket
import subprocess
import time
from pathlib import Path

from . import models, places, project_data, secrets_scan
from .core import NotReady, atomic_json

BOARD = "JiehoonKwak/switchboard"
STATE_LABELS = ("running", "done", "failed")
MACHINE_LABELS = ("run:m1", "run:m3", "run:nas", "run:bv")
CLOUD_HARNESSES = ("codex-cloud", "claude-cloud")
MACHINES = {"m1": "m1pro", "m1pro": "m1pro", "m3": "m3max", "m3max": "m3max", "nas": "nas", "bv": "bv"}
WAKE_PENDING = "wake-pending"
ACTIVE_RUN_STATUSES = ("queued", "in_progress", "waiting", "pending", "requested")
OUTCOME = re.compile(r"^\W*SWITCHBOARD-OUTCOME:\s*(done|failed|blocked)\W*$", re.I)
RESULT_HEADER = re.compile(r"^\*\*(\w+)\*\* on `[^`]+` \(run (\d+)[,)]")
SIDE_EFFECTS = re.compile(r"^\W*Side effects\W*?:\W*(.+?)\s*$", re.I | re.M)
COMMENT_LIMIT = 60000
WAKE_LIMIT = 3000
SWEEP_SETTLE = datetime.timedelta(minutes=5)
RUN_ROOT = Path.home() / ".local/state/agent-runs/switchboard"
TASK_WORKTREES = Path.home() / ".local/state/switchboard/worktrees"
LOCK_ROOT = Path.home() / ".local/state/switchboard/locks"
WAKE_CONFIG = Path.home() / ".config/agent-events/.env"
AUTHORIZED = frozenset({"JiehoonKwak"})
LAB_LABELS = ("run:bv",)
MACHINE_LABEL_IDS = {"run:m1": "LA_kwDOVCGiWc8AAAAC75H2Yw", "run:m3": "LA_kwDOVCGiWc8AAAAC75H25g",
                     "run:nas": "LA_kwDOVCGiWc8AAAAC75H3Yg", "run:bv": "LA_kwDOVCGiWc8AAAAC8KLePA"}
TRUSTED_RUNNERS = ("m1pro-", "m3max-", "nas-")
RUNNER_BOT = "github-actions"
LAB_RESULT_LIMIT = 50000
SNAPSHOT_QUERY = (
    "query($owner:String!,$name:String!,$number:Int!,$after:String){repository(owner:$owner,name:$name){"
    "issue(number:$number){number title body url state author{login} editor{login} labels(first:100){nodes{id name}} "
    "timelineItems(first:100,after:$after,itemTypes:[LABELED_EVENT,RENAMED_TITLE_EVENT]){pageInfo{hasNextPage endCursor} "
    "nodes{__typename ... on LabeledEvent{actor{login} label{id name}} ... on RenamedTitleEvent{actor{login}}}}}}}")
class TaskError(Exception):
    pass


HarnessRun = collections.namedtuple("HarnessRun", "code report text worktree")


def gh(*args, input=None, attempts=3):
    for attempt in range(attempts):
        result = subprocess.run(["gh", *args], input=input, text=True, capture_output=True)
        if result.returncode == 0:
            return result.stdout
        if attempt + 1 < attempts:
            time.sleep(10 * (attempt + 1))
    raise subprocess.CalledProcessError(result.returncode, ["gh", *args], result.stdout, result.stderr)


def git(*args, cwd, check=True):
    result = subprocess.run(["git", *args], cwd=cwd, text=True, capture_output=True)
    if check and result.returncode != 0:
        raise TaskError(f"git {' '.join(args)} failed in {cwd}: {result.stderr.strip()[-500:]}")
    return result


def redact(text):
    """Never withhold the text (user decision, 2026-10-10); only credential substrings are replaced."""
    return secrets_scan.redact(text)


def private_dir(path):
    path.mkdir(mode=0o700, parents=True, exist_ok=True)
    path.chmod(0o700)
    return path


@contextlib.contextmanager
def private_open(path, mode="w"):
    """Open a run file as 0600 regardless of the umask, tightening one that already exists."""
    with open(path, mode, opener=lambda name, flags: os.open(name, flags, 0o600)) as file:
        os.chmod(path, 0o600)
        yield file


def private_write(path, text):
    with private_open(path) as file:
        file.write(text)


def parse_fields(body):
    fields = {}
    for match in re.finditer(r"^###\s+(.+?)\s*\n(.*?)(?=^###\s|\Z)", body or "", re.M | re.S):
        value = match.group(2).strip()
        if value and value != "_No response_":
            fields[match.group(1).strip().lower()] = value
    return fields


def resolve_directory(ctx, value):
    path = Path(os.path.expanduser(value))
    if path.is_dir():
        return path
    for project in ctx.registry(cached=True).get("projects", []):
        if value in (project["id"], project.get("label"), *project.get("aliases", [])):
            candidate = project.get("paths", {}).get(ctx.config.host)
            if candidate and Path(candidate).is_dir():
                return Path(candidate)
    raise TaskError(f"Directory not found on this machine: {value}")


def task_base(root, upstream):
    """The commit a task starts from: the freshly fetched upstream when the checkout's branch is behind or equal
    to it, else the checkout's HEAD, whose unpublished commits integration then refuses to publish."""
    head = git("rev-parse", "HEAD", cwd=root).stdout.strip()
    if not upstream:
        return head
    with repository_lock(root):
        git("fetch", "-q", upstream[0], cwd=root, check=False)
    tip = git("rev-parse", "--verify", "-q", f"{upstream[2]}^{{commit}}", cwd=root, check=False).stdout.strip()
    behind = tip and git("merge-base", "--is-ancestor", head, tip, cwd=root, check=False).returncode == 0
    return tip if behind else head


def owner_problem(ctx, directory, host=None):
    """Why host (default: this one) may not run a task in directory: another host alone writes its Git."""
    owner = places.foreign_git_owner(ctx, host or ctx.config.host, directory)
    if not owner:
        return None
    label = places.RUN_LABELS.get(owner, f"run:{owner}")
    return f"this repository's Git owner is {owner}; run on {label} (`ctx task create --machine {label[4:]}`)"


def checkout_of(directory):
    top = git("rev-parse", "--show-toplevel", cwd=directory, check=False)
    if top.returncode != 0:
        raise TaskError(f"{directory} is not a Git repository; tasks outside Git are deferred for now.")
    root = Path(top.stdout.strip())
    branch = git("symbolic-ref", "--quiet", "--short", "HEAD", cwd=root, check=False).stdout.strip()
    if not branch:
        raise TaskError(f"{root} is on a detached HEAD; Switchboard needs a branch to integrate into.")
    tracking = git("rev-parse", "--abbrev-ref", "--symbolic-full-name", f"{branch}@{{upstream}}",
                   cwd=root, check=False).stdout.strip()
    upstream = None
    if tracking:
        remote = git("config", f"branch.{branch}.remote", cwd=root).stdout.strip()
        dest = git("config", f"branch.{branch}.merge", cwd=root).stdout.strip()
        upstream = (remote, dest, tracking)
    focus = os.path.relpath(directory.resolve(), root.resolve())
    return root, branch, upstream, focus


def build_prompt(issue, fields, root, branch, focus, data_ticket=None):
    publish = fields.get("publish", "none")
    parts = [
        f"You are running Switchboard task #{issue['number']} ({issue['url']}) unattended on "
        f"{socket.gethostname()}. Nobody can answer questions or approve actions during the run: "
        "make reasonable decisions within the goal and finish.",
        f"Title: {issue['title']}",
        task_contract(fields, focus),
    ]
    parts.append(
        "You are in a dedicated Git worktree of this repository. Follow the project's AGENTS.md, and "
        "commit your finished work on the current branch; when the task changed no files, make no commit "
        "(no empty commits), because a report is not a change. Do not push, merge, switch branches, or "
        f"synchronize other machines: Switchboard rebases your commits onto `{branch}`, verifies and "
        "publishes them after you finish. Unless the instructions above ask for it, do not deploy, restart "
        f"services, or change files outside this worktree (including the primary checkout at {root}): "
        "anything deployed before integration runs unintegrated code. Publishing to people or public places "
        f"(messages, posts, email, public pages) is allowed only for: {publish}."
    )
    if data_ticket:
        parts.append(
            f"Managed project data is prepared outside this disposable Git worktree at {data_ticket['workspace']}. "
            f"Its pinned input revision is {data_ticket.get('revision') or 'empty'}. Use that workspace for managed "
            "inputs and outputs, keeping the configured relative paths. Writes there are explicitly authorized. "
            "Do not modify another task's data workspace or publish shared data yourself. Stop data writers before "
            "reporting done; Switchboard freezes your output, integrates Git, then publishes the verified data. "
            "Report the data files you changed and the computation verification."
        )
    return "\n\n".join(parts)


def harness_command(fields):
    harness = fields.get("harness", "codex").lower()
    if harness not in models.DEFAULTS:
        raise TaskError(f"Unknown harness {harness!r}; expected {', '.join(models.DEFAULTS)}")
    model, effort = models.setting(harness, fields)
    if harness == "agy":
        level = [] if re.search(r"-(low|medium|high)$", model) else ["--effort", effort]
        return ["agy", "--dangerously-skip-permissions", "--output-format", "json", "--model", model, *level, "-p"]
    if harness == "codex":
        return ["codex", "exec", "--json", "--dangerously-bypass-approvals-and-sandbox",
                "-m", model, "-c", f"model_reasoning_effort={effort}", "-"]
    return ["claude", "-p", "--dangerously-skip-permissions", "--output-format", "stream-json", "--verbose",
            "--model", model, "--effort", effort]


def report_instruction(report_file):
    return (f"When you finish, write your report for the task board to `{report_file}` (overwrite it if anything "
            "changes later): outcome, verification evidence, changed files or artifacts, and anything "
            "unresolved. Include one line `Side effects: none`, or `Side effects:` followed by everything you "
            "changed outside your worktree besides this report (deployments, service restarts, files elsewhere, "
            "messages sent). "
            "Its last line must be exactly one of `SWITCHBOARD-OUTCOME: done`, `SWITCHBOARD-OUTCOME: failed`, "
            "or `SWITCHBOARD-OUTCOME: blocked`.")


def run_harness(fields, prompt, cwd, run_dir, label, worktree_name=None, base="HEAD"):
    output = run_dir / f"{label}.md"
    report_file = run_dir / f"{label}.report.md"
    report_file.unlink(missing_ok=True)
    prompt = f"{prompt}\n\n{report_instruction(report_file)}"
    harness = fields.get("harness", "codex").lower()
    command, stdin, workdir = harness_command(fields), prompt, cwd
    if harness == "agy":
        command, stdin = [*command, prompt], None
    if worktree_name:
        workdir = TASK_WORKTREES / worktree_name
        git("worktree", "add", "-b", worktree_name, str(workdir), base, cwd=cwd)
    env_with_machine_gh_login = {k: v for k, v in os.environ.items() if k not in ("GH_TOKEN", "GITHUB_TOKEN")}
    if harness == "claude" and fields.get("_hosted_subscription") is True:
        from .switchboard_cloud import subscription_environment
        env_with_machine_gh_login = subscription_environment(env_with_machine_gh_login)
        command = [*command, "--setting-sources", "user"]
    run_identity = re.fullmatch(r"\d+-(\d+)", run_dir.name)
    env_with_machine_gh_login.update(CTX_INBOX_BACKGROUND="1", CTX_INBOX_RUN_ID=run_identity[1] if run_identity else "")
    with private_open(run_dir / f"{label}.log") as log:
        result = subprocess.run(command, cwd=workdir, input=stdin, stdin=subprocess.DEVNULL if stdin is None else None,
                                text=True, stdout=subprocess.PIPE, stderr=log, env=env_with_machine_gh_login)
    private_write(run_dir / f"{label}.events.jsonl", result.stdout)
    if report_file.exists():
        report_file.chmod(0o600)
    report = report_file.read_text().strip() if report_file.exists() else None
    text = report if report is not None else last_message(result.stdout).strip()
    private_write(output, text)
    return HarnessRun(result.returncode, report, text, workdir if worktree_name else None)


def last_message(stream):
    texts = []
    for line in stream.splitlines():
        event = json.loads(line) if line.startswith("{") else {}
        if event.get("type") == "assistant":
            texts += [part["text"] for part in event["message"]["content"] if part.get("type") == "text"]
        if event.get("response"):
            texts.append(event["response"])
        item = event.get("item") or {}
        if event.get("type") == "item.completed" and item.get("type") == "agent_message":
            texts.append(item.get("text", ""))
    return next((text for text in reversed(texts) if text.strip()), "")


def declared_outcome(message):
    lines = [line for line in message.splitlines() if line.strip()]
    match = OUTCOME.match(lines[-1]) if lines else None
    return match.group(1).lower() if match else None


def outcome_of(run):
    if run.code != 0:
        return "failed", f"The harness exited with code {run.code}."
    if run.report is None:
        return "failed", "The worker did not write its report file, so its outcome is not accepted."
    declared = declared_outcome(run.report)
    if not declared:
        return "failed", "The report does not end with a SWITCHBOARD-OUTCOME line."
    return declared, ""


def side_effects_of(text):
    declared = SIDE_EFFECTS.findall(text or "")
    return declared[-1] if declared else "not reported"


@contextlib.contextmanager
def repository_lock(root):
    common = Path(git("rev-parse", "--git-common-dir", cwd=root).stdout.strip())
    key = str((root / common).resolve())
    LOCK_ROOT.mkdir(parents=True, exist_ok=True)
    with open(LOCK_ROOT / f"{hashlib.sha1(key.encode()).hexdigest()}.lock", "w") as handle:
        fcntl.flock(handle, fcntl.LOCK_EX)
        yield


def task_contract(fields, focus):
    labels = {"goal": "Goal", "verify": "How to verify", "context": "Context", "prompt": "Instructions"}
    parts = [f"{label}:\n{fields[key]}" for key, label in labels.items() if key in fields]
    if focus != ".":
        parts.insert(1, f"Focus directory within this repository: {focus}")
    return "\n\n".join(parts)


VERIFY_EVERY_CHECK = ("Run every check in the task's verification. Temporary fixtures a check needs go in a fresh "
                      "directory under the system temporary directory, removed afterwards. Do not deploy, restart "
                      "services, or change anything else outside this worktree; a check that cannot run without that "
                      "is not skipped: the outcome is then `blocked`. The outcome is `done` only if every check ran "
                      "and passed.")


def rebase_onto(worktree, onto, fields, focus, run_dir, issue, stages, allow_resolver=True):
    """Rebase the task's work onto `onto`; return True when the resolver had to (and did) verify it."""
    if git("merge-base", "--is-ancestor", onto, "HEAD", cwd=worktree, check=False).returncode == 0:
        return False
    if git("rebase", onto, cwd=worktree, check=False).returncode == 0:
        return False
    git("rebase", "--abort", cwd=worktree, check=False)
    if not allow_resolver:
        raise TaskError(f"Rebasing onto {onto} conflicted again after a rejected push; the work stays in {worktree}.")
    prompt = (f"Switchboard task #{issue['number']} ({issue['title']}) finished its work on this branch, but "
              f"rebasing it onto `{onto}` conflicts. Rebase the current branch onto `{onto}`, resolving every "
              "conflict so that the task's goal still holds and the upstream changes keep their intent, and leave "
              "the rebased work committed with a clean worktree. Do not push or merge. Then verify the result. "
              f"{VERIFY_EVERY_CHECK}\n\nThe task:\n\n{task_contract(fields, focus)}")
    run = run_harness(fields, prompt, worktree, run_dir, "integration")
    stages.append(("Conflict resolution report", run.text))
    rebased = git("merge-base", "--is-ancestor", onto, "HEAD", cwd=worktree, check=False).returncode == 0
    clean = not git("status", "--porcelain", cwd=worktree).stdout.strip()
    if not (rebased and clean and outcome_of(run)[0] == "done"):
        raise TaskError(f"Rebasing onto {onto} conflicted and the integration run did not resolve it; "
                        f"the work stays in {worktree}.")
    return True


def verify_final_revision(worktree, fields, focus, run_dir, issue, stages):
    head = git("rev-parse", "HEAD", cwd=worktree).stdout.strip()
    prompt = (f"This worktree holds Switchboard task #{issue['number']} ({issue['title']}), rebased onto newer "
              "upstream commits after the task finished. Check that the task still holds on this revision. Do "
              f"not edit or commit files in this worktree. {VERIFY_EVERY_CHECK}\n\nThe task:\n\n{task_contract(fields, focus)}")
    run = run_harness({**fields, "effort": "low"}, prompt, worktree, run_dir, "verify")
    stages.append(("Final-revision check report", run.text))
    unchanged = (git("rev-parse", "HEAD", cwd=worktree).stdout.strip() == head
                 and not git("status", "--porcelain", cwd=worktree).stdout.strip())
    if not unchanged:
        raise TaskError(f"The final-revision verification changed the worktree; nothing was published, and the "
                        f"work stays in {worktree}.")
    if outcome_of(run)[0] != "done":
        raise TaskError(f"The task's verification did not pass on {head[:8]}, the work rebased onto newer "
                        f"upstream changes (report below); nothing was published, and the work stays in {worktree}.")
    return f"re-run by Switchboard on {head[:8]}, whose content is the published content, and passed (report below)"


def tree_of(worktree):
    return git("rev-parse", "HEAD^{tree}", cwd=worktree).stdout.strip()


def integrate(root, branch, upstream, worktree, base, fields, focus, run_dir, issue, stages, *, cleanup=True,
              validate_final=None):
    """Publish the task's commits; return (integration note, verification note)."""
    if git("status", "--porcelain", cwd=worktree).stdout.strip():
        raise TaskError(f"The worker left uncommitted changes, so nothing was integrated; the work stays in {worktree}.")
    head = git("rev-parse", "HEAD", cwd=worktree).stdout.strip()
    if head == base:
        if validate_final:
            validate_final(worktree)
        if cleanup:
            remove_worktree(root, worktree)
        return ("no commits to integrate; " + ("the worktree was removed" if cleanup else "data publication pending"),
                "worker-reported only (below)")
    verified = {tree_of(worktree): "worker-reported only (below); the final revision has the same content"}
    with repository_lock(root):
        for attempt in range(2):
            if upstream:
                git("fetch", "-q", upstream[0], cwd=root)
            onto = upstream[2] if upstream else branch
            unpublished = any(git("merge-base", "--is-ancestor", ref, onto, cwd=root, check=False).returncode
                              for ref in (branch, base))
            if upstream and unpublished:
                raise TaskError(f"`{branch}` at {root} has commits that are not on `{onto}`; nothing was published, "
                                f"and the work stays in {worktree}. Push or reconcile the checkout, then retry.")
            if rebase_onto(worktree, onto, fields, focus, run_dir, issue, stages, allow_resolver=attempt == 0):
                verified[tree_of(worktree)] = "re-run by the conflict resolver on the rebased content (report below)"
            if tree_of(worktree) not in verified:
                verified[tree_of(worktree)] = (verify_final_revision(worktree, fields, focus, run_dir, issue, stages)
                                               if "verify" in fields else "none; the task has no Verify section")
            head = git("rev-parse", "HEAD", cwd=worktree).stdout.strip()
            ensure_checkout_can_advance(root, branch, head, worktree)
            if validate_final:
                validate_final(worktree)
            if not upstream:
                break
            remote, dest, _ = upstream
            if git("push", "-q", remote, f"HEAD:{dest}", cwd=worktree, check=False).returncode == 0:
                break
            if attempt:
                raise TaskError(f"Publishing to `{remote} {dest}` was rejected twice; nothing changed in {root}, "
                                f"and the work stays in {worktree}.")
        advanced = git("merge", "--ff-only", "-q", head, cwd=root, check=False).returncode == 0
    if not upstream and not advanced:
        raise TaskError(f"The checkout at {root} changed during integration and could not be fast-forwarded; "
                        f"the work stays in {worktree}.")
    if not upstream:
        note = f"committed {head[:8]} to local `{branch}` at {root} (no upstream to push to)"
    elif advanced:
        note = f"pushed {head[:8]} to `{upstream[0]} {upstream[1]}` and fast-forwarded {root}"
    else:
        note = (f"pushed {head[:8]} to `{upstream[0]} {upstream[1]}`; {root} changed meanwhile and was not "
                "fast-forwarded, so pull it")
    verification = verified[tree_of(worktree)]
    if cleanup:
        remove_worktree(root, worktree)
    return note, verification


def dirty_paths(root):
    entries = git("status", "--porcelain=v1", "-z", "--untracked-files=all", cwd=root).stdout.split("\0")
    paths, index = set(), 0
    while index < len(entries):
        entry = entries[index]
        if entry:
            paths.add(entry[3:])
            if entry[0] in "RC":
                index += 1
                paths.add(entries[index])
        index += 1
    return paths


def ensure_checkout_can_advance(root, branch, head, worktree):
    current = git("symbolic-ref", "--quiet", "--short", "HEAD", cwd=root, check=False).stdout.strip()
    if current != branch:
        raise TaskError(f"The checkout at {root} is no longer on `{branch}`; the work stays in {worktree}.")
    if git("merge-base", "--is-ancestor", "HEAD", head, cwd=root, check=False).returncode:
        raise TaskError(f"The checkout at {root} moved away from the rebased work; the work stays in {worktree}.")
    changed = set(filter(None, git("diff", "--name-only", "-z", "HEAD", head, cwd=root).stdout.split("\0")))
    dirty = dirty_paths(root)
    overlap = sorted(c for c in changed for d in dirty
                     if c == d or c.startswith(d.rstrip("/") + "/") or d.startswith(c + "/"))
    if overlap:
        raise TaskError(f"Uncommitted changes in {root} overlap the task's changes ({', '.join(overlap[:5])}); "
                        f"nothing was published, and the work stays in {worktree}.")


def remove_worktree(root, worktree):
    branch = git("symbolic-ref", "--quiet", "--short", "HEAD", cwd=worktree, check=False).stdout.strip()
    git("worktree", "unlock", str(worktree), cwd=root, check=False)
    git("worktree", "remove", "--force", str(worktree), cwd=root, check=False)
    if branch:
        git("branch", "-D", branch, cwd=root, check=False)


def ensure_external_data_workspace(worktree, ticket):
    misplaced = project_data.files(worktree, ticket["config"])
    if misplaced:
        raise TaskError("Managed data was written inside the disposable Git worktree instead of "
                        f"{ticket['workspace']}: " + ", ".join(misplaced[:10]) +
                        "; worktree and external outputs retained. Preserve it and prepare a corrected candidate before retrying.")


def set_state(repo, number, state, *extra_labels):
    gh("issue", "edit", str(number), "--repo", repo, "--add-label", ",".join((state, *extra_labels)),
       *[arg for other in STATE_LABELS if other != state for arg in ("--remove-label", other)])


def comment(repo, number, text):
    text = redact(text)
    if len(text) > COMMENT_LIMIT:
        text = text[:COMMENT_LIMIT] + "\n\n…(truncated; full output in the run directory)"
    gh("issue", "comment", str(number), "--repo", repo, "--body-file", "-", input=text)


def wake_cloud(issue, status, result, event_id):
    result = redact(result)
    if len(result) > WAKE_LIMIT:
        result = result[:WAKE_LIMIT] + "\n\n…(truncated; read the issue comment)"
    body = redact(f"Switchboard task #{issue['number']} {status}: {issue['title']}\n{issue['url']}\n\n{result}")
    sent = subprocess.run(["send2cloud", "--title", f"Switchboard #{issue['number']} {status}",
                           "--event-id", event_id], input=body, text=True, capture_output=True)
    return sent.returncode == 0


def compose_result(status, run_id, run_dir, facts, sections=(), host=None, note=""):
    host = host or socket.gethostname().split(".")[0]
    where = f", `{run_dir}`" if run_dir else ""
    lines = [f"**{status}** on `{host}` (run {run_id}{note}{where})", ""]
    lines += [f"- {name}: {value}" for name, value in facts if value]
    for title, text in sections:
        lines += ["", "---", "", f"{title}:", "", text]
    return "\n".join(lines)


def close_done(repo, number, status):
    """Close a `done` task once its result is delivered, so open issues are only tasks that need someone.
    `failed` stays open until it is retried in place or superseded; an orchestrator reopens a rejected result."""
    if status == "done":
        gh("issue", "close", str(number), "--repo", repo, "--reason", "completed")


def report(repo, issue, fields, status, result, run_id):
    comment(repo, issue["number"], result)
    notify = fields.get("notify", "cloud").lower() != "none"
    set_state(repo, issue["number"], status, *([WAKE_PENDING] if notify else []))
    if notify and not WAKE_CONFIG.exists():
        print(f"#{issue['number']} wake left pending for M1 (no Cloud credentials on this host)")
    elif notify and wake_cloud(issue, status, result, f"switchboard:{issue['number']}:{run_id}"):
        gh("issue", "edit", str(issue["number"]), "--repo", repo, "--remove-label", WAKE_PENDING)
        close_done(repo, issue["number"], status)
    elif not notify:
        close_done(repo, issue["number"], status)


def snapshot(repo, number):
    """The issue as one read: the body, title and labels that run are the ones the gate checks.
    The timeline is paged to its end, so no labelling or rename is missed however long the issue is."""
    owner, name = repo.split("/")
    issue, events, after = None, [], None
    while True:
        args = ["api", "graphql", "-f", f"query={SNAPSHOT_QUERY}", "-F", f"owner={owner}", "-F", f"name={name}",
                "-F", f"number={number}", *(["-f", f"after={after}"] if after else [])]
        page = json.loads(gh(*args))["data"]["repository"]["issue"]
        issue = issue or page
        events += page["timelineItems"]["nodes"]
        info = page["timelineItems"]["pageInfo"]
        if not info["hasNextPage"]:
            break
        after = info["endCursor"]
    return {**{key: value for key, value in issue.items() if key != "timelineItems"},
            "labels": issue["labels"]["nodes"], "events": events}


def label_names(issue):
    return {label["name"] for label in issue["labels"]}


def authorization_problem(issue, machine, environ=os.environ):
    """Why this task may not run, or None. Only the owner may write, edit, rename, label or trigger a task;
    machine labels are matched by node id, so renaming a repository label cannot redirect a task."""
    for name in ("SWITCHBOARD_ACTOR", "SWITCHBOARD_TRIGGERING_ACTOR"):
        if environ.get(name) not in AUTHORIZED:
            return f"the workflow actor ({name}={environ.get(name) or 'unset'}) is not authorized"
    login = lambda actor: (actor or {}).get("login")
    if login(issue["author"]) not in AUTHORIZED:
        return f"the issue author ({login(issue['author'])}) is not authorized"
    if issue["editor"] and login(issue["editor"]) not in AUTHORIZED:
        return f"the issue body was last edited by {login(issue['editor'])}, who is not authorized"
    events = issue["events"]
    renamers = {login(event.get("actor")) for event in events if event["__typename"] == "RenamedTitleEvent"}
    if renamers - AUTHORIZED:
        return f"the title was changed by {', '.join(sorted(map(str, renamers - AUTHORIZED)))}, who is not authorized"
    for label in issue["labels"]:
        if label["name"].startswith("run:") and MACHINE_LABEL_IDS.get(label["name"]) != label["id"]:
            return f"the `{label['name']}` label is not the board's machine label (renamed or recreated)"
    expected = MACHINE_LABEL_IDS.get(machine)
    labelled = [login(event.get("actor")) for event in events
                if event["__typename"] == "LabeledEvent" and (event.get("label") or {}).get("id") == expected]
    if not expected or not labelled or labelled[-1] not in AUTHORIZED:
        return f"the `{machine}` label was not added by an authorized user"
    return None


def superseded_numbers(fields, own):
    return sorted({int(n) for n in re.findall(r"#?(\d+)", fields.get("supersedes", ""))} - {int(own)})


def close_superseded(repo, issue, fields):
    """Close the tasks this one replaces (`### Supersedes`), so a replacement leaves one open issue, not two.
    Only open, owner-written tasks that are not running are closed; a failure here never stops the task."""
    for number in superseded_numbers(fields, issue["number"]):
        try:
            old = json.loads(gh("issue", "view", str(number), "--repo", repo, "--json", "state,labels,author"))
            if old["state"] != "OPEN" or (old.get("author") or {}).get("login") not in AUTHORIZED:
                continue
            if "running" in label_names(old):
                print(f"#{number} is running; not closed as superseded by #{issue['number']}")
                continue
            gh("issue", "close", str(number), "--repo", repo, "--reason", "not planned",
               "--comment", f"Superseded by #{issue['number']}.")
            print(f"#{number} closed as superseded by #{issue['number']}")
        except (subprocess.CalledProcessError, ValueError, KeyError) as error:
            print(f"#{number} not closed as superseded: {error}")


def refusal_text(run_id, refusal):
    return (f"**refused** on `{socket.gethostname().split('.')[0]}` (run {run_id}): {refusal}; no harness ran. "
            "Only allowlisted users may author, edit, label or trigger tasks.")


def startable(issue, machine, claimed=False):
    states = label_names(issue).intersection(STATE_LABELS)
    return issue["state"] == "OPEN" and machine in label_names(issue) and states == ({"running"} if claimed else set())


def claim(ctx, repo, number, machine, run_id):
    """On M1, before a lab host runs a task: gate it and set `running`, because the lab job cannot write."""
    issue = snapshot(repo, number)
    claimed = False
    host = next(name for name, label in places.RUN_LABELS.items() if label == machine)
    directory = parse_fields(issue["body"]).get("directory")
    if not startable(issue, machine):
        print(f"#{number} skipped: state={issue['state']} labels={sorted(label_names(issue))}")
    elif refusal := authorization_problem(issue, machine):
        comment(repo, number, refusal_text(run_id, refusal))
        set_state(repo, number, "failed")
        print(f"#{number} refused: {refusal}")
    elif directory and (problem := owner_problem(ctx, directory, host)):
        comment(repo, number, compose_result("failed", run_id, None, [("Problem", f"refused before running: {problem}")], host=host))
        set_state(repo, number, "failed")
        print(f"#{number} refused: {problem}")
    else:
        set_state(repo, number, "running")
        close_superseded(repo, issue, parse_fields(issue["body"]))
        claimed = True
    if os.environ.get("GITHUB_OUTPUT"):
        with open(os.environ["GITHUB_OUTPUT"], "a") as output:
            output.write(f"claimed={'true' if claimed else 'false'}\n")
    return 0


def read_lab_result(host, number, run_id):
    """The lab host's result.md for this run over SSH, capped; None when it cannot be read."""
    path = f".local/state/agent-runs/switchboard/{int(number)}-{int(run_id)}/result.md"
    try:
        result = subprocess.run(["ssh", "-o", "BatchMode=yes", "-o", "ConnectTimeout=10", host,
                                 f"head -c {LAB_RESULT_LIMIT + 1} {path}"], capture_output=True, timeout=60, check=False)
    except subprocess.TimeoutExpired:
        return None
    return result.stdout.decode("utf-8", errors="replace") if result.returncode == 0 and result.stdout else None


def finish_lab(repo, number, machine, run_id, job_result):
    """On M1, after a lab host ran a task: relay its result as untrusted data and do every board write."""
    issue = snapshot(repo, number)
    if issue["state"] != "OPEN" or "running" not in label_names(issue):
        print(f"#{number} needs no lab finish")
        return 0
    host = next(name for name, label in places.RUN_LABELS.items() if label == machine)
    text = read_lab_result(host, number, run_id)
    header = RESULT_HEADER.match(text or "")
    reported = header.group(1) if header and header.group(2) == str(run_id) else None
    status = "done" if reported == "done" and job_result == "success" else "failed"
    if text is None:
        problem = f"no result could be read from `{host}` for this run (lab job {job_result})"
    elif reported is None:
        problem = f"`{host}`'s result does not carry this run's header (lab job {job_result})"
    else:
        problem = None if status == "done" else f"`{host}` reported `{reported}` (lab job {job_result})"
    if text and len(text) > LAB_RESULT_LIMIT:
        text = text[:LAB_RESULT_LIMIT] + "\n\n…(truncated; full output on the lab host)"
    facts = [("Problem", problem),
             ("Lab host", f"`{host}` ran the task; the output below is its own and was not checked by M1")]
    sections = [("Lab-host output (untrusted)", redact(text))] if text else []
    result = compose_result(status, run_id, None, facts, sections, host=host, note=", lab-host output relayed by M1")
    report(repo, issue, parse_fields(issue["body"]), status, result, run_id)
    print(f"#{number} {status} (lab)")
    return 0 if status == "done" else 1


def cloud_problem(fields, host):
    if fields.get('harness', '').lower() not in CLOUD_HARNESSES:
        return None
    if host != 'm1pro':
        return 'hosted Cloud tasks must be submitted and supervised on M1 (run:m1)'
    if not any(line.strip() for line in fields.get('data paths', '').splitlines()):
        return 'hosted Cloud tasks require nonempty ### Data Paths for selected NAS inputs and outputs'
    if fields.get('model') or fields.get('effort'):
        return 'hosted Cloud tasks use the pinned Jstack environment model/effort defaults'
    return None


def run_cloud_task(ctx, repo, issue, fields, root, branch, upstream, base, focus, run_dir, run_id):
    from . import switchboard_cloud
    outcome = switchboard_cloud.run(ctx, issue, fields, root, branch, upstream, base, focus, run_dir)
    status = outcome['status']
    facts = [("Problem", outcome.get('problem')), ("Integration", outcome.get('integration')),
             ("Verification", outcome.get('verification')), ("Project data", outcome.get('data_note'))]
    result = compose_result(status, run_id, run_dir, facts, outcome.get('sections', ()))
    private_write(run_dir / 'result.md', result)
    if status == 'pending':
        print(f"#{issue['number']} Cloud pending; M1 will resume the same submitted task")
        return 0
    report(repo, issue, fields, 'done' if status == 'done' else 'failed', result, run_id)
    print(f"#{issue['number']} {status}")
    return 0 if status == 'done' else 1


def run_task(ctx, repo, number, machine, run_id):
    issue = snapshot(repo, number)
    lab = machine in LAB_LABELS
    if not startable(issue, machine, claimed=lab):
        print(f"#{number} skipped: state={issue['state']} labels={sorted(label_names(issue))}")
        return 0
    run_dir = private_dir(private_dir(RUN_ROOT) / f"{number}-{run_id}")
    refusal = authorization_problem(issue, machine)
    if refusal:
        if lab:
            private_write(run_dir / "result.md", refusal_text(run_id, refusal))
        else:
            comment(repo, number, refusal_text(run_id, refusal))
            set_state(repo, number, "failed")
        print(f"#{number} refused: {refusal}")
        return 1
    fields = parse_fields(issue["body"])
    if not lab:
        set_state(repo, number, "running")
        close_superseded(repo, issue, fields)
    run, problem, integration, verification, stages = None, None, None, None, []
    data_ticket, data_note = None, None
    try:
        if "goal" not in fields or "directory" not in fields:
            raise TaskError("The task needs at least `### Directory` and `### Goal` sections.")
        if fields.get('harness', '').lower() in CLOUD_HARNESSES:
            if machine != 'run:m1':
                raise TaskError('hosted Cloud tasks require the run:m1 machine label')
            if problem := cloud_problem(fields, ctx.config.host):
                raise TaskError(problem)
        root, branch, upstream, focus = checkout_of(resolve_directory(ctx, fields["directory"]))
        if problem := owner_problem(ctx, str(root)):
            raise TaskError(f"Refused before running: {problem}.")
        base = task_base(root, upstream)
        if fields.get('harness', '').lower() in CLOUD_HARNESSES:
            previous_dir, _ = retained_cloud_state(number, required=False)
            if previous_dir is not None:
                run_dir = previous_dir
            return run_cloud_task(ctx, repo, issue, fields, root, branch, upstream, base, focus, run_dir, run_id)
        data_ticket = project_data.prepare(ctx, root, f"switchboard-{number}-{run_id}")
        if data_ticket:
            data_note = f"prepared ticket {data_ticket['id']}; output retained at {data_ticket['workspace']}"
        run = run_harness(fields, build_prompt(issue, fields, root, branch, focus, data_ticket), root, run_dir,
                          "final", worktree_name=f"switchboard-{number}-{run_id}", base=base)
        status, problem = outcome_of(run)
        worktree = run.worktree
        if worktree is None or not worktree.is_dir():
            if status == "done":
                status, problem = "failed", "The harness worktree could not be found."
            integration = "not attempted"
        elif status != "done":
            untouched = (git("rev-parse", "HEAD", cwd=worktree).stdout.strip() == base
                         and not git("status", "--porcelain", cwd=worktree).stdout.strip())
            if untouched and not data_ticket:
                remove_worktree(root, worktree)
                integration = "not attempted; the worktree had no changes and was removed"
            else:
                integration = f"not attempted; the work stays in `{worktree}` for inspection"
        else:
            try:
                if data_ticket:
                    ensure_external_data_workspace(worktree, data_ticket)
                    data_ticket = project_data.freeze(ctx, data_ticket, worktree)
                    data_note = f"frozen ticket {data_ticket['id']}; publication pending; output at {data_ticket['workspace']}"
                    ensure_external_data_workspace(worktree, data_ticket)
                integration, verification = integrate(root, branch, upstream, worktree, base, fields, focus,
                                                      run_dir, issue, stages, cleanup=not bool(data_ticket))
                if data_ticket:
                    ensure_external_data_workspace(worktree, data_ticket)
                    receipt = project_data.publish(ctx, data_ticket, integrated_root=worktree)
                    data_note = f"published ticket {data_ticket['id']}; revision {receipt.get('revision', '-')}; output at {data_ticket['workspace']}"
                    ensure_external_data_workspace(worktree, data_ticket)
                    remove_worktree(root, worktree)
            except (TaskError, NotReady) as error:
                status, problem = "failed", str(error)
                integration = integration or f"not completed: {error}"
    except (TaskError, NotReady) as error:
        status, problem = "failed", str(error)

    facts = [("Problem", problem), ("Integration", integration), ("Verification", verification), ("Project data", data_note)]
    sections = [("Worker report (written before integration)", run.text)] + stages if run else []
    if run:
        effects = [f"{title.split(' report')[0].lower()}: {side_effects_of(text)}" for title, text in sections]
        facts.append(("Side effects reported", "; ".join(effects)))
    result = compose_result(status, run_id, run_dir, facts, sections)
    private_write(run_dir / "result.md", result)
    if lab:
        print(f"#{number} {status}; M1's lab-finish job reports it")
    else:
        report(repo, issue, fields, "done" if status == "done" else "failed", result, run_id)
        print(f"#{number} {status}")
    return 0 if status == "done" else 1


def retained_cloud_state(number, *, required=True):
    markers = [path for path in RUN_ROOT.glob(f'{number}-*/cloud-state.json')
               if not path.is_symlink() and not path.parent.is_symlink()]
    if not markers:
        if not required:
            return None, None
        raise NotReady('No retained Cloud submission exists; recovery will not submit another task')
    marker = max(markers, key=lambda path: path.stat().st_mtime_ns)
    state = json.loads(marker.read_text())
    if not isinstance(state, dict):
        raise NotReady('Invalid retained Cloud submission state')
    return marker.parent, state


def cloud_attach(ctx, repo, number, url):
    """Authorize a known hosted URL, then resume M1's existing supervision workflow."""
    from . import switchboard_cloud
    if ctx.config.host != 'm1pro':
        raise NotReady('Cloud task attachment must run on M1')
    issue = snapshot(repo, number)
    if issue['state'] != 'OPEN' or not {'run:m1', 'running'} <= label_names(issue):
        raise NotReady('Cloud attachment requires an open running task on run:m1')
    actors = os.environ
    if not any(key in actors for key in ('GITHUB_RUN_ID', 'SWITCHBOARD_ACTOR', 'SWITCHBOARD_TRIGGERING_ACTOR')):
        actor = gh('api', 'user', '--jq', '.login').strip()
        actors = {**actors, 'SWITCHBOARD_ACTOR': actor, 'SWITCHBOARD_TRIGGERING_ACTOR': actor}
    if refusal := authorization_problem(issue, 'run:m1', environ=actors):
        raise NotReady('Refused before Cloud attachment: ' + refusal)
    fields = parse_fields(issue['body'])
    if fields.get('harness', '').lower() != 'codex-cloud':
        raise NotReady('Cloud web attachment is available only for codex-cloud')
    if problem := cloud_problem(fields, ctx.config.host):
        raise NotReady(problem)
    root, _, _, focus = checkout_of(resolve_directory(ctx, fields['directory']))
    if problem := owner_problem(ctx, str(root)):
        raise NotReady('Refused before Cloud attachment: ' + problem)
    run_dir, _ = retained_cloud_state(number)
    attached = switchboard_cloud.attach(ctx, issue, fields, root, focus, run_dir, url)
    try:
        gh('workflow', 'run', 'run.yml', '--repo', repo, '-f', f'issue={number}', '-f', 'machine=reconcile')
        resume = 'queued'
    except subprocess.CalledProcessError:
        resume = 'pending; attachment retained for the next M1 sweep'
    return {**attached, 'number': number, 'resume': resume}


def reconcile(repo, number, run_id, *, ctx=None):
    issue = json.loads(gh("issue", "view", str(number), "--repo", repo, "--json", "number,title,body,url,labels,state"))
    if issue["state"] != "OPEN" or "running" not in {label["name"] for label in issue["labels"]}:
        print(f"#{number} needs no reconciliation")
        return 0
    fields = parse_fields(issue['body'])
    if fields.get('harness', '').lower() in CLOUD_HARNESSES:
        issue = snapshot(repo, number)
        if issue['state'] != 'OPEN' or 'running' not in label_names(issue):
            print(f'#{number} needs no Cloud reconciliation')
            return 0
        fields = parse_fields(issue['body'])
        try:
            if ctx is None or ctx.config.host != 'm1pro' or 'run:m1' not in label_names(issue):
                raise TaskError('hosted Cloud recovery requires M1 and the run:m1 machine label')
            if refusal := authorization_problem(issue, 'run:m1'):
                raise TaskError('Refused before Cloud recovery: ' + refusal)
            if fields.get('harness', '').lower() not in CLOUD_HARNESSES:
                raise TaskError('Cloud task contract changed during recovery')
            if problem := cloud_problem(fields, ctx.config.host):
                raise TaskError(problem)
            run_dir, state = retained_cloud_state(number)
            browser_recovery = (state.get('submission') == 'browser'
                                and state.get('phase') in ('awaiting_browser', 'submitting', 'submission_unknown'))
            if not state.get('cloud_task') and state.get('phase') != 'awaiting_submission' and not browser_recovery:
                raise TaskError('Cloud submission identity is unknown; recover its provider ID before resuming; '
                                'no automatic resubmission')
            root, branch, upstream, focus = checkout_of(resolve_directory(ctx, fields['directory']))
            if problem := owner_problem(ctx, str(root)):
                raise TaskError('Refused before Cloud recovery: ' + problem)
            base = task_base(root, upstream)
            return run_cloud_task(ctx, repo, issue, fields, root, branch, upstream, base, focus, run_dir, run_id)
        except (TaskError, NotReady, OSError, ValueError, KeyError, TypeError) as error:
            result = compose_result('failed', run_id, None, [('Problem', str(error))])
            report(repo, issue, fields, 'failed', result, run_id)
            print(f'#{number} Cloud recovery refused: {error}')
            return 1
    problem = ("interrupted: the run stopped before reporting (runner or machine went down). It is not retried "
               "automatically because its side effects are unknown; inspect its worktree and target repository, "
               "then remove `failed` and re-add the machine label to run it again.")
    labels = {label["name"] for label in issue["labels"]}
    host = next((name for name, label in places.RUN_LABELS.items() if label in labels), None)
    result = compose_result("failed", run_id, None, [("Problem", problem)], host=host,
                            note=f", reconciled by {socket.gethostname().split('.')[0]}" if host else "")
    report(repo, issue, parse_fields(issue["body"]), "failed", result, run_id)
    print(f"#{number} marked failed (interrupted)")
    return 0


def issues_with_active_runs(repo):
    active = set()
    for status in ACTIVE_RUN_STATUSES:
        runs = json.loads(gh("run", "list", "--repo", repo, "--status", status, "--limit", "200",
                             "--json", "displayTitle"))
        active.update(int(m.group(1)) for m in (re.match(r"#(\d+) ", run["displayTitle"]) for run in runs) if m)
    return active


def retry_wake(issue, status, result, event_id):
    known = subprocess.run(["send2cloud", "status", event_id], text=True, capture_output=True)
    state = json.loads(known.stdout).get("status") if known.returncode == 0 else None
    if state == "delivered":
        return True
    if state == "failed":
        return subprocess.run(["send2cloud", "retry", event_id], text=True, capture_output=True).returncode == 0
    if state is None:
        return wake_cloud(issue, status, result, event_id)
    return False


def retry_wakes(repo, run_id):
    issues = json.loads(gh("issue", "list", "--repo", repo, "--state", "all", "--label", WAKE_PENDING,
                           "--limit", "100", "--json", "number,title,url,labels,comments,state"))
    settled_before = datetime.datetime.now(datetime.timezone.utc) - SWEEP_SETTLE
    attempted = delivered = 0
    for issue in issues:
        last = run_result(repo, issue)
        if not last:
            continue
        if datetime.datetime.fromisoformat(last["createdAt"].replace("Z", "+00:00")) > settled_before:
            continue
        attempted += 1
        delivered += deliver_wake(repo, issue, last)
    return {"attempted": attempted, "delivered": delivered, "pending": len(issues) - delivered}


def trusted_run(repo, number, run_id):
    """Whether `run_id` is a run of the board workflow for this issue with a job on a trusted host."""
    try:
        run = json.loads(gh("api", f"repos/{repo}/actions/runs/{run_id}", attempts=1))
        jobs = json.loads(gh("api", f"repos/{repo}/actions/runs/{run_id}/jobs", attempts=1))["jobs"]
    except (subprocess.CalledProcessError, ValueError, KeyError):
        return False
    return (run.get("path", "").endswith("/run.yml") and run.get("display_title", "").startswith(f"#{number} ")
            and any((job.get("runner_name") or "").startswith(TRUSTED_RUNNERS) for job in jobs))


def run_result(repo, issue):
    """The latest result comment, if the runner bot posted it from a verified run; a forged one is never forwarded."""
    for item in reversed(issue["comments"]):
        header = RESULT_HEADER.match(item["body"])
        if header and (item.get("author") or {}).get("login") == RUNNER_BOT:
            if trusted_run(repo, issue["number"], header.group(2)):
                return item
            print(f"#{issue['number']} latest result comment is not from a verified run; not forwarded")
            return None
    return None


def deliver_wake(repo, issue, result):
    status = next((label["name"] for label in issue["labels"] if label["name"] in ("done", "failed")), "updated")
    run = RESULT_HEADER.match(result["body"]).group(2)
    if not retry_wake(issue, status, result["body"], f"switchboard:{issue['number']}:{run}"):
        return False
    gh("issue", "edit", str(issue["number"]), "--repo", repo, "--remove-label", WAKE_PENDING)
    if issue.get("state", "OPEN") == "OPEN":
        close_done(repo, issue["number"], status)
    print(f"#{issue['number']} wake delivered")
    return True


def wake(repo, number):
    """Deliver a task's pending wake now from a host holding Cloud credentials (M1's `wake` job)."""
    issue = json.loads(gh("issue", "view", str(number), "--repo", repo, "--json", "number,title,url,labels,comments,state"))
    if WAKE_PENDING not in label_names(issue):
        print(f"#{number} has no pending wake")
        return 0
    result = run_result(repo, issue)
    if not result:
        return 1
    if not WAKE_CONFIG.exists():
        print(f"#{number} wake left pending (no Cloud credentials on this host either)")
        return 1
    return 0 if deliver_wake(repo, issue, result) else 1


def never_started(repo, number, current):
    """Re-queue only tasks that never ran: a cleared state label or a result comment means it ran before,
    and only the owner's explicit `ctx task retry` (a fresh labelled event) may run it again."""
    if any(RESULT_HEADER.match(item["body"]) for item in current["comments"]):
        return False
    return not any(event["__typename"] == "LabeledEvent" and (event.get("label") or {}).get("name") in STATE_LABELS
                   for event in snapshot(repo, number)["events"])


def sweep(ctx, repo, run_id):
    """Publish a dated completion receipt; a launchd exit alone is not an outcome."""
    receipt = {"host": ctx.config.host, "checked_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
               "status": "error", "jobs": {"requeued": 0, "reconciled": 0, "wakes_retried": 0},
               "publications": {"places": "error", "models": "error"}}
    try:
        result = _sweep(ctx, repo, run_id, receipt)
        receipt["status"] = "partial" if "error" in receipt["publications"].values() or receipt.get("wake_pending", 0) else "complete"
        return result
    finally:
        receipt["completed_at"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        atomic_json(ctx.config.state / "switchboard-sweep.json", receipt)


def _sweep(ctx, repo, run_id, receipt):
    issues = json.loads(gh("issue", "list", "--repo", repo, "--state", "open", "--limit", "1000",
                           "--search", "-label:done -label:failed",
                           "--json", "number,title,body,url,labels,createdAt"))
    active = issues_with_active_runs(repo)
    settled_before = datetime.datetime.now(datetime.timezone.utc) - SWEEP_SETTLE
    for issue in issues:
        labels = {label["name"] for label in issue["labels"]}
        machine = next((label for label in MACHINE_LABELS if label in labels), None)
        created = datetime.datetime.fromisoformat(issue["createdAt"].replace("Z", "+00:00"))
        if not machine or issue["number"] in active or created > settled_before:
            continue
        if issue["number"] in issues_with_active_runs(repo):
            continue
        current = json.loads(gh("issue", "view", str(issue["number"]), "--repo", repo, "--json", "labels,state,comments"))
        labels = label_names(current)
        if current["state"] != "OPEN" or labels.intersection(("done", "failed")):
            continue
        if "running" in labels:
            gh("workflow", "run", "run.yml", "--repo", repo, "-f", f"issue={issue['number']}", "-f", "machine=reconcile")
            print(f"#{issue['number']} queued for reconciliation")
            receipt["jobs"]["reconciled"] += 1
        elif not never_started(repo, issue["number"], current):
            print(f"#{issue['number']} has run before; not re-queued (use `ctx task retry`)")
        elif not labels.intersection(STATE_LABELS):
            gh("workflow", "run", "run.yml", "--repo", repo, "-f", f"issue={issue['number']}", "-f", f"machine={machine}")
            print(f"#{issue['number']} re-queued for {machine}")
            receipt["jobs"]["requeued"] += 1
    wakes = retry_wakes(repo, run_id)
    receipt["jobs"]["wakes_retried"] = wakes["attempted"]
    receipt["wake_pending"] = wakes["pending"]
    receipt["wakes_delivered"] = wakes["delivered"]
    for name, write in (("places", lambda: places.publish(ctx, repo)), ("models", lambda: models.publish(repo))):
        try:
            write()
            receipt["publications"][name] = "complete"
        except (RuntimeError, OSError, ValueError, KeyError, subprocess.SubprocessError) as error:
            print(f"{name} not published: {error}")
    return 0


def machine_label(name):
    if name in CLOUD_HARNESSES:
        name = 'm1'
    host = MACHINES.get(name.removeprefix("run:"))
    if not host:
        raise ValueError(f"unknown machine {name!r}; use m1, m3, nas or bv")
    return places.RUN_LABELS[host], host


def create(ctx, machine, title, body, *, new_place=False, dry_run=False):
    """Open a task issue after checking that its directory is a known place on that machine."""
    label, host = machine_label(machine)
    fields = parse_fields(body)
    if machine in CLOUD_HARNESSES:
        if fields.get('harness', machine).lower() != machine:
            raise ValueError('Cloud machine alias conflicts with the task Harness section')
        if 'harness' not in fields:
            body = body.rstrip() + f'\n\n### Harness\n\n{machine}\n'
            fields = parse_fields(body)
    if problem := cloud_problem(fields, host):
        raise ValueError(problem)
    missing = [name for name in ("directory", "goal") if name not in fields]
    if missing:
        raise ValueError("the task needs " + " and ".join(f"### {name.title()}" for name in missing))
    if not places.target_path(ctx, host, fields["directory"].strip()):
        raise ValueError(f"{fields['directory'].strip()} is neither an absolute or ~/ path nor a project registered on {host}")
    if problem := owner_problem(ctx, fields["directory"], host):
        raise ValueError(problem)
    if not new_place and not places.known(ctx, host, fields["directory"]):
        raise ValueError(f"{fields['directory'].strip()} is not a known place on {host} (ctx places); check the machine and "
                         "directory, or pass --new-place for a directory without recent agent work")
    if dry_run:
        return {"status": "complete", "machine": label, "directory": fields["directory"].strip(), "opened": False,
                "body": body}
    url = gh("issue", "create", "--repo", BOARD, "--label", label, "--title", title, "--body-file", "-", input=body).strip()
    return {"status": "complete", "url": url, "number": int(url.rsplit("/", 1)[-1]), "machine": label}


def listing(state=None, limit=30):
    args = ["issue", "list", "--repo", BOARD, "--limit", str(limit), "--json", "number,title,labels,updatedAt,state"]
    if state:
        args += ["--label", state]
    issues = json.loads(gh(*args))
    return {"status": "complete", "tasks": [
        {"number": item["number"], "title": item["title"], "updated": item["updatedAt"],
         "labels": [label["name"] for label in item["labels"]]} for item in issues]}


def show(number):
    issue = json.loads(gh("issue", "view", str(number), "--repo", BOARD, "--json", "number,title,url,state,labels,comments"))
    results = [c["body"] for c in issue["comments"] if RESULT_HEADER.match(c["body"])]
    return {"status": "complete", "number": issue["number"], "title": issue["title"], "url": issue["url"],
            "state": issue["state"], "labels": [label["name"] for label in issue["labels"]],
            "result": results[-1] if results else None}


def retry(number):
    """Run a finished task again: clear its state and re-add its machine label."""
    issue = json.loads(gh("issue", "view", str(number), "--repo", BOARD, "--json", "labels,state"))
    labels = {label["name"] for label in issue["labels"]}
    machine = next((label for label in MACHINE_LABELS if label in labels), None)
    if not machine:
        raise ValueError(f"#{number} must carry a machine label")
    if "running" in labels:
        raise ValueError(f"#{number} is running; wait for its result or for the sweep to mark it interrupted")
    if issue["state"] != "OPEN":
        gh("issue", "reopen", str(number), "--repo", BOARD)
    gh("issue", "edit", str(number), "--repo", BOARD, "--remove-label", ",".join(sorted(labels & {"done", "failed", WAKE_PENDING} | {machine})))
    gh("issue", "edit", str(number), "--repo", BOARD, "--add-label", machine)
    return {"status": "complete", "number": number, "machine": machine}
