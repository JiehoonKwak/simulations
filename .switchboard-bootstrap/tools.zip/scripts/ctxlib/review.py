"""Agent-facing views of the session inbox: `ctx ps` lists what is going on, `ctx show` explains one item.

Both read the inbox store on M1 (proxied from M3) and never change review state. `show` asks the
host that owns a running session for its turn so far (`_activity`), so progress is current on every
host, including NAS and BV. `continuation` turns one item into the context of a follow-up
Switchboard task.
"""

from __future__ import annotations

import os
from pathlib import Path
import re
import subprocess
import time

from . import activity, inbox
from .core import NotReady, remote

ORDER = ("needs-you", "running", "unread", "read")
READ_SHOWN = 15
MACHINE = {"m1pro": "m1", "m3max": "m3", "nas": "nas", "bv": "bv"}


def status(item: dict) -> str:
    """`needs-you` when a running turn waits on approval or input, or a stopped turn ended with a question."""
    if (item["state"] == "running" and item["waiting"]) or (item["state"] == "unread" and item["question"]):
        return "needs-you"
    return item["state"]


def project_of(item: dict, projects: list[dict]) -> str:
    """The registered project whose path on the item's host contains its directory, else the directory's name."""
    cwd, best = item.get("cwd") or "", ("", 0)
    for project in projects:
        root = (project.get("paths") or {}).get(item["host"], "")
        if root and (cwd == root or cwd.startswith(root.rstrip("/") + "/")) and len(root) > best[1]:
            best = (project["id"], len(root))
    return best[0] or Path(cwd).name or "-"


def here(host: str, cwd: Path | None = None) -> dict:
    """The current repository as a filter: every worktree of it on this host, as HOST:PATH."""
    location = str(cwd or Path.cwd())
    try:
        listed = subprocess.run(["git", "-C", location, "worktree", "list", "--porcelain"], capture_output=True, text=True, timeout=5)
    except (OSError, subprocess.TimeoutExpired):
        listed = None
    roots = [line[9:] for line in (listed.stdout.splitlines() if listed and listed.returncode == 0 else []) if line.startswith("worktree ")]
    return {"roots": [f"{host}:{root}" for root in roots or [location]]}


def _excluded() -> list[str]:
    return [value for value in (os.environ.get("CODEX_THREAD_ID"), os.environ.get("CLAUDE_CODE_SESSION_ID")) if value]


def ps(ctx, *, since: float = 24 * 3600, everything: bool = False, scope: dict | None = None, exclude=(), limit: int = 60) -> dict:
    """Running, waiting and unread items, plus items read within `since` seconds; newest first in each group."""
    if ctx.config.host != inbox.OWNER:
        args = ["ps", "--since", f"{int(since)}s", *(["--all"] if everything else [])]
        for root in (scope or {}).get("roots", []):
            args += ["--root", root]
        for native_id in exclude:
            args += ["--exclude", native_id]
        return remote(inbox.OWNER, args, timeout=20)
    projects = ctx.registry().get("projects", [])
    cutoff = time.time() - since
    db = inbox.connect()
    try:
        rows = db.execute(f"SELECT * FROM items {'' if everything else 'WHERE background = 0'}").fetchall()
    finally:
        db.close()
    roots = [tuple(value.split(":", 1)) for value in (scope or {}).get("roots", [])]
    items, hidden = [], 0
    for row in rows:
        item = dict(row)
        if item["native_id"] in exclude:
            continue
        if roots and not any(item["host"] == host and (item["cwd"] == root or item["cwd"].startswith(root.rstrip("/") + "/")) for host, root in roots):
            continue
        when = item["stop_at"] or item["prompt_at"] or item["updated_at"]
        if item["state"] == "read" and when < cutoff:
            hidden += 1
            continue
        public = inbox._public(row)
        public.update(status=status(item), project=project_of(item, projects), at=when)
        items.append(public)
    items.sort(key=lambda value: (ORDER.index(value["status"]), -value["at"]))
    counts = {name: sum(item["status"] == name for item in items) for name in ORDER}
    shown = [item for item in items if item["status"] != "read"] + [item for item in items if item["status"] == "read"][:READ_SHOWN]
    shown = shown[:limit]
    return {"status": "complete", "items": shown, "more": len(items) - len(shown), "counts": counts,
            "older_read": hidden, "since_seconds": int(since), "scoped": bool(roots)}


def _resolve(db, reference: str) -> dict:
    if not re.fullmatch(r"[0-9a-f]{4,64}|task:\d+|#\d+", reference):
        raise ValueError("use an ID from ctx ps (a hexadecimal prefix) or #N for a Switchboard task")
    reference = "task:" + reference[1:] if reference.startswith("#") else reference
    rows = db.execute("SELECT * FROM items WHERE key LIKE ?", (reference + "%",)).fetchmany(2)
    if len(rows) != 1:
        raise LookupError(f"{reference}: {'no inbox item' if not rows else 'ambiguous prefix'}")
    return dict(rows[0])


def show(ctx, reference: str, *, live: bool | None = None, brief: bool = False) -> dict:
    """One item: identity, last exchange, what waits on the user, what it changed; a running session adds its turn so far."""
    if ctx.config.host != inbox.OWNER:
        return remote(inbox.OWNER, ["show", reference, *(["--brief"] if brief else []), *(["--live"] if live else [])], timeout=40)
    db = inbox.connect()
    try:
        row = _resolve(db, reference)
        worker = _worker(db, row["native_id"]) if row["kind"] == "task" else None
        children = db.execute("SELECT * FROM items WHERE parent=? AND host=? AND harness=? ORDER BY prompt_at DESC LIMIT 20",
                              (row["native_id"], row["host"], row["harness"])).fetchall() if row["kind"] == "session" else []
    finally:
        db.close()
    item = inbox._public(row)
    item.update(status=status(row), project=project_of(row, ctx.registry().get("projects", [])), raw_host=row["host"],
                cwd_full=row["cwd"])
    item["subagents"] = [{"id": child["key"][:10], "state": "running" if child["state"] == "running" else "done",
                          "title": child["title"], "reply": (child["reply"] or "").strip().split("\n")[0][:160]} for child in children]
    if worker:
        item["worker"] = {"id": worker["key"][:10], "state": worker["state"]}
        if not brief and worker["state"] == "running":
            item["progress"] = progress(worker)
    if brief or item["kind"] != "session":
        return {"status": "complete", "item": item}
    # Items stored before the hooks captured replies have none; their transcript answers instead.
    if live if live is not None else row["state"] == "running" or not row["reply"]:
        item["progress"] = progress(row)
    return {"status": "complete", "item": item}


def _worker(db, number: str) -> dict | None:
    """The latest worker session of Switchboard task N: a background session in its `switchboard-N-RUN` worktree."""
    rows = db.execute("SELECT * FROM items WHERE kind='session' AND background=1 AND run_id!='' ORDER BY event_at DESC LIMIT 200")
    return next((dict(row) for row in rows if row["cwd"].endswith(f"/switchboard-{number}-{row['run_id']}")), None)


def progress(row: dict) -> dict:
    """The current turn so far, read from the transcript on the session's own host."""
    payload = {"harness": row["harness"], "native_id": row["native_id"], "since": row["prompt_at"] or 0}
    try:
        if row["host"] == inbox.OWNER:
            return answer(payload)
        return sanitize(remote(row["host"], ["inbox", "_activity"], payload, timeout=25))
    except (NotReady, OSError, ValueError, subprocess.TimeoutExpired) as error:
        lines = [line.strip() for line in str(error).splitlines() if line.strip()]
        return {"status": "not_ready", "reason": (lines[-1] if lines else "no answer")[:300]}


def answer(payload: dict) -> dict:
    """`ctx inbox _activity` on the owning host."""
    path = activity.transcript(payload["harness"], payload["native_id"])
    if path is None:
        return {"status": "not_ready", "reason": "no native transcript for this session on its host"}
    return {"status": "complete", **activity.since(payload["harness"], path, float(payload.get("since") or 0))}


def sanitize(value: dict) -> dict:
    """A pulled host's answer is untrusted: keep bounded plain strings only."""
    if not isinstance(value, dict) or value.get("status") != "complete":
        return {"status": "not_ready", "reason": inbox._text((value or {}).get("reason"), 300) or "no answer"}
    strings = lambda name, count, width: [inbox._text(text, width) for text in (value.get(name) or [])[-count:] if isinstance(text, str)]
    commits = [{"sha": commit["sha"], "subject": inbox._text(commit.get("subject"), 200), "branch": inbox._text(commit.get("branch"), 200)}
               for commit in (value.get("commits") or [])[-20:]
               if isinstance(commit, dict) and isinstance(commit.get("sha"), str) and re.fullmatch(r"[0-9a-f]{7,40}", commit["sha"])]
    messages = [inbox._clip(text, 4000) for text in (value.get("messages") or [])[-3:] if isinstance(text, str)]
    return {"status": "complete", "messages": messages, "actions": strings("actions", 10, 300),
            "files": strings("files", 50, 500), "commits": commits}


def continuation(ctx, reference: str, body: str, machine: str | None) -> tuple[str, str]:
    """A follow-up task body: the session's directory and harness by default, and its state under ### Context."""
    item = show(ctx, reference, live=True)["item"]
    if item["kind"] != "session":
        raise ValueError("--continues takes a session; to rerun a Switchboard task use ctx task retry N")
    from .switchboard import parse_fields

    fields = parse_fields(body)
    projects = {project["id"]: project for project in ctx.registry(cached=True).get("projects", [])}
    directory = (projects.get(item["project"], {}).get("paths") or {}).get(item["raw_host"]) or item["cwd_full"]
    lines = [f"Continues session {item['id']} ({item['harness']}@{item['host']}, {item['status']}): {item['title']}",
             f"Directory then: {item['cwd']}" + (f" on {item['branch']} at {item['head']}" if item.get("branch") else ""),
             f"Inspect: `ctx show {item['id']}` (state and turn so far), `ctx read {item['id']}` (conversation turns); "
             f"native {item['harness']} session {item['native_id']} on {item['host']}."]
    if item["prompt"]:
        lines += ["", "Last prompt:", item["prompt"][:1500]]
    if item["reply"]:
        lines += ["", "Last reply:", item["reply"][-2500:]]
    progress_value = item.get("progress") or {}
    if progress_value.get("messages") and (item["state"] == "running" or not item["reply"]):
        heading = "Turn in progress, latest message:" if item["state"] == "running" else "Last message (from its transcript):"
        lines += ["", heading, progress_value["messages"][-1][-1500:]]
    files = list(dict.fromkeys([*item["files"], *progress_value.get("files", [])]))
    if files:
        lines += ["", "Files the session changed: " + ", ".join(files[-30:])]
    commits = item["commits"] + [commit for commit in progress_value.get("commits", []) if commit not in item["commits"]]
    if commits:
        lines += ["", "Its commits: " + "; ".join(f"{commit['sha']} {commit['subject']}" for commit in commits[-10:])]
    block = "\n".join(lines)
    if "context" in fields:
        body = re.sub(r"(^###\s+Context\s*\n)", lambda match: match.group(1) + block + "\n\n", body, count=1, flags=re.M | re.I)
    else:
        body = body.rstrip() + "\n\n### Context\n\n" + block + "\n"
    if "directory" not in fields:
        body = f"### Directory\n\n{directory}\n\n" + body
    if "harness" not in fields:
        body = body.rstrip() + f"\n\n### Harness\n\n{item['harness']}\n"
    return body, machine or MACHINE.get(item["raw_host"], item["raw_host"])
