"""One Slack message to Cloud with what changed in the daily note and Apple Reminders.

M1's `ctx data sync` calls `run` every minute. It captures today's daily note and
reads the Reminders snapshot already written to `data/reminders/open.json`, then
compares each with the version last delivered to Cloud. A message goes out once
every changed source has been quiet for QUIET_SECONDS and the previous message is
at least MIN_INTERVAL_SECONDS old, so Cloud wakes at most every half hour and sees
both sources together; a source without changes is left out. A note first seen,
or anything written between KST 00:00 and 00:05 (Templater creation), becomes a
silent baseline. Delivered versions stay in host-local ctx state.

Delivery must never stall silently: a failed send keeps the baselines, so the
next run resends everything since the last delivery, and `deliver` alerts the
user (at most hourly) until a message goes through again.
"""

from __future__ import annotations

import difflib
import hashlib
import json
import re
import subprocess
from datetime import datetime, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

from . import reminders

SEOUL = ZoneInfo("Asia/Seoul")
QUIET_SECONDS = 180
MIN_INTERVAL_SECONDS = 1800
MAX_MESSAGE = 11000
ALERT_INTERVAL_SECONDS = 3600
HEADING = re.compile(r"#{1,6} \S")


def _digest(value) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


def _clock(moment: float) -> str:
    return datetime.fromtimestamp(moment, SEOUL).strftime("%H:%M")


def _fit(lines: list[str], budget: int, pointer: str) -> list[str]:
    kept = []
    for index, line in enumerate(lines):
        budget -= len(line) + 1
        if budget < 0:
            return kept + [f"… {len(lines) - index} more lines omitted; {pointer}"]
        kept.append(line)
    return kept


def note_lines(previous: str, text: str) -> list[str]:
    """Unified diff with two context lines; each hunk names its nearest heading instead of line numbers."""
    current = text.splitlines()
    lines, repeated = [], None
    for line in list(difflib.unified_diff(previous.splitlines(), current, n=2, lineterm=""))[2:]:
        hunk = re.match(r"@@ -\d+(?:,\d+)? \+(\d+)", line)
        if hunk:
            heading = next((current[i] for i in range(min(int(hunk[1]), len(current)) - 1, -1, -1)
                            if HEADING.match(current[i])), "(top of note)")
            line, repeated = "@ " + heading, " " + heading
        elif line == repeated:
            repeated = None
            continue
        else:
            repeated = None
        lines.append(line)
    return lines


def capture_note(root: Path, notes: dict, now: float) -> None:
    """Record today's note text; the first sighting and the midnight window only move the baseline."""
    local = datetime.fromtimestamp(now, SEOUL)
    day = local.date()
    for old in [key for key in notes if key not in (day.isoformat(), (day - timedelta(days=1)).isoformat())]:
        del notes[old]
    path = root / "daily-notes" / (day.isoformat() + ".md")
    if not path.is_file():
        return
    text = path.read_text(encoding="utf-8")
    record = notes.setdefault(day.isoformat(), {})
    if record.get("pending", {}).get("hash") != _digest(text):
        record["pending"] = {"hash": _digest(text), "text": text, "changed_at": now}
    if "baseline" not in record or (local.hour == 0 and local.minute < 5):
        record["baseline"] = record["pending"]


def _note_section(day: str, record: dict, budget: int) -> list[str]:
    head = [f"## Daily note · daily-notes/{day}.md · edits {_clock(record['baseline']['changed_at'])}–{_clock(record['pending']['changed_at'])} KST",
            "Unified diff; '@' names the section."]
    body = note_lines(record["baseline"]["text"], record["pending"]["text"])
    return head + _fit(body, budget, f"read daily-notes/{day}.md.") if body else []


def _reminder_section(found: list[dict], current: dict, since: float, until: float, budget: int) -> list[str]:
    head = [f"## Reminders · edits {_clock(since)}–{_clock(until)} KST",
            "+ added, ~ edited, ✓ completed, ✗ deleted, - closed (reason unknown); reordering ignored."]
    inbox = reminders.inbox_lines(current)
    tail = ["", f"### Open Inbox ({len(inbox)})"] + inbox
    changes = _fit(reminders.change_lines(found), budget - len("\n".join(tail)),
                   "run `ctx data reminders --diff` on M1 or read data/reminders/open.json.")
    return head + changes + tail


def run(root: Path, state: dict, *, now: float, publish, runner=subprocess.run) -> dict:
    """Capture both sources and send one combined message when due; mutates `state`."""
    notes = state.setdefault("daily_note", {})
    capture_note(root, notes, now)
    mark = state.setdefault("reminders", {})
    snapshot_path = root / "data/reminders/open.json"
    current = json.loads(snapshot_path.read_text()) if snapshot_path.is_file() else None
    if current is not None:
        mark.setdefault("baseline", current)
        version = _digest(current)
        if version == _digest(mark["baseline"]):
            for key in ("pending", "first_at", "changed_at"):
                mark.pop(key, None)
        elif mark.get("pending") != version:
            mark.update(pending=version, changed_at=now)
            mark.setdefault("first_at", now)
    local = datetime.fromtimestamp(now, SEOUL)
    if local.hour == 0 and local.minute < 5:
        return {"status": "waiting", "reason": "midnight baseline window"}
    ready = sorted(day for day, record in notes.items() if record["pending"]["hash"] != record["baseline"]["hash"])
    changed = [notes[day]["pending"]["changed_at"] for day in ready] + ([mark["changed_at"]] if "pending" in mark else [])
    if not changed:
        return {"status": "clean"}
    if now - max(changed) < QUIET_SECONDS:
        return {"status": "waiting", "reason": "editing"}
    if now - state.get("sent_at", 0) < MIN_INTERVAL_SECONDS:
        return {"status": "waiting", "reason": "interval", "next_at": state["sent_at"] + MIN_INTERVAL_SECONDS}
    found = reminders.changes(mark["baseline"], current, runner) if "pending" in mark else []
    budget = MAX_MESSAGE - 400
    note_budget = (budget // 2 if found else budget) // max(len(ready), 1)
    sections = [section for day in ready if (section := _note_section(day, notes[day], note_budget))]
    kinds = ["daily note"] if sections else []
    if found:
        used = sum(len("\n".join(section)) for section in sections)
        sections.append(_reminder_section(found, current, mark["first_at"], mark["changed_at"], budget - used))
        kinds.append("Apple Reminders")
    receipt = None
    if sections:
        head = ["### Context Diffs",
                f"Code-generated changes in the user's {' and '.join(kinds)} since the last message (sent at most every 30 min)."]
        body = "\n\n".join("\n".join(part) for part in [head, *sections])
        if len(body) > MAX_MESSAGE:
            body = body[:MAX_MESSAGE - 80] + "\n… message cut at the size limit; read the sources for the rest."
        receipt = publish(body, "context:" + _digest(body)[:32])
        state["sent_at"] = now
    for day in ready:
        notes[day]["baseline"] = notes[day]["pending"]
    if "pending" in mark:
        mark["baseline"] = current
        for key in ("pending", "first_at", "changed_at"):
            mark.pop(key, None)
    return {"status": "sent" if receipt else "clean", "notes": len(ready), "reminder_changes": len(found),
            **({"receipt": receipt} if receipt else {})}


def deliver(root: Path, state: dict, *, now: float, publish, alert, runner=subprocess.run) -> dict:
    """`run`, telling the user through `alert` while delivery keeps failing and once it recovers."""
    try:
        result = run(root, state, now=now, publish=publish, runner=runner)
    except Exception as error:
        failure = state.setdefault("failure", {"since": now})
        if now - failure.get("alerted_at", 0) >= ALERT_INTERVAL_SECONDS and _alerted(
                alert, f"Context Diffs not delivered since {_clock(failure['since'])} KST; retrying every minute.\n"
                       f"{type(error).__name__}: {str(error)[:300]}"):
            failure["alerted_at"] = now
        raise
    if result["status"] in ("sent", "clean") and (failure := state.pop("failure", None)) and failure.get("alerted_at"):
        _alerted(alert, f"Context Diffs delivered again (failing since {_clock(failure['since'])} KST).")
    return result


def _alerted(alert, text: str) -> bool:
    try:
        alert(text)
        return True
    except Exception:
        return False
