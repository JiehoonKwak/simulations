"""Where work happens: each host's Git repositories with recent agent sessions, for choosing a task's machine and directory."""

from __future__ import annotations

import base64
from datetime import datetime, timedelta, timezone
import json
import os
from pathlib import Path
import re
import subprocess
import time

from . import index
from .core import HOSTS, NotReady, atomic_json, primary_checkout, remote
from .handoff import runtime_roots

BOARD = "JiehoonKwak/switchboard"
WINDOW_DAYS = 90
RECHECK_SECONDS = 24 * 3600
GIT_SECONDS = 2
ORIGINS = ("interactive", "agent", "headless", "automation")
TEMPORARY = tuple(Path(path) for path in ("/tmp", "/private/tmp", "/private/var", "/var/folders"))
RUN_LABELS = {"m1pro": "run:m1", "m3max": "run:m3", "nas": "run:nas", "bv": "run:bv"}
HOST_NAMES = {"m1pro": "M1 Pro", "m3max": "M3 Max", "nas": "NAS", "bv": "BV"}


def local(ctx) -> dict:
    """This host's repositories with sessions in the last WINDOW_DAYS days, plus registered workspaces.

    Each directory's repository is probed once and cached in the state directory, and probed again after
    RECHECK_SECONDS (or when its root disappears), so later sweeps rarely wait."""
    since = (datetime.now(timezone.utc) - timedelta(days=WINDOW_DAYS)).strftime("%Y-%m-%dT%H:%M:%S")
    with index.readonly(ctx.index_path) as db:
        rows = db.execute("SELECT cwd, COUNT(*), MAX(last_message_at) FROM sessions WHERE host=? AND cwd != '' "
                          f"AND origin IN ({','.join('?' * len(ORIGINS))}) AND last_message_at >= ? GROUP BY cwd",
                          (ctx.config.host, *ORIGINS, since)).fetchall()
    registry = ctx.registry(cached=True)
    registered = [(project["paths"][ctx.config.host], 0, "") for project in registry.get("projects", [])
                  if project.get("mode", "workspace") == "workspace" and project["paths"].get(ctx.config.host)]
    excluded = runtime_roots(ctx) + [Path.home() / ".local"] + [path.resolve() for path in TEMPORARY if path.exists()]
    cache_path = ctx.config.state / "places-roots.json"
    cache = json.loads(cache_path.read_text()) if cache_path.exists() else {}
    now = time.time()
    places: dict[Path, dict] = {}
    for cwd, count, last in [*rows, *registered]:
        known = cache.get(cwd)
        if (not isinstance(known, dict) or (known["root"] and not Path(known["root"]).is_dir())
                or now - known["checked"] > RECHECK_SECONDS):
            found = primary_checkout(cwd)
            known = cache[cwd] = {"root": str(found) if found else "", "checked": now}
        root = Path(known["root"]) if known["root"] else None
        if (root is None or any(root.is_relative_to(item) for item in excluded)
                or foreign_git_owner(ctx, ctx.config.host, str(root), registry)):
            continue
        place = places.setdefault(root, {"sessions": 0, "last": ""})
        place["sessions"] += count
        place["last"] = max(place["last"], last)
    atomic_json(cache_path, cache)
    home = str(Path.home())
    listed = []
    for root, place in places.items():
        try:
            origin = subprocess.run(["git", "-C", str(root), "remote", "get-url", "origin"], capture_output=True, text=True,
                                    timeout=GIT_SECONDS).stdout.strip()
        except subprocess.TimeoutExpired:
            origin = ""
        listed.append({"path": str(root).replace(home, "~", 1) if str(root).startswith(home) else str(root),
                       "project_id": ctx.project_id_for(str(root)), "origin": origin, **place})
    listed.sort(key=lambda item: (item["last"][:10], item["path"]), reverse=True)
    return {"status": "complete", "host": ctx.config.host,
            "generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"), "places": listed}


def everywhere(ctx) -> dict:
    """This host's places and each peer's, falling back to the peer's last answer when it is unreachable.

    Hosts outside HOSTS cannot reach the registry owner, so each first receives the current registry copy."""
    hosts = {ctx.config.host: local(ctx)}
    registry = ctx.registry()
    for peer in dict.fromkeys((*ctx.config.peers, *(host for host in RUN_LABELS if host != ctx.config.host))):
        cache = ctx.config.state / f"places-{peer}.json"
        try:
            if peer not in HOSTS:
                remote(peer, ["_registry"], registry, timeout=30)
            hosts[peer] = remote(peer, ["places", "--local"], timeout=60)
            atomic_json(cache, hosts[peer])
        except (NotReady, OSError, subprocess.TimeoutExpired) as error:
            hosts[peer] = {**(json.loads(cache.read_text()) if cache.exists() else {"places": []}), "stale": str(error)}
    order = list(RUN_LABELS)
    return {"status": "complete", "hosts": dict(sorted(hosts.items(), key=lambda item: order.index(item[0]) if item[0] in order else len(order)))}


def markdown(result: dict) -> str:
    lines = ["# Places", "",
             "Git repositories where agents worked in the last "
             f"{WINDOW_DAYS} days, by machine, generated by `ctx places --publish`. Use a row's directory (or its "
             "project id) as `### Directory` together with that machine's label. Follow "
             "[Choosing placement](AGENTS.md#choosing-placement) for placement policy, including the M1 Obsidian "
             "Vault default for an unclear target project or temporary/general tasks without a specific project. "
             "A repository listed under several "
             "machines has a checkout on each; its last activity is context, not a placement rule. "
             "Directories that are not listed may still exist; ask before guessing a specific target path.", ""]
    for host, value in result["hosts"].items():
        note = f" (unreachable; last known list from {value.get('generated_at', 'never')})" if value.get("stale") else ""
        lines += [f"## {HOST_NAMES.get(host, host)} (`{RUN_LABELS.get(host, 'run:' + host)}`){note}", "",
                  "| Directory | Project id | Remote | Last activity |", "| --- | --- | --- | --- |"]
        for place in value.get("places", []):
            remote_name = re.sub(r"^(?:\w+://)?(?:[^@/]+@)?[^:/]+[:/]", "", place["origin"]).removesuffix(".git")
            lines.append(f"| `{place['path']}` | {place['project_id'] or ''} | {remote_name} | {place['last'][:10]} |")
        lines.append("")
    return "\n".join(lines)


def publish(ctx, repo: str) -> dict:
    """Write PLACES.md to the task board repository when its content changed."""
    return publish_file(repo, "PLACES.md", markdown(everywhere(ctx)), "Update places")


def publish_file(repo: str, name: str, body: str, message: str, comparable=lambda text: text) -> dict:
    """Write a file to the board repository unless comparable(current) equals comparable(body)."""
    current = subprocess.run(["gh", "api", f"repos/{repo}/contents/{name}"], capture_output=True, text=True)
    existing = json.loads(current.stdout) if current.returncode == 0 else {}
    if existing and comparable(base64.b64decode(existing["content"]).decode()) == comparable(body):
        return {"status": "complete", "published": False}
    fields = ["-f", f"message={message}", "-f", "content=" + base64.b64encode(body.encode()).decode()]
    if existing:
        fields += ["-f", "sha=" + existing["sha"]]
    result = subprocess.run(["gh", "api", "-X", "PUT", f"repos/{repo}/contents/{name}", *fields], capture_output=True, text=True)
    if result.returncode:
        raise NotReady(f"publishing {name} failed: " + result.stderr.strip()[-300:])
    return {"status": "complete", "published": True}


def target_path(ctx, host: str, value: str) -> str | None:
    """A registered project's path on host for its id, label or alias, or an absolute or `~` path as given.

    A relative path is refused: the runner would resolve it against its own working directory."""
    if value.startswith(("/", "~")):
        return value
    if "/" in value:
        return None
    for project in ctx.registry(cached=True).get("projects", []):
        if value in (project["id"], project.get("label"), *project.get("aliases", [])):
            return project["paths"].get(host)
    return None


def comparable(path: str) -> str:
    """A path in a form that compares across hosts that share a home layout: `~` and this home both become /HOME."""
    home = str(Path.home())
    if path.startswith("~"):
        path = "/HOME" + path[1:]
    elif path == home or path.startswith(home + "/"):
        path = "/HOME" + path[len(home):]
    return os.path.normpath(path)


def inside(path: str, root: str) -> bool:
    return path == root or path.startswith(root.rstrip("/") + "/")


def foreign_git_owner(ctx, host: str, directory: str, registry: dict | None = None) -> str | None:
    """The other host that alone may write Git for the registered project holding directory on host (its
    `git_owner`), or None. The Vault's Git is written only on M1: M3 shares its files through iCloud but keeps
    its own stale Git HEAD, so a task there would start from old notes and publish against the owner's rule."""
    path = target_path(ctx, host, directory.strip())
    if not path:
        return None
    wanted = comparable(path)
    for project in (registry or ctx.registry()).get("projects", []):
        owner = project.get("git_owner")
        if owner and owner != host and any(inside(wanted, comparable(root)) for root in project.get("paths", {}).values()):
            return owner
    return None


def check(ctx, directory: str) -> dict:
    """Whether directory, after resolving `~`, `..` and symlinks on this host, lies inside one of its places."""
    path = os.path.realpath(os.path.expanduser(directory))
    roots = [os.path.realpath(os.path.expanduser(place["path"])) for place in local(ctx)["places"]]
    found = os.path.isdir(path) and any(path == root or path.startswith(root.rstrip("/") + "/") for root in roots)
    return {"status": "complete", "known": found, "path": path}


def known(ctx, host: str, directory: str) -> bool:
    """Whether a task directory (a path, or a registered project id, label or alias) is inside a listed place on
    host, checked on that host; an unreachable peer is checked against its last listing without symlinks."""
    path = target_path(ctx, host, directory.strip())
    if not path:
        return False
    if host == ctx.config.host:
        return check(ctx, path)["known"]
    try:
        return remote(host, ["places", "--check", path], timeout=60)["known"]
    except (NotReady, OSError, subprocess.TimeoutExpired, KeyError):
        pass
    wanted = comparable(path)
    cache = ctx.config.state / f"places-{host}.json"
    listed = json.loads(cache.read_text()).get("places", []) if cache.exists() else []
    return any(inside(wanted, comparable(place["path"])) for place in listed)
