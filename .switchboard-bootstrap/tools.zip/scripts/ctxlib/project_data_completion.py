"""Explicit completed-result seals consumed by handoff and periodic publication.

Quiet files are not evidence of completion. Only a producer's explicit seal is
queued; mutable inputs and frozen outputs are retained if validation fails.
"""
from __future__ import annotations

import fcntl
import hashlib
import json
import os
from contextlib import contextmanager
from pathlib import Path
from uuid import uuid4

from . import project_data as data
from .core import NotReady, atomic_json, canonical, component, run_git


@contextmanager
def publication_lock(ctx):
    directory = Path(data.settings(ctx)['tasks'])
    directory.mkdir(parents=True, exist_ok=True, mode=0o700)
    with (directory / '.publication.lock').open('a') as lock:
        os.fchmod(lock.fileno(), 0o600)
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
        try:
            yield
        finally:
            fcntl.flock(lock.fileno(), fcntl.LOCK_UN)


def fingerprints(root, names):
    """Detect writes/replacements, including SQLite writers' auxiliary files."""
    result = {}
    root = Path(root).resolve()
    for name in names:
        path = root / name
        if path.is_symlink() or path.resolve() != path.absolute():
            raise NotReady('symlink in completed data: ' + name)
        stat = path.stat()
        result[name] = [stat.st_dev, stat.st_ino, stat.st_size,
                        stat.st_mtime_ns, stat.st_ctime_ns]
        for suffix in ('-wal', '-shm', '-journal'):
            auxiliary = path.with_name(path.name + suffix)
            if auxiliary.exists():
                if auxiliary.is_symlink():
                    raise NotReady('symlink in completed data auxiliary: ' + name)
                stat = auxiliary.stat()
                result[name + suffix] = [stat.st_dev, stat.st_ino, stat.st_size,
                                         stat.st_mtime_ns, stat.st_ctime_ns]
    return result


def local_names(root, config, selection):
    return data.files(root, {**config, 'paths': selection})


def marker_path(ctx, identifier):
    return Path(data.settings(ctx)['tasks']) / component(identifier) / 'completed.json'


def _prepare_local_ticket(ctx, root, identifier, selected_paths, base):
    """Overlay explicitly selected local results on their known NAS inputs."""
    config = data.binding(ctx, root)
    if config is None:
        raise NotReady('completed results require a managed data binding')
    selection = data.selection_paths(config, selected_paths, root)
    if selection is None:
        raise NotReady('select completed local result paths explicitly')
    if base is None:
        raise NotReady('local results require their known input revision with --base')
    component(base)
    identifier = component(identifier or 'completed-' + uuid4().hex)
    directory = Path(data.settings(ctx)['tasks']) / identifier
    if (directory / 'ticket.json').exists():
        raise NotReady('completion ID already exists; use its ticket or a new ID')
    names = local_names(root, config, selection)
    data.inventoried_files(root, config, names)
    if not names:
        raise NotReady('selected completed paths contain no untracked result files')
    current = data.command(ctx, {'action': 'inspect', 'project': config['project'], 'revision': base})
    if current['revision'] is None:
        raise NotReady('project has no completed NAS checkpoint; import data first')
    before = fingerprints(root, names)
    workspace = directory / 'workspace'
    data.snapshot(root, workspace, names)
    if names != local_names(root, config, selection) or before != fingerprints(root, names):
        raise NotReady('result changed while sealing; copied data retained, not queued')
    ticket = data.save_ticket(ctx, {
        'id': identifier, 'project': config['project'], 'config': config,
        'revision': current['revision'], 'base': current['revision'],
        'workspace': str(workspace), 'root': str(root), 'frozen': False,
        'status': 'prepared', 'selected_paths': names,
        'baseline_manifest': current['manifest'],
        'materialized_files': sorted(name for name in current['manifest']['files']
                                     if data.in_selection(name, names)),
    })
    return ticket, selection, before


def complete(ctx, root, *, identifier=None, ticket_id=None, selected_paths=None, base=None):
    """Seal stopped producers' outputs; scheduling never infers completion."""
    root = Path(root).resolve()
    if ticket_id is not None and (identifier is not None or selected_paths is not None or base is not None):
        raise NotReady('complete accepts either a prepared ticket or selected local result paths')
    with publication_lock(ctx):
        if ticket_id is not None:
            ticket = data.load_ticket(ctx, ticket_id)
            if ticket.get('initial'):
                raise NotReady('initial-copy tickets are not completed computation results')
            data.validate_producing_root(ctx, ticket, root)
            source = Path(ticket['workspace'])
            names = data.data_names(source)
            selection = None
            before = fingerprints(source, names)
        else:
            ticket, selection, before = _prepare_local_ticket(ctx, root, identifier, selected_paths, base)
            source = root
            names = ticket['selected_paths']
        marker = marker_path(ctx, ticket['id'])
        if marker.exists():
            existing = json.loads(marker.read_text())
            validate_seal(ctx, ticket, existing)
            return result(ticket)
        if ticket.get('status') == 'published':
            raise NotReady('already published ticket cannot be resealed; prepare a new task')
        if before != fingerprints(source, names):
            raise NotReady('result changed while sealing; copied data retained, not queued')
        frozen = data.freeze(ctx, ticket, root)
        current_names = (local_names(source, ticket['config'], selection) if selection is not None
                         else data.data_names(source))
        if before != fingerprints(source, names) or names != current_names:
            raise NotReady('result changed while sealing; candidate retained, not queued')
        seal = {'schema_version': 1, 'candidate': frozen['candidate'],
                'source': str(source), 'source_names': names, 'source_selection': selection,
                'source_fingerprints': before,
                'workspace_fingerprints': fingerprints(frozen['workspace'], data.data_names(frozen['workspace']))}
        atomic_json(marker, seal)
        marker.chmod(0o600)
        return result(frozen)


def result(ticket):
    return {'status': 'published' if ticket.get('status') == 'published' else 'ready',
            'id': ticket['id'], 'ticket': ticket['id'], 'workspace': ticket['workspace'],
            'revision': ticket['candidate']}


def validate_seal(ctx, ticket, seal):
    if not isinstance(ticket, dict) or not isinstance(seal, dict):
        raise NotReady('completed-result seal is not a valid object; candidate retained')
    candidate = hashlib.sha256(canonical(ticket.get('manifest'))).hexdigest()
    if (seal.get('schema_version') != 1 or not ticket.get('frozen')
            or candidate != seal.get('candidate')
            or (ticket.get('status') != 'published' and ticket.get('candidate') != candidate)):
        raise NotReady('completed-result seal identity changed; candidate retained')
    data.validate_producing_root(ctx, ticket, ticket['root'])
    source = Path(seal['source'])
    selection = seal['source_selection']
    if source.resolve() not in {Path(ticket['workspace']).resolve(), Path(ticket['root']).resolve()}:
        raise NotReady('completed-result source identity changed; candidate retained')
    names = (local_names(source, ticket['config'], selection) if selection is not None
             else data.data_names(source))
    if names != seal['source_names'] or fingerprints(source, names) != seal['source_fingerprints']:
        raise NotReady('completed source changed or computation resumed; skipped, candidate retained')
    names = data.data_names(ticket['workspace'])
    if fingerprints(ticket['workspace'], names) != seal['workspace_fingerprints']:
        raise NotReady('completed workspace changed or computation resumed; skipped, candidate retained')
    try:
        if json.loads((Path(ticket['stage']) / 'manifest.json').read_text()) != ticket['manifest']:
            raise NotReady('completed frozen manifest changed; candidate retained')
    except (OSError, ValueError) as error:
        raise NotReady('completed frozen manifest unavailable; candidate retained') from error


@contextmanager
def producing_checkout(ctx, ticket):
    """Keep publication pinned to its producing code even after later commits."""
    root = Path(ticket['root'])
    if not ticket.get('source_commit'):
        yield root
        return
    directory = Path(data.settings(ctx)['tasks']) / ticket['id'] / 'publication-code'
    if directory.exists():
        raise NotReady('previous publisher checkout retained; inspect it before retrying')
    run_git(root, 'worktree', 'add', '--detach', str(directory), ticket['source_commit'])
    try:
        yield directory
    finally:
        run_git(root, 'worktree', 'remove', str(directory))


def publish_ready(ctx, *, ticket_id=None, root=None):
    """Drain explicit seals; failed/changing/stale candidates remain recoverable."""
    report = {'status': 'complete', 'published': [], 'skipped': []}
    with publication_lock(ctx):
        directory = Path(data.settings(ctx)['tasks'])
        markers = ([marker_path(ctx, ticket_id)] if ticket_id is not None
                   else sorted(directory.glob('*/completed.json')))
        for marker in markers:
            if not marker.exists():
                if ticket_id is not None:
                    report['skipped'].append({'ticket': ticket_id, 'reason': 'result is not marked completed'})
                continue
            identifier = marker.parent.name
            try:
                ticket = data.load_ticket(ctx, identifier)
                if root is not None and data.repository_identity(root) != data.repository_identity(ticket['root']):
                    if ticket_id is not None:
                        raise NotReady('completed ticket belongs to another repository')
                    continue
                if ticket.get('status') == 'published':
                    if ticket_id is not None:
                        current = data.command(ctx, {'action': 'inspect', 'project': ticket['project'],
                                                     'revision': ticket['candidate']})
                        if current['manifest'] != ticket['manifest'] and current['revision'] != ticket['base']:
                            raise NotReady('published completion receipt no longer matches')
                        report['published'].append({'ticket': identifier, 'revision': current['revision'],
                                                    'workspace': ticket['workspace'], 'unchanged': True})
                    continue
                seal = json.loads(marker.read_text())
                validate_seal(ctx, ticket, seal)
                with producing_checkout(ctx, ticket) as producing_root:
                    receipt = data.publish(ctx, ticket, integrated_root=producing_root)
                report['published'].append({'ticket': identifier, 'revision': receipt['revision'],
                                            'workspace': ticket['workspace']})
            except (NotReady, OSError, ValueError, KeyError) as error:
                report['skipped'].append({'ticket': identifier, 'reason': str(error)})
    if report['skipped']:
        report['status'] = 'not_ready'
        report['reason'] = '; '.join(item['ticket'] + ': ' + item['reason'] for item in report['skipped'])
    return report
