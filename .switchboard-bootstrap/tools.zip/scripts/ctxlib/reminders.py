"""Apple Reminders: an ID-keyed snapshot of open reminders and readable diffs between snapshots.

`snapshot` keeps only what a person edits (title, list, notes, URL, priority,
due date, alarm, repeat), so reordering and modification timestamps never count
as changes. `changes` compares two snapshots by reminder ID; `change_lines` and
`inbox_lines` render them as text for `context_diffs` and `ctx data reminders`.
"""

from __future__ import annotations

import json
import subprocess
from datetime import datetime
from zoneinfo import ZoneInfo

from .core import NotReady

SEOUL = ZoneInfo("Asia/Seoul")
FIELDS = ("title", "listName", "notes", "url", "priority", "dueDate", "dueDateIsAllDay", "alarmDate", "recurrenceRule", "creationDate")
SHOWN = ("title", "list", "due", "priority", "alarm", "repeat", "url", "notes")
INBOX = "Inbox"


def snapshot(runner=subprocess.run) -> dict:
    """Open reminders keyed by ID, Inbox first, then by list and creation time."""
    result = runner(["remindctl", "show", "open", "--json", "--no-input"], capture_output=True, text=True, timeout=20)
    if result.returncode:
        raise NotReady("remindctl could not read Reminders: " + (result.stderr or result.stdout).strip()[:200])
    items = {item["id"]: {key: item[key] for key in FIELDS if item.get(key) not in (None, "", False, "none")}
             for item in json.loads(result.stdout)}
    order = lambda pair: (pair[1].get("listName") != INBOX, pair[1].get("listName", ""), pair[1].get("creationDate", ""), pair[0])
    return dict(sorted(items.items(), key=order))


def _time(value: str, all_day=False) -> str:
    local = datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone(SEOUL)
    return local.strftime("%Y-%m-%d" if all_day else "%Y-%m-%d %H:%M")


def _repeat(rule: dict) -> str:
    interval, frequency = rule.get("interval", 1), rule.get("frequency", "?")
    return frequency if interval == 1 else f"every {interval} {frequency}"


def display(item: dict) -> dict:
    """The fields a person sees, as text; all-day status folds into the due date."""
    shown = {"title": item.get("title", ""), "list": item.get("listName", ""),
             "due": item.get("dueDate") and _time(item["dueDate"], item.get("dueDateIsAllDay", False)),
             "priority": item.get("priority"), "alarm": item.get("alarmDate") and _time(item["alarmDate"]),
             "repeat": item.get("recurrenceRule") and _repeat(item["recurrenceRule"]),
             "url": item.get("url"), "notes": item.get("notes")}
    return {key: value for key, value in shown.items() if value}


def _closed(reminder_id: str, runner) -> str:
    """How an open reminder left the snapshot: completed, deleted, or closed when unknown."""
    if runner is None:
        return "closed"
    result = runner(["remindctl", "info", reminder_id, "--json", "--no-input"], capture_output=True, text=True, timeout=20)
    if result.returncode:
        return "deleted" if "not found" in (result.stderr + result.stdout).lower() else "closed"
    return "completed" if json.loads(result.stdout).get("isCompleted") else "closed"


def changes(old: dict, new: dict, runner=None) -> list[dict]:
    """Added, edited and closed reminders, Inbox first. `runner` looks up why one closed."""
    found = []
    for reminder_id in old.keys() | new.keys():
        before = display(old[reminder_id]) if reminder_id in old else None
        after = display(new[reminder_id]) if reminder_id in new else None
        if before is None:
            found.append({"change": "added", "id": reminder_id, "item": after})
        elif after is None:
            found.append({"change": _closed(reminder_id, runner), "id": reminder_id, "item": before})
        else:
            fields = {key: [before.get(key), after.get(key)] for key in SHOWN if before.get(key) != after.get(key)}
            if fields:
                found.append({"change": "edited", "id": reminder_id, "item": after, "fields": fields})
    lists = lambda change: {change["item"]["list"], *change.get("fields", {}).get("list", [])}
    return sorted(found, key=lambda change: (INBOX not in lists(change), change["item"]["list"], change["item"]["title"]))


def _clip(text: str, limit=300) -> str:
    text = " ".join(text.split())
    return text if len(text) <= limit else text[:limit - 1] + "…"


def _summary(item: dict, notes=300) -> str:
    parts = [item["title"]] + [f"{key} {item[key]}" for key in ("due", "priority", "alarm", "repeat", "url") if key in item]
    return " · ".join(parts) + (f"\n  notes: {_clip(item['notes'], notes)}" if notes and "notes" in item else "")


MARK = {"added": "+", "edited": "~", "completed": "✓", "deleted": "✗", "closed": "-"}


def change_lines(found: list[dict]) -> list[str]:
    lines = []
    for change in found:
        item, fields = change["item"], change.get("fields", {})
        where = " → ".join(fields["list"]) if "list" in fields else item["list"]
        if change["change"] == "added":
            lines.append(f"+ [{where}] {_summary(item)}")
            continue
        label = "" if change["change"] == "edited" else f" ({change['change']})"
        lines.append(f"{MARK[change['change']]} [{where}] {fields['title'][1] if 'title' in fields else item['title']}{label}")
        for key, (before, after) in fields.items():
            if key == "list":
                continue
            if key == "notes":
                lines.append(f"  notes: {_clip(after) if after else '(removed)'}")
            else:
                lines.append(f"  {key}: {before or '—'} → {after or '—'}")
    return lines


def inbox_lines(current: dict) -> list[str]:
    """Every open Inbox reminder, one line each with a short notes excerpt."""
    return [f"- {_summary(display(item), notes=120)}" for item in current.values() if item.get("listName") == INBOX]
