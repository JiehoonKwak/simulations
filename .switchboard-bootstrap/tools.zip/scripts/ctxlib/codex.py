"""Read-only Codex originals, and new or resumed threads on the local managed daemon.

SQLite is metadata, never a database to restore. History-base IDs address immutable
rollout filenames; they must not be resolved through a thread's newer selection.
"""
from __future__ import annotations

from contextlib import contextmanager
import base64
import binascii
import hashlib
import json
import os
import re
import sqlite3
from pathlib import Path
from urllib.parse import unquote, urlparse


NATIVE_SUBTREES = ("sessions", "archived_sessions", "attachments")


class CaptureError(ValueError):
    """An original or its selected history cannot be captured completely."""


def _home(home=None) -> Path:
    if home is not None:
        return Path(home).expanduser().absolute() / ".codex"
    return Path(os.environ.get("CODEX_HOME", Path.home() / ".codex"))


def native_root(home=None) -> Path:
    return _home(home)


@contextmanager
def _connect(root: Path):
    db = sqlite3.connect((root / "state_5.sqlite").as_uri() + "?mode=ro", uri=True, timeout=2)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA query_only=ON")
    db.execute("BEGIN")
    try:
        yield db
    finally:
        db.close()


def discover(*, home=None) -> list[dict]:
    root = _home(home)
    if not (root / "state_5.sqlite").is_file():
        return []
    with _connect(root) as db:
        available = {row[1] for row in db.execute("PRAGMA table_info(threads)")}
        columns = [f'substr({name},1,160) AS {name}' if name in {"name", "title"} else name
                   for name in ("id", "cwd", "updated_at", "updated_at_ms", "source", "name", "title", "rollout_path") if name in available]
        return [_entry(dict(row)) for row in db.execute("SELECT " + ",".join(columns) + " FROM threads ORDER BY updated_at DESC, id")]


def source_state(native_id, *, home=None) -> dict:
    """Read current selection/dependency metadata without parsing saved rollouts."""
    metadata, files = {}, set()
    with _connect(_home(home)) as db:
        tables = {row[0] for row in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        pending = [native_id]
        while pending:
            identity = pending.pop()
            if identity in metadata:
                continue
            row = db.execute("SELECT * FROM threads WHERE id=?", (identity,)).fetchone()
            if row is None:
                raise CaptureError("thread metadata missing: " + identity)
            details = {"thread": dict(row)}
            files.add(str(row["rollout_path"]))
            for table in ("thread_attachments", "thread_dynamic_tools"):
                if table in tables:
                    details[table] = sorted((dict(item) for item in db.execute(f"SELECT * FROM {table} WHERE thread_id=?", (identity,))), key=lambda item: json.dumps(item, sort_keys=True))
            if "thread_spawn_edges" in tables:
                edges = sorted((dict(item) for item in db.execute("SELECT * FROM thread_spawn_edges WHERE parent_thread_id=?", (identity,))), key=lambda item: json.dumps(item, sort_keys=True))
                details["thread_spawn_edges"] = edges
                pending.extend(item["child_thread_id"] for item in edges)
            metadata[identity] = details
    return {"metadata": metadata, "files": sorted(files)}


def _entry(row):
    milliseconds = row.get("updated_at_ms")
    updated_at = milliseconds / 1000 if isinstance(milliseconds, (int, float)) and milliseconds > 0 else row.get("updated_at", 0)
    return {"native_id": row["id"], "harness": "codex", "cwd": row.get("cwd", ""),
            "title": row.get("name") or row.get("title") or "", "updated_at": updated_at,
            "source": row.get("source"), "native_path": row.get("rollout_path") or ""}


def _read(path: Path):
    before = path.stat()
    if path.suffix == ".zst":
        raise CaptureError(f"compressed rollout requires native decoding before capture: {path}")
    data = path.read_bytes()
    after = path.stat()
    if (before.st_ino, before.st_size, before.st_mtime_ns) != (after.st_ino, after.st_size, after.st_mtime_ns):
        raise CaptureError(f"source changed during capture: {path}")
    end = data.rfind(b"\n") + 1
    prefix = data[:end]
    records, offsets = [], [0]
    for line in prefix.splitlines(keepends=True):
        try:
            record = json.loads(line)
        except (ValueError, UnicodeDecodeError) as exc:
            raise CaptureError(f"invalid complete JSON record: {path}:{len(records)+1}") from exc
        if not isinstance(record, dict):
            raise CaptureError(f"non-object native record: {path}:{len(records)+1}")
        records.append(record)
        offsets.append(offsets[-1] + len(line))
    if not records or records[0].get("type") != "session_meta":
        raise CaptureError(f"missing initial session metadata: {path}")
    return data, prefix, records, offsets


def _rollout_id(path: Path):
    match = re.search(r"([0-9a-f]{8}-[0-9a-f-]{27})\.jsonl(?:\.zst)?$", path.name)
    if not match:
        raise CaptureError(f"unrecognized immutable rollout filename: {path}")
    return match.group(1)


def _ancestor(root: Path, rollout_id: str):
    if not re.fullmatch(r"[0-9a-f]{8}-[0-9a-f-]{27}", rollout_id):
        raise CaptureError("invalid history-base rollout ID")
    matches = [p for directory in (root / "sessions", root / "archived_sessions")
               for p in directory.rglob(f"*{rollout_id}.jsonl*")
               if p.is_file() and re.search(rf"[-_]{re.escape(rollout_id)}\.jsonl(?:\.zst)?$", p.name)]
    if len(matches) != 1:
        raise CaptureError(f"missing or ambiguous immutable ancestor: {rollout_id}")
    return matches[0]


def segments(path, *, home=None) -> list[dict]:
    """Rollout files, oldest first, whose records make up a thread's history, with each one's bounds."""
    root, path = _home(home), Path(path)
    result, seen, bound = [], set(), None
    while True:
        rollout_id = _rollout_id(path)
        if rollout_id in seen:
            raise CaptureError("history-base cycle detected")
        seen.add(rollout_id)
        with path.open("rb") as handle:
            try:
                meta = json.loads(handle.readline()).get("payload") or {}
            except (ValueError, UnicodeDecodeError, AttributeError) as exc:
                raise CaptureError(f"missing initial session metadata: {path}") from exc
        base = meta.get("history_base")
        if base is not None and (not isinstance(base, dict) or not {"thread_id", "end_byte_offset", "end_ordinal_exclusive"} <= base.keys()):
            raise CaptureError("malformed native history base")
        result.append({"path": str(path), "start_ordinal": base["end_ordinal_exclusive"] + 1 if base else None,
                       "end_ordinal_exclusive": bound["end_ordinal_exclusive"] if bound else None,
                       "byte_limit": bound["end_byte_offset"] if bound else None})
        if not base:
            return result[::-1]
        path, bound = _ancestor(root, base["thread_id"]), base


def _relative(path: Path, root: Path):
    for name in NATIVE_SUBTREES:
        base = root / name
        try:
            rel = path.resolve().relative_to(base.resolve())
        except ValueError:
            continue
        return str(Path(name) / rel)
    raise CaptureError(f"native path outside managed roots: {path}")


def _plan(path: Path, relative: str, data: bytes, byte_count=None):
    item = {"source": str(path.absolute()), "path": relative,
            "sha256": hashlib.sha256(data).hexdigest()}
    if byte_count is not None:
        item["byte_count"] = byte_count
    return item


def _dependencies(value, root: Path):
    """Only typed native local media and explicit artifact paths are dependencies."""
    if isinstance(value, list):
        for item in value:
            yield from _dependencies(item, root)
    elif isinstance(value, dict):
        kind = value.get("type", "")
        for key, item in value.items():
            if isinstance(item, str):
                local = None
                media = isinstance(kind, str) and kind in {"localImage", "local_image", "localAudio", "local_audio", "artifact", "attachment", "input_image", "image", "audio"}
                if media and item.startswith("file://"):
                    local = Path(unquote(urlparse(item).path))
                elif media and key in {"path", "local_path", "image_path", "audio_path", "artifact_path", "attachment_path"}:
                    local = Path(item).expanduser()
                if local is not None:
                    if not local.is_absolute():
                        raise CaptureError(f"relative native attachment has no stable root: {local}")
                    yield local
            if isinstance(item, (dict, list)):
                yield from _dependencies(item, root)


def _inline_image(content):
    if not isinstance(content, dict) or content.get("type") != "input_image":
        return False
    url = content.get("image_url")
    if not isinstance(url, str) or not re.match(r"^data:image/[^;,]+;base64,", url):
        return False
    try:
        return bool(base64.b64decode(url.split(",", 1)[1], validate=True))
    except (ValueError, binascii.Error):
        return False


def _record_dependencies(records, root):
    dependencies, inline_backed_missing = set(), []
    for index, record in enumerate(records):
        found = set(_dependencies(record, root))
        payload = record.get("payload") or {}
        item = payload.get("item") or {}
        if index and record.get("type") == "event_msg" and payload.get("type") == "item_completed" and item.get("type") == "UserMessage":
            previous = records[index-1]
            original = previous.get("payload") or {}
            identity = original.get("internal_chat_message_metadata_passthrough") or {}
            turn_id = payload.get("turn_id")
            local_images = [v for v in item.get("content", []) if isinstance(v, dict) and v.get("type") in {"local_image", "localImage"}]
            original_images = [(i, v) for i, v in enumerate(original.get("content", [])) if isinstance(v, dict) and v.get("type") == "input_image"]
            paired = (previous.get("type") == "response_item" and original.get("type") == "message"
                      and original.get("role") == "user" and turn_id and identity.get("turn_id") == turn_id
                      and len(local_images) == len(original_images)
                      and all(_inline_image(v) for _, v in original_images))
            if paired:
                for local, (content_index, _) in zip(local_images, original_images):
                    path = Path(local.get("path", "")).expanduser()
                    if path in found and not path.is_file():
                        found.remove(path)
                        inline_backed_missing.append({"source": str(path), "reason": "missing local locator; complete paired native image is inline",
                                                     "turn_id": turn_id, "event_ordinal": record.get("ordinal"),
                                                     "inline_ordinal": previous.get("ordinal"), "inline_content_index": content_index})
        dependencies.update(found)
    return dependencies, inline_backed_missing


def _boundary(records, partial):
    if partial:
        return {"ready": False, "reason": "native rollout has an incomplete trailing record"}
    lifecycle = None
    for record in records:
        if record.get("type") == "event_msg":
            kind = (record.get("payload") or {}).get("type")
            if kind in {"task_started", "turn_started"}:
                lifecycle = "active"
            elif kind in {"task_complete", "task_completed", "turn_complete", "turn_completed", "turn_aborted", "shutdown_complete"}:
                lifecycle = "saved"
        if record.get("type") == "response_item" and (record.get("payload") or {}).get("role") == "user":
            lifecycle = "active"
    return {"ready": lifecycle == "saved", "reason": "persisted terminal turn event and stable complete rollout" if lifecycle == "saved" else "active or unknown native writer; stop the owning thread before handoff"}


def capture(native_id, *, home=None, require_saved_boundary=False) -> dict:
    return _capture(native_id, home=home, require_saved_boundary=require_saved_boundary, visited=frozenset())


def _capture(native_id, *, home, require_saved_boundary, visited) -> dict:
    root = _home(home)
    result = {"native_id": native_id, "harness": "codex", "cwd": "", "title": "",
              "files": [], "primary": None, "metadata": {}, "cutoff": {},
              "complete": False, "missing": [], "saved_boundary": {"ready": False, "reason": "capture unavailable"}}
    try:
        if native_id in visited:
            raise CaptureError("subagent dependency cycle detected")
        visited = visited | {native_id}
        with _connect(root) as db:
            row = db.execute("SELECT * FROM threads WHERE id=?", (native_id,)).fetchone()
            if row is None:
                raise CaptureError(f"thread metadata missing: {native_id}")
            row = dict(row)
            result.update(_entry(row))
            selected = Path(row["rollout_path"])
            files, segments, dependencies = {}, [], set()
            inline_backed_missing = []
            seen = set()
            next_path, bound = selected, None
            selected_boundary = None
            last_timestamp = ""
            while True:
                path = next_path
                rollout_id = _rollout_id(path)
                if rollout_id in seen:
                    raise CaptureError("history-base cycle detected")
                seen.add(rollout_id)
                relative = _relative(path, root)
                data, prefix, records, offsets = _read(path)
                meta = records[0].get("payload") or {}
                if path == selected and meta.get("id") != native_id:
                    raise CaptureError("selected rollout belongs to another logical thread")
                base = meta.get("history_base")
                if base is not None and meta.get("history_mode") != "paginated":
                    raise CaptureError("history base on a non-paginated rollout")
                if base is not None:
                    if not isinstance(base, dict) or not {"thread_id", "end_byte_offset", "end_ordinal_exclusive"} <= base.keys():
                        raise CaptureError("malformed native history base")
                    if not isinstance(base["end_ordinal_exclusive"], int) or isinstance(base["end_ordinal_exclusive"], bool) or base["end_ordinal_exclusive"] < 1:
                        raise CaptureError("invalid history-base ordinal")
                start = base["end_ordinal_exclusive"] + 1 if base else 1
                byte_limit = bound["end_byte_offset"] if bound else len(prefix)
                end_ordinal = bound["end_ordinal_exclusive"] if bound else None
                if not isinstance(byte_limit, int) or isinstance(byte_limit, bool) or byte_limit not in offsets:
                    raise CaptureError("ancestor byte cutoff is outside a complete record boundary")
                if bound and (not isinstance(end_ordinal, int) or isinstance(end_ordinal, bool) or end_ordinal < 1):
                    raise CaptureError("invalid ancestor ordinal cutoff")
                chosen = records[:offsets.index(byte_limit)]
                if bound:
                    if not chosen:
                        raise CaptureError("ancestor cutoff excludes session metadata")
                    for record in chosen:
                        ordinal = record.get("ordinal")
                        if not isinstance(ordinal, int) or isinstance(ordinal, bool) or ordinal >= end_ordinal:
                            raise CaptureError("ancestor byte and ordinal cutoffs disagree")
                    remaining = records[offsets.index(byte_limit):]
                    if remaining and isinstance(remaining[0].get("ordinal"), int) and remaining[0]["ordinal"] < end_ordinal:
                        raise CaptureError("ancestor byte cutoff omits selected ordinals")
                raw = prefix if require_saved_boundary else data
                files[relative] = _plan(path, relative, raw, len(raw))
                segments.append({"path": relative, "rollout_id": rollout_id,
                                 "byte_limit": byte_limit, "start_ordinal": start,
                                 "end_ordinal_exclusive": end_ordinal})
                segment_dependencies, segment_inline_backed = _record_dependencies(chosen, root)
                dependencies.update(segment_dependencies)
                inline_backed_missing.extend(dict(item, path=relative) for item in segment_inline_backed)
                if path == selected:
                    result["primary"] = relative
                    selected_boundary = _boundary(records, len(data) != len(prefix))
                    last_timestamp = str(records[-1].get("timestamp") or "")
                    result["cutoff"] = {"bytes": len(prefix), "records": len(records), "timestamp": last_timestamp,
                                        "ordinal": records[-1].get("ordinal"), "partial_tail_bytes": len(data)-len(prefix)}
                if not base:
                    break
                next_path, bound = _ancestor(root, base["thread_id"]), base
            tables = {r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            metadata = {"thread": row, "segments": list(reversed(segments)), "metadata_read": "SQLite read transaction",
                        "inline_backed_missing": inline_backed_missing}
            for table in ("thread_attachments", "thread_dynamic_tools"):
                if table in tables:
                    metadata[table] = [dict(r) for r in db.execute(f"SELECT * FROM {table} WHERE thread_id=?", (native_id,))]
                    if table == "thread_attachments":
                        for attachment in metadata[table]:
                            payload = attachment.get("payload")
                            if isinstance(payload, str):
                                try:
                                    dependencies.update(_dependencies(json.loads(payload), root))
                                except json.JSONDecodeError as exc:
                                    raise CaptureError("invalid native attachment metadata") from exc
            if "thread_spawn_edges" in tables:
                edges = [dict(r) for r in db.execute("SELECT * FROM thread_spawn_edges WHERE parent_thread_id=?", (native_id,))]
                metadata["thread_spawn_edges"] = edges
                metadata["subagents"] = []
                for edge in edges:
                    child = _capture(edge["child_thread_id"], home=home, require_saved_boundary=False, visited=visited)
                    if not child["complete"]:
                        result["missing"].append(f"incomplete subagent original {edge['child_thread_id']}: {child['missing']}")
                    for item in child["files"]:
                        existing = files.get(item["path"])
                        if existing is None:
                            files[item["path"]] = item
                        elif existing["sha256"] != item["sha256"]:
                            raise CaptureError("shared native history changed while capturing subagents")
                    metadata["subagents"].append({k: child[k] for k in ("native_id", "primary", "metadata", "cutoff", "saved_boundary")})
                    if not child["saved_boundary"]["ready"]:
                        selected_boundary = {"ready": False, "reason": f"subagent {edge['child_thread_id']} has an active or unknown saved boundary"}
            for dep in sorted(dependencies):
                if not dep.is_file():
                    result["missing"].append(f"missing native attachment: {dep}")
                    continue
                raw = dep.read_bytes()
                relative = "dependencies/" + hashlib.sha256(str(dep).encode()).hexdigest()[:16] + "/" + dep.name
                files[relative] = _plan(dep, relative, raw)
            if result["cutoff"].get("partial_tail_bytes"):
                result["missing"].append("native rollout has a partial trailing record")
            result.update(files=list(files.values()), metadata=metadata, complete=not result["missing"],
                          saved_boundary=selected_boundary)
        with _connect(root) as verify:
            current = verify.execute("SELECT rollout_path FROM threads WHERE id=?", (native_id,)).fetchone()
            if current is None or current[0] != str(selected):
                raise CaptureError("selected native rollout changed during capture")
        if require_saved_boundary and not result["saved_boundary"]["ready"]:
            result["status"] = "not_ready"
        else:
            result["status"] = "ready"
    except (OSError, sqlite3.Error, CaptureError, KeyError, TypeError, ValueError) as exc:
        if "files" in locals():
            result["files"] = list(files.values())
        if "metadata" in locals():
            result["metadata"] = metadata
        result.update(complete=False, status="not_ready", missing=[str(exc)],
                      saved_boundary={"ready": False, "reason": str(exc)})
        if not require_saved_boundary and "selected" in locals():
            try:
                relative = _relative(selected, root)
                if not any(item["path"] == relative for item in result["files"]):
                    raw = selected.read_bytes()
                    result["files"].append(_plan(selected, relative, raw, len(raw)))
                result["primary"] = relative
                result["metadata"]["unparsed_native_original"] = str(exc)
            except (OSError, CaptureError):
                pass
    return result


class _RPC:
    """Bounded WebSocket JSON-RPC on the already running managed Unix socket."""
    def __init__(self, sock, timeout=15):
        from websockets.sync.client import unix_connect
        try:
            self.connection = unix_connect(str(sock), uri="ws://localhost/", open_timeout=timeout)
        except Exception as exc:
            raise RuntimeError(f"native app-server connection failed: {exc}") from exc
        self.timeout, self.next_id = timeout, 0
        try:
            self.call("initialize", {"clientInfo": {"name": "ctx", "version": "1"}, "capabilities": {}})
            self.connection.send(json.dumps({"method": "initialized", "params": {}}))
        except Exception as exc:
            self.connection.close()
            raise RuntimeError(f"native app-server initialization failed: {exc}") from exc

    def call(self, method, params):
        import time
        self.next_id += 1
        request_id = self.next_id
        self.connection.send(json.dumps({"id": request_id, "method": method, "params": params}))
        deadline = time.monotonic() + self.timeout
        while time.monotonic() < deadline:
            try:
                message = json.loads(self.connection.recv(timeout=max(0.001, deadline-time.monotonic())))
            except Exception as exc:
                raise RuntimeError(f"native {method} response failed: {exc}") from exc
            if message.get("id") == request_id:
                if "error" in message:
                    raise RuntimeError(f"native {method}: {message['error']}")
                return message.get("result", {})
        raise TimeoutError(f"native {method} timed out")

    def close(self):
        self.connection.close()


def _socket(root):
    configured = os.environ.get("CTX_CODEX_SOCKET")
    return Path(configured) if configured else root / "app-server-control" / "app-server-control.sock"


def holder(native_id, *, home=None):
    """Name a turn still running on this thread here; an idle loaded thread is not a holder."""
    sock, rpc = _socket(_home(home)), None
    if not sock.is_socket():
        return None
    try:
        rpc = _RPC(sock)
        if native_id not in rpc.call("thread/loaded/list", {}).get("data", []):
            return None
        status = rpc.call("thread/read", {"threadId": native_id, "includeTurns": False})["thread"].get("status", {})
        return "a Codex turn is still running on this thread here; let it finish first" if status.get("type") == "active" else None
    finally:
        if rpc:
            rpc.close()


def release(native_id, *, home=None):
    """Nothing to stop: the managed daemon keeps idle threads loaded and resumes them on request."""


def launch(workspace, prompt, *, resume, home=None) -> dict:
    """Resume thread `resume` from its rollout in `workspace` and send the first turn."""
    root, workspace = _home(home), Path(workspace).absolute()
    sock = _socket(root)
    if not workspace.is_dir() or not sock.is_socket():
        return {"status": "not_ready", "reason": "destination workspace or managed native app-server socket is unavailable", "retry_safe": True}
    rpc, native_id = None, None
    try:
        rpc = _RPC(sock)
        response = rpc.call("thread/resume", {"threadId": resume, "cwd": str(workspace), "excludeTurns": True})
        native_id = response["thread"]["id"]
        turn = rpc.call("turn/start", {"threadId": native_id, "input": [{"type": "text", "text": prompt}]})
        return {"status": "started", "native_id": native_id, "turn_id": turn["turn"]["id"],
                "transport": "managed native app-server Unix WebSocket", "socket": str(sock),
                "url": f"codex://threads/{native_id}",
                "attach_command": ["codex", "resume", native_id, "--remote", "unix://" + str(sock), "--cd", str(workspace)]}
    except (OSError, RuntimeError, TimeoutError, ValueError, KeyError, ImportError) as exc:
        return {"status": "not_ready", "native_id": native_id, "reason": str(exc), "launch_uncertain": True}
    finally:
        if rpc:
            rpc.close()

