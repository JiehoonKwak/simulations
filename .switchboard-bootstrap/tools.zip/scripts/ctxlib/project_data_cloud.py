"""Portable, nonsecret Cloud project identity and provider configuration."""

from __future__ import annotations

import json
import os
import re
from contextlib import contextmanager
from pathlib import Path
from urllib.parse import urlsplit

from .core import NotReady, atomic_json, component, run_git

CONFIG_PATH = Path(__file__).resolve().parents[2] / 'config/project-data-cloud.json'
PROVIDERS = ('codex', 'claude')
ENDPOINT = 'https://data.jjhouse0722.myds.me:443'


def normalize_repository(value):
    """Compare HTTPS and SSH GitHub origins without trusting host-local paths."""
    if not isinstance(value, str):
        return None
    value = value.strip()
    scp = re.fullmatch(r'git@github\.com:([^\s]+)', value, re.IGNORECASE)
    if scp:
        path = scp[1]
    else:
        try:
            parsed = urlsplit(value)
            if (parsed.scheme not in ('https', 'ssh') or parsed.hostname != 'github.com'
                    or parsed.password is not None or parsed.query or parsed.fragment
                    or parsed.port not in (None, 443 if parsed.scheme == 'https' else 22)
                    or parsed.username not in (None, 'git')):
                return None
        except ValueError:
            return None
        path = parsed.path.lstrip('/')
    path = path.removesuffix('/').removesuffix('.git')
    if not re.fullmatch(r'[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+', path):
        return None
    return 'github.com/' + path.casefold()


def configuration():
    try:
        value = json.loads(CONFIG_PATH.read_text())
        if (not isinstance(value, dict) or value.get('schema_version') != 1
                or value.get('endpoint') != ENDPOINT
                or value.get('providers') != {
                    'codex': {'auth': 'token-env', 'token_env': 'CTX_NAS_TOKEN'},
                    'claude': {'auth': 'proxy'},
                } or not isinstance(value.get('projects'), list)):
            raise ValueError
        identities, repositories = set(), set()
        for project in value['projects']:
            if not isinstance(project, dict):
                raise TypeError
            identity = component(project['project'])
            if identity == 'backups-1acdfe0f' or identity in identities:
                raise ValueError
            identities.add(identity)
            aliases = project.get('aliases', [])
            if not isinstance(aliases, list) or any(not isinstance(a, str) or not a.strip() for a in aliases):
                raise ValueError
            if 'repository' in project:
                repository = normalize_repository(project['repository'])
                if repository is None or repository in repositories:
                    raise ValueError
                repositories.add(repository)
        return value
    except (OSError, ValueError, KeyError, TypeError):
        raise NotReady('Cloud project configuration is missing or invalid; no remote fallback was used') from None


def resolve_project(selector):
    projects = configuration()['projects']
    exact = [p['project'] for p in projects if p['project'] == selector]
    if exact:
        return exact[0]
    matches = [p['project'] for p in projects
               if any(a.casefold() == selector.casefold() for a in p.get('aliases', []))]
    if len(matches) != 1:
        raise NotReady('Cloud project selector is unknown or ambiguous; use its approved stable project ID')
    return matches[0]


def resolve_repository(root):
    projects = configuration()['projects']
    try:
        origin = run_git(Path(root), 'remote', 'get-url', 'origin').decode().strip()
    except NotReady:
        return None
    repository = normalize_repository(origin)
    return next((p['project'] for p in projects
                 if repository is not None and normalize_repository(p.get('repository')) == repository), None)


def profile_path(ctx):
    return ctx.config.state / 'project-data/cloud-profile.json'


def cloudsettings(ctx):
    provider = os.environ.get('CTX_PROJECT_DATA_PROVIDER')
    path = profile_path(ctx)
    if path.exists():
        try:
            profile = json.loads(path.read_text())
            if (not isinstance(profile, dict) or set(profile) != {'schema_version', 'provider'}
                    or profile['schema_version'] != 1 or profile['provider'] not in PROVIDERS
                    or (provider is not None and provider != profile['provider'])):
                raise ValueError
            provider = profile['provider']
        except (OSError, ValueError, KeyError, TypeError):
            raise NotReady('Cloud provider profile is invalid or conflicts with the environment; no remote fallback was used') from None
    if provider is None:
        return None
    if provider not in PROVIDERS:
        raise NotReady('Cloud provider must be codex or claude; no remote fallback was used')
    config = configuration()
    runtime = ctx.config.state / 'project-data'
    return {'endpoint': config['endpoint'], **config['providers'][provider], 'provider': provider,
            'use_sessions': True,
            'cache': str(runtime / 'cache'), 'tasks': str(runtime / 'tasks')}


def configure(ctx, provider):
    if provider not in PROVIDERS:
        raise NotReady('Cloud provider must be codex or claude')
    configuration()
    configured_provider = os.environ.get('CTX_PROJECT_DATA_PROVIDER')
    if configured_provider is not None and configured_provider != provider:
        raise NotReady('Cloud provider conflicts with CTX_PROJECT_DATA_PROVIDER')
    path = profile_path(ctx)
    atomic_json(path, {'schema_version': 1, 'provider': provider})
    return {'status': 'complete', 'provider': provider, 'profile': str(path),
            'endpoint': ENDPOINT, 'project_count': len(configuration()['projects'])}


@contextmanager
def selected_project(selector):
    """Keep CLI overrides command-local, including error exits in embedded callers."""
    previous = os.environ.get('CTX_PROJECT_DATA_PROJECT')
    if selector is not None:
        os.environ['CTX_PROJECT_DATA_PROJECT'] = resolve_project(selector)
    try:
        yield
    finally:
        if previous is None:
            os.environ.pop('CTX_PROJECT_DATA_PROJECT', None)
        else:
            os.environ['CTX_PROJECT_DATA_PROJECT'] = previous
