"""Host-local conversation index.

Each host indexes its own native Codex and Claude transcripts straight from disk
and pulls the indexed turns of its peers over SSH. Only dialogue text crosses the
network: a peer sends the sessions and turns that changed after the last sequence
number this host received. Native records stay on the host that owns them; a raw
read of a peer's session asks that peer.
"""

from __future__ import annotations

import hashlib
import json
import re
import sqlite3
import subprocess
import time
import uuid
from contextlib import closing
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from . import codex, dialogue

SCHEMA = """
CREATE TABLE IF NOT EXISTS sessions (
    key TEXT PRIMARY KEY, host TEXT NOT NULL, harness TEXT NOT NULL, native_id TEXT NOT NULL,
    project_id TEXT, cwd TEXT NOT NULL DEFAULT '', title TEXT NOT NULL DEFAULT '',
    origin TEXT NOT NULL DEFAULT 'interactive', last_message_at TEXT NOT NULL DEFAULT '',
    turn_count INTEGER NOT NULL DEFAULT 0, signature TEXT NOT NULL DEFAULT '',
    gap TEXT, seq INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS turns (
    id INTEGER PRIMARY KEY, key TEXT NOT NULL, ordinal INTEGER NOT NULL,
    timestamp TEXT NOT NULL, role TEXT NOT NULL, text TEXT NOT NULL,
    locators TEXT NOT NULL, seq INTEGER NOT NULL DEFAULT 0,
    UNIQUE(key, ordinal)
);
CREATE VIRTUAL TABLE IF NOT EXISTS turns_fts USING fts5(text, content='turns', content_rowid='id', tokenize='unicode61');
CREATE TABLE IF NOT EXISTS meta (name TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS sessions_host_seq ON sessions(host, seq);
CREATE INDEX IF NOT EXISTS turns_seq ON turns(seq);
"""
EXPORT_BYTES = 16 * 1024 * 1024
PARSER = 2


def key(host: str, harness: str, native_id: str) -> str:
    return hashlib.sha256(f"{host}:{harness}:{native_id}".encode()).hexdigest()


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def connect(path: Path) -> sqlite3.Connection:
    path.parent.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(path, timeout=30)
    path.chmod(0o600)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA journal_mode=WAL")
    db.executescript(SCHEMA)
    if not _meta(db, "epoch"):
        with db:
            _set(db, "epoch", uuid.uuid4().hex)
    return db


def readonly(path: Path) -> sqlite3.Connection:
    if not path.is_file():
        raise FileNotFoundError("context index has not been built; run ctx sync")
    db = sqlite3.connect(path.resolve().as_uri() + "?mode=ro", uri=True, timeout=30)
    db.row_factory = sqlite3.Row
    return db


def _meta(db, name, default=None):
    row = db.execute("SELECT value FROM meta WHERE name=?", (name,)).fetchone()
    return json.loads(row[0]) if row else default


def _set(db, name, value):
    db.execute("INSERT OR REPLACE INTO meta VALUES(?,?)", (name, json.dumps(value)))


def _next_seq(db) -> int:
    value = _meta(db, "seq", 0) + 1
    _set(db, "seq", value)
    return value


def _messages(harness: str, path: Path, home=None) -> list[dict]:
    if harness == "claude":
        parts = [({"path": str(path)}, dialogue.claude_dialogue(path))]
    else:
        parts = []
        for segment in codex.segments(path, home=home):
            bounds = {name: segment[name] for name in ("start_ordinal", "end_ordinal_exclusive", "byte_limit") if segment[name] is not None}
            parts.append((segment, dialogue.codex_dialogue(Path(segment["path"]), **bounds)))
    result = []
    for segment, messages in parts:
        messages = [message for message in messages if message.get("phase") != "commentary"]
        for message in messages:
            message["raw_segment"] = segment
            result.append(message)
    return result


def _write_turns(db, session_key: str, messages: list[dict], seq: int) -> None:
    existing = {row["ordinal"]: row for row in db.execute("SELECT id,ordinal,timestamp,role,text,locators FROM turns WHERE key=?", (session_key,))}
    for ordinal, message in enumerate(messages, 1):
        locators = json.dumps({name: message[name] for name in ("native_id", "raw_lines", "raw_segment") if name in message})
        values = (message["timestamp"], message["role"], message["text"], locators)
        old = existing.get(ordinal)
        if old is not None and (old["timestamp"], old["role"], old["text"], old["locators"]) == values:
            continue
        _put_turn(db, session_key, ordinal, *values, seq)
    _trim(db, session_key, len(messages))


def _put_turn(db, session_key, ordinal, timestamp, role, text, locators, seq):
    old = db.execute("SELECT id,text FROM turns WHERE key=? AND ordinal=?", (session_key, ordinal)).fetchone()
    if old is not None:
        db.execute("INSERT INTO turns_fts(turns_fts,rowid,text) VALUES('delete',?,?)", (old["id"], old["text"]))
        db.execute("DELETE FROM turns WHERE id=?", (old["id"],))
    cursor = db.execute("INSERT INTO turns(key,ordinal,timestamp,role,text,locators,seq) VALUES(?,?,?,?,?,?,?)",
                        (session_key, ordinal, timestamp, role, text, locators, seq))
    db.execute("INSERT INTO turns_fts(rowid,text) VALUES(?,?)", (cursor.lastrowid, text))


def _trim(db, session_key, count):
    for row in db.execute("SELECT id,text FROM turns WHERE key=? AND ordinal>?", (session_key, count)).fetchall():
        db.execute("INSERT INTO turns_fts(turns_fts,rowid,text) VALUES('delete',?,?)", (row["id"], row["text"]))
    db.execute("DELETE FROM turns WHERE key=? AND ordinal>?", (session_key, count))


def _signature(paths) -> str:
    """Transcript sizes and times, prefixed with PARSER so raising it after a parsing or origin rule change reindexes every local session."""
    parts = [f"p{PARSER}"]
    for path in paths:
        stat = Path(path).stat()
        parts.append(f"{stat.st_size}:{stat.st_mtime_ns}")
    return ",".join(parts)


def refresh(ctx, *, budget: float = 300) -> dict:
    """Index this host's changed native sessions, newest first, within the budget."""
    host, deadline = ctx.config.host, time.monotonic() + budget
    sessions = sorted(ctx.sessions(), key=lambda item: float(item.get("updated_at") or 0), reverse=True)
    projects, indexed, pending, gaps = {}, 0, 0, 0
    with closing(connect(ctx.index_path)) as db:
        known = {row["key"]: row["signature"] for row in db.execute("SELECT key,signature FROM sessions WHERE host=?", (host,))}
        for item in sessions:
            path = item.get("native_path")
            session_key = key(host, item["harness"], item["native_id"])
            if not path or not Path(path).is_file():
                continue
            try:
                signature = _signature([path])
            except OSError:
                continue
            if known.get(session_key) == signature:
                continue
            if time.monotonic() >= deadline:
                pending += 1
                continue
            cwd = item.get("cwd") or ""
            if cwd not in projects:
                projects[cwd] = ctx.project_id_for(cwd)
            gap = None
            try:
                messages = _messages(item["harness"], Path(path), ctx.config.native_home)
                origin = dialogue.origin(item["harness"], Path(path))
            except (OSError, ValueError) as error:
                messages, origin, gap = [], "interactive", str(error)
                gaps += 1
            with db:
                seq = _next_seq(db)
                _write_turns(db, session_key, messages, seq)
                db.execute("INSERT OR REPLACE INTO sessions(key,host,harness,native_id,project_id,cwd,title,origin,last_message_at,turn_count,signature,gap,seq)"
                           " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
                           (session_key, host, item["harness"], item["native_id"], projects[cwd], cwd,
                            dialogue.redact(item.get("title") or "")[:300], origin,
                            max((message["timestamp"] for message in messages), key=dialogue.timestamp_value, default=""),
                            len(messages), signature, gap, seq))
            indexed += 1
        with db:
            _set(db, "indexed_at", _now())
            _set(db, "pending", pending)
    return {"indexed_sessions": indexed, "pending_sessions": pending, "gaps": gaps}


def export(ctx, after: int, epoch: str | None = None) -> dict:
    """This host's own sessions and turns changed after `after`, oldest first, in bounded chunks."""
    with closing(readonly(ctx.index_path)) as db:
        current = _meta(db, "epoch")
        if epoch != current:
            after = 0
        rows = db.execute("SELECT * FROM sessions WHERE host=? AND seq>? ORDER BY seq", (ctx.config.host, after)).fetchall()
        sessions, turns, size, through = [], [], 0, after
        for row in rows:
            if size > EXPORT_BYTES:
                return {"status": "complete", "epoch": current, "through": through, "more": True, "sessions": sessions, "turns": turns}
            sessions.append({name: row[name] for name in row.keys()})
            for turn in db.execute("SELECT ordinal,timestamp,role,text,locators,seq FROM turns WHERE key=? AND seq>? ORDER BY ordinal", (row["key"], after)):
                turns.append([row["key"], *turn])
                size += len(turn["text"]) + len(turn["locators"]) + 64
            through = row["seq"]
        return {"status": "complete", "epoch": current, "through": through, "more": False, "sessions": sessions, "turns": turns}


def _fetch(peer: str, after: int, epoch: str | None, timeout: float) -> dict:
    command = f'"$HOME/.local/bin/ctx" _export {int(after)} {epoch or "-"} --json'
    result = subprocess.run(["ssh", "-C", "-o", "BatchMode=yes", "-o", "ConnectTimeout=5", peer, command],
                            capture_output=True, timeout=timeout)
    try:
        value = json.loads(result.stdout)
    except ValueError:
        raise RuntimeError((result.stderr.decode(errors="replace").strip() or "no answer")[-300:]) from None
    if value.get("status") != "complete":
        raise RuntimeError(value.get("reason", "export refused"))
    return value


def pull(ctx, peer: str, *, budget: float = 120, fetch=_fetch) -> dict:
    """Apply a peer's changed sessions and turns; replays are idempotent and resume from the stored cursor."""
    deadline, received = time.monotonic() + budget, {"sessions": 0, "turns": 0}
    with closing(connect(ctx.index_path)) as db:
        cursor = _meta(db, "peer:" + peer, {"epoch": None, "seq": 0})
        while True:
            try:
                value = fetch(peer, cursor["seq"], cursor["epoch"], max(10.0, deadline - time.monotonic()))
            except (RuntimeError, OSError, subprocess.TimeoutExpired) as error:
                with db:
                    _set(db, "peer:" + peer, {**cursor, "error": str(error)[:300], "failed_at": _now()})
                return {"status": "unreachable", "reason": str(error)[:300], **received}
            with db:
                if value["epoch"] != cursor["epoch"]:
                    for (session_key,) in db.execute("SELECT key FROM sessions WHERE host=?", (peer,)).fetchall():
                        _trim(db, session_key, 0)
                    db.execute("DELETE FROM sessions WHERE host=?", (peer,))
                for row in value["sessions"]:
                    if row["host"] != peer:
                        raise ValueError(f"{peer} exported a session of another host")
                    db.execute("INSERT OR REPLACE INTO sessions(" + ",".join(row) + ") VALUES(" + ",".join("?" * len(row)) + ")", list(row.values()))
                for session_key, ordinal, timestamp, role, text, locators, seq in value["turns"]:
                    _put_turn(db, session_key, ordinal, timestamp, role, text, locators, seq)
                for row in value["sessions"]:
                    _trim(db, row["key"], row["turn_count"])
                cursor = {"epoch": value["epoch"], "seq": value["through"], "pulled_at": _now()}
                _set(db, "peer:" + peer, cursor)
            received["sessions"] += len(value["sessions"])
            received["turns"] += len(value["turns"])
            if not value["more"] or time.monotonic() >= deadline:
                return {"status": "catching_up" if value["more"] else "complete", **received}



def _cutoff(since: str | float) -> str:
    if isinstance(since, (int, float)):
        return datetime.fromtimestamp(since, timezone.utc).isoformat()
    duration = re.fullmatch(r"(\d+(?:\.\d+)?)([smhdw])", since)
    if duration:
        seconds = float(duration[1]) * {"s": 1, "m": 60, "h": 3600, "d": 86400, "w": 604800}[duration[2]]
        return (datetime.now(timezone.utc) - timedelta(seconds=seconds)).isoformat()
    parsed = datetime.fromisoformat(since.replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        raise ValueError("since timestamp requires a UTC offset")
    return parsed.astimezone(timezone.utc).isoformat()


def _scope(project, since, origins, exclude) -> tuple[str, list[Any]]:
    where, values = ["1"], []
    if project is not None:
        where.append("s.project_id=?")
        values.append(project)
    if since is not None:
        where.append("julianday(s.last_message_at)>=julianday(?)")
        values.append(_cutoff(since))
    if origins:
        where.append("s.origin IN (" + ",".join("?" * len(origins)) + ")")
        values.extend(origins)
    if exclude:
        where.append("s.native_id NOT IN (" + ",".join("?" * len(exclude)) + ")")
        values.extend(exclude)
    return " AND ".join(where), values


def _source(row) -> dict:
    return {"id": row["key"], "host": row["host"], "harness": row["harness"], "native_id": row["native_id"],
            "project_id": row["project_id"], "origin": row["origin"], "title": dialogue.shorten(row["title"], 100),
            "last_message_at": row["last_message_at"], "turn_count": row["turn_count"]}


def summary(db) -> dict:
    peers = {name[5:]: value for name, value in ((row[0], json.loads(row[1])) for row in db.execute("SELECT name,value FROM meta WHERE name LIKE 'peer:%'"))}
    hosts = dict(db.execute("SELECT host,count(*) FROM sessions GROUP BY host").fetchall())
    return {"indexed_at": _meta(db, "indexed_at"), "pending_sessions": _meta(db, "pending", 0), "sessions": hosts,
            "gaps": db.execute("SELECT count(*) FROM sessions WHERE gap IS NOT NULL").fetchone()[0],
            "peers": {peer: {key: value.get(key) for key in ("pulled_at", "error", "failed_at") if value.get(key)} for peer, value in peers.items()}}


def status(path: Path) -> dict:
    with closing(readonly(path)) as db:
        value = summary(db)
        value["gap_sessions"] = [{"id": row[0], "host": row[1], "harness": row[2], "native_id": row[3], "reason": row[4]}
                                 for row in db.execute("SELECT key,host,harness,native_id,gap FROM sessions WHERE gap IS NOT NULL ORDER BY last_message_at DESC LIMIT 50")]
        return value


def sessions(path: Path, *, project=None, since=None, origins=dialogue.DEFAULT_ORIGINS, exclude=(), limit=30) -> dict:
    with closing(readonly(path)) as db:
        where, values = _scope(project, since, origins, exclude)
        rows = db.execute(f"SELECT s.* FROM sessions s WHERE {where} AND s.turn_count>0 ORDER BY julianday(s.last_message_at) DESC", values).fetchall()
        return {"sessions": [_source(row) for row in rows[:limit]], "more": max(0, len(rows) - limit), "index": summary(db)}


def search(path: Path, text: str, *, project=None, since=None, origins=dialogue.DEFAULT_ORIGINS, exclude=(), limit=10, session_key=None) -> dict:
    """The newest matching turn of each matching session, newest session first; within `session_key`, every matching turn in order."""
    if not isinstance(text, str) or not text.strip():
        raise ValueError("search query must contain text")
    if not 1 <= limit <= 200:
        raise ValueError("search limit must be between 1 and 200")
    text = text.strip()
    tokens = re.findall(r"[^\W_]+", text.casefold(), flags=re.UNICODE)
    expression = " AND ".join('"' + token.replace('"', '""') + '"' for token in tokens)
    with closing(readonly(path)) as db:
        where, values = ("s.key=?", [session_key]) if session_key else _scope(project, since, origins, exclude)
        literal = " AND ".join("instr(lower(t.text),?)>0" for _ in tokens) or "instr(lower(t.text),?)>0"
        literals = tokens or [text.casefold()]
        order = "1 ORDER BY m.ordinal" if session_key else "m.rank=1 ORDER BY julianday(m.timestamp) DESC,m.ordinal DESC"
        fts = "t.id IN (SELECT rowid FROM turns_fts WHERE turns_fts MATCH ?) OR " if expression else ""
        rows = db.execute(
            f"""WITH matched AS (
                SELECT t.key,t.ordinal,t.timestamp,t.role,t.text,
                       ROW_NUMBER() OVER (PARTITION BY t.key ORDER BY julianday(t.timestamp) DESC,t.ordinal DESC) AS rank,
                       COUNT(*) OVER (PARTITION BY t.key) AS matches
                FROM sessions s JOIN turns t USING(key) WHERE {where} AND ({fts}({literal})))
            SELECT s.*,m.ordinal,m.timestamp,m.role,m.text,m.matches FROM matched m JOIN sessions s USING(key)
            WHERE {order} LIMIT ?""",
            [*values, *([expression] if expression else []), *literals, limit + 1]).fetchall()
        hits = [{**_source(row), "turn": row["ordinal"], "timestamp": row["timestamp"], "role": row["role"],
                 "matches": row["matches"], "snippet": dialogue.excerpt(row["text"], text, 160)} for row in rows[:limit]]
        return {"query": text, "hits": hits, "more": len(rows) > limit, "index": summary(db)}


def resolve(path: Path, reference: str) -> dict:
    """A session row by full key or a unique prefix of at least six characters."""
    if not re.fullmatch(r"[0-9a-f]{6,64}", reference):
        raise ValueError("session ID must be a hexadecimal prefix of at least six characters")
    with closing(readonly(path)) as db:
        rows = db.execute("SELECT * FROM sessions WHERE key>=? AND key<?", (reference, reference + "g")).fetchmany(2)
    if not rows:
        raise LookupError(f"session not indexed: {reference}")
    if len(rows) > 1:
        raise LookupError(f"ambiguous session ID prefix: {reference}")
    return _source(rows[0])


def _turn_range(turns, count, around=None) -> tuple[int, int]:
    if turns is None and around is not None:
        if not 1 <= around <= count:
            raise ValueError(f"turn must lie between 1 and {count}")
        return max(1, around - 3), min(count, around + 3)
    if turns is None:
        return max(1, count - 9), count
    parts = str(turns).split(":")
    if len(parts) not in (1, 2):
        raise ValueError("use a turn number or inclusive START:END range")
    start, end = int(parts[0]), int(parts[-1])
    if start < 1 or end < start or end > count:
        raise ValueError(f"turn range must lie between 1 and {count}")
    if end - start >= 200:
        raise ValueError("read at most 200 turns at once; expand adjacent ranges")
    return start, end


def _redact(value):
    if isinstance(value, str):
        return dialogue.redact(value)
    if isinstance(value, list):
        return [_redact(item) for item in value]
    if isinstance(value, dict):
        return {name: _redact(item) for name, item in value.items()}
    return value


def _records(harness: str, messages: list[dict], following: dict | None) -> list[dict]:
    """The redacted native records behind the selected turns, up to the next turn, read from this host's transcript."""
    ranges: dict[str, dict] = {}
    for message in messages:
        lines = message.get("raw_lines") or []
        if lines:
            segment = message["raw_segment"]
            entry = ranges.setdefault(json.dumps(segment, sort_keys=True), {"segment": segment, "start": min(lines), "end": float("inf")})
            entry["start"] = min(entry["start"], min(lines))
    if following and following.get("raw_lines"):
        entry = ranges.get(json.dumps(following["raw_segment"], sort_keys=True))
        if entry is not None:
            entry["end"] = min(following["raw_lines"]) - 1
    records = []
    for entry in ranges.values():
        segment, source = entry["segment"], Path(entry["segment"]["path"])
        if harness == "codex":
            bounds = {name: segment[name] for name in ("start_ordinal", "end_ordinal_exclusive", "byte_limit") if segment.get(name) is not None}
            numbered = dialogue.codex_records(source, **bounds)
        else:
            numbered = ((record.pop("_raw_line"), record) for record in dialogue.claude_records(source))
        for number, record in numbered:
            if entry["start"] <= number <= entry["end"]:
                records.append({"path": str(source), "line": number, "record": _redact(record)})
            elif number > entry["end"]:
                break
    return records


def read(path: Path, session_key: str, *, turns=None, around=None, raw=False) -> dict:
    with closing(readonly(path)) as db:
        row = db.execute("SELECT * FROM sessions WHERE key=?", (session_key,)).fetchone()
        if row is None:
            raise LookupError(f"session not indexed: {session_key}")
        count = row["turn_count"]
        result = {"source": _source(row), "messages": [], "selection": {"available_turns": count}}
        if not count:
            return result
        start, end = _turn_range(turns, count, around)
        rows = db.execute("SELECT * FROM turns WHERE key=? AND ordinal BETWEEN ? AND ? ORDER BY ordinal", (session_key, start, end)).fetchall()
        result["messages"] = [{"turn": item["ordinal"], "timestamp": item["timestamp"], "role": item["role"], "text": item["text"],
                               **json.loads(item["locators"])} for item in rows]
        result["selection"].update(start=start, end=end, returned_turns=len(rows))
        following = db.execute("SELECT locators FROM turns WHERE key=? AND ordinal=?", (session_key, end + 1)).fetchone()
    if raw:
        result["records"] = _records(row["harness"], result["messages"], json.loads(following[0]) if following else None)
    return result
