"""Apple Health history as agent-ready tables, built from the deduplicated Health Export Kit store.

The iPhone exports overlapping windows every six hours; the kit's SQLite store keeps
one row per sample, day and metric. This module flattens that store into four
deterministic tables in the Vault: one row per day, per sleep session, per
workout, and the raw samples by month. Repeated captures of a sleep session or
workout, including one recorded by several sources, collapse to the best record.
"""

from __future__ import annotations

import csv
import io
import json
import re
import sqlite3
from contextlib import closing
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

SEOUL = ZoneInfo("Asia/Seoul")
SLEEP_COLUMNS = ("night", "start", "end", "asleep_h", "deep_min", "rem_min", "core_min", "unspecified_min", "awake_min",
                 "awakenings", "efficiency_pct", "hr_avg_bpm", "hrv_avg_ms", "spo2_avg_pct", "resp_rate_avg_brpm",
                 "wrist_temp_c", "source")
WORKOUT_COLUMNS = ("date", "start", "end", "kind", "minutes", "km", "active_kcal", "avg_hr_bpm", "max_hr_bpm",
                   "pace_min_per_km", "elevation_m", "indoor", "source")
SAMPLE_COLUMNS = ("metric", "representation", "ts_utc", "end_utc", "source", "value", "low", "high", "unit")
UNITS = {"%": "pct", "count": "", "BMI": "", "mL/kg·min": "ml_kg_min", "m/s": "m_s", "km/h": "km_h", "floors": ""}


def _local(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone(SEOUL)


def _clock(value: str) -> str:
    return _local(value).strftime("%Y-%m-%d %H:%M")


def column(metric: str, unit: str) -> str:
    """`heart.restingHR` in bpm -> `resting_hr_bpm`."""
    name = re.sub(r"(?<=[a-z0-9])(?=[A-Z])", "_", metric.split(".", 1)[-1]).lower()
    suffix = UNITS.get(unit, re.sub(r"[^a-z0-9]+", "_", unit.lower()).strip("_"))
    return name if not suffix or name.endswith(suffix) else f"{name}_{suffix}"


def _round(value, digits=1):
    return "" if value is None else round(value, digits)


def _deduplicated(rows, rank):
    """One row per overlapping time span: the same session captured while in progress,
    or recorded by several sources (Watch, iPhone, Sleep++, Strong), keeps its best record."""
    chosen, cluster_end = [], ""
    for row in sorted(rows, key=lambda item: (item[0], item[1])):
        if chosen and row[0] < cluster_end:
            if rank(row) > rank(chosen[-1]):
                chosen[-1] = row
            cluster_end = max(cluster_end, row[1])
        else:
            chosen.append(row)
            cluster_end = row[1]
    return chosen


def _watch(source: str) -> bool:
    return "watch" in source.casefold()


def _sleep(rows) -> list[dict]:
    result = []
    for start, end, source, asleep, payload in _deduplicated(rows, lambda row: (_watch(row[2]), row[3], row[1])):
        body = json.loads(payload)
        stages, vitals = body.get("stageTotalsSec") or {}, body.get("vitals") or {}
        minutes = lambda name: _round((stages.get(name) or 0) / 60, 0)
        vital = lambda name: _round((vitals.get(name) or {}).get("avg"), 2 if name == "wristTemperature" else 1)
        result.append({"night": _local(end).date().isoformat(), "start": _clock(start), "end": _clock(end),
                       "asleep_h": _round(asleep / 3600, 2), "deep_min": minutes("asleepDeep"), "rem_min": minutes("asleepREM"),
                       "core_min": minutes("asleepCore"), "unspecified_min": minutes("asleepUnspecified"),
                       "awake_min": _round((body.get("awakeSec") or 0) / 60, 0), "awakenings": body.get("awakenings", ""),
                       "efficiency_pct": body.get("sleepEfficiencyPct", ""), "hr_avg_bpm": vital("heartRate"),
                       "hrv_avg_ms": vital("hrvSDNN"), "spo2_avg_pct": vital("oxygenSaturation"),
                       "resp_rate_avg_brpm": vital("respiratoryRate"), "wrist_temp_c": vital("wristTemperature"), "source": source})
    return result


def _workouts(rows) -> list[dict]:
    result = []
    for start, end, source, kind, duration, distance, detail, payload in _deduplicated(
            rows, lambda row: (row[6], _watch(row[2]), row[4] or 0)):
        body = json.loads(payload)
        pace = body.get("averagePaceSecPerKm")
        result.append({"date": _local(start).date().isoformat(), "start": _clock(start), "end": _clock(end), "kind": kind,
                       "minutes": _round((duration or 0) / 60), "km": _round(distance, 2),
                       "active_kcal": _round(body.get("activeEnergyKcal"), 0), "avg_hr_bpm": body.get("averageHeartRateBpm", ""),
                       "max_hr_bpm": body.get("maxHeartRateBpm", ""), "pace_min_per_km": _round(pace / 60, 2) if pace else "",
                       "elevation_m": _round(body.get("elevationAscendedM"), 0),
                       "indoor": {True: "yes", False: "no"}.get(body.get("isIndoor"), ""), "source": source})
    return result


def _days(daily, sleeps, workouts) -> tuple[list[str], list[dict]]:
    metrics = sorted({(metric, unit) for _, metric, _, unit in daily})
    names = {metric: column(metric, unit) for metric, unit in metrics}
    days: dict[str, dict] = {}
    for day, metric, value, _ in daily:
        days.setdefault(day, {})[names[metric]] = _round(value, 2)
    for item in sleeps:
        row = days.setdefault(item["night"], {})
        row["sleep_sessions"] = row.get("sleep_sessions", 0) + 1
        for field in ("asleep_h", "deep_min", "rem_min", "core_min"):
            row["sleep_" + field] = _round(row.get("sleep_" + field, 0) + (item[field] or 0), 2)
    for item in workouts:
        row = days.setdefault(item["date"], {})
        row["workouts"] = row.get("workouts", 0) + 1
        row["workout_min"] = _round(row.get("workout_min", 0) + (item["minutes"] or 0))
        row["workout_kinds"] = " · ".join(dict.fromkeys(filter(None, [*row.get("workout_kinds", "").split(" · "), item["kind"]])))
    header = ["day", "sleep_sessions", "sleep_asleep_h", "sleep_deep_min", "sleep_rem_min", "sleep_core_min",
              "workouts", "workout_min", "workout_kinds", *dict.fromkeys(names[metric] for metric, _ in metrics)]
    return header, [{"day": day, **days[day]} for day in sorted(days)]


def _csv(header, rows) -> bytes:
    buffer = io.StringIO()
    writer = csv.DictWriter(buffer, fieldnames=header, lineterminator="\n", restval="")
    writer.writeheader()
    writer.writerows(rows)
    return buffer.getvalue().encode()


def build(db_path: Path) -> dict[str, bytes]:
    """Every output file, keyed by its path under `data/health/`."""
    with closing(sqlite3.connect(db_path.resolve().as_uri() + "?mode=ro", uri=True, timeout=30)) as db:
        daily = db.execute("SELECT day,metric,value,unit FROM daily ORDER BY day,metric").fetchall()
        sleeps = _sleep(db.execute("SELECT start_utc,end_utc,source,asleep_sec,payload FROM sleep").fetchall())
        workouts = _workouts(db.execute("SELECT start_utc,end_utc,source,kind,duration_sec,distance_km,detail_score,payload FROM workouts").fetchall())
        months: dict[str, list] = {}
        for row in db.execute("SELECT " + ",".join(SAMPLE_COLUMNS) + " FROM samples ORDER BY ts_utc,metric,representation,source"):
            months.setdefault(row[2][:7], []).append(dict(zip(SAMPLE_COLUMNS, row)))
    files = {"days.csv": _csv(*_days(daily, sleeps, workouts)),
             "sleep.csv": _csv(SLEEP_COLUMNS, sleeps), "workouts.csv": _csv(WORKOUT_COLUMNS, workouts)}
    files.update({f"samples/{month}.csv": _csv(SAMPLE_COLUMNS, rows) for month, rows in months.items()})
    return files
