"""Provider-neutral checkpoint transport; NAS owns roots, grants and publication.

Run behind an HTTPS reverse proxy, binding only its private loopback interface.
The client uses HTTPS (plain HTTP is permitted only for loopback tests).
"""
from __future__ import annotations

import argparse
import fcntl
import hashlib
import json
import os
import re
import shutil
import ssl
import threading
import time
from contextlib import contextmanager
from http.client import HTTPException
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import quote, unquote, urlsplit
from urllib.request import HTTPRedirectHandler, HTTPSHandler, Request, build_opener

from . import project_data_store as store
from . import project_data_auth as auth

CHUNK = 8 * 1024 * 1024
CONTROL_LIMIT = 64 * 1024
JSON_LIMIT = 64 * 1024 * 1024
MAX_CHECKPOINT_BYTES = 4 * 1024 ** 4


class TransportError(ValueError):
    pass


class SessionExpiredError(TransportError):
    pass


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise TransportError('data endpoint redirects are refused')


class Client:
    def __init__(self, settings):
        self.endpoint = settings['endpoint'].rstrip('/')
        parsed = urlsplit(self.endpoint)
        if (parsed.scheme != 'https' and not (parsed.scheme == 'http' and parsed.hostname in {'127.0.0.1', 'localhost', '::1'})) or parsed.username or parsed.password or parsed.query or parsed.fragment:
            raise TransportError('data endpoint must use HTTPS without embedded credentials')
        auth = settings.get('auth', 'token-file')
        self.authorization = None
        if auth == 'token-file':
            if settings.get('token_env') or not settings.get('token_file'):
                raise TransportError('token-file authentication requires only token_file')
            token_path = Path(settings['token_file']).expanduser()
            if token_path.is_symlink() or not token_path.is_file() or token_path.stat().st_mode & 0o077:
                raise TransportError('data token must be a private regular file')
            token = token_path.read_text().strip()
        elif auth == 'token-env':
            name = settings.get('token_env', '')
            if settings.get('token_file') or not isinstance(name, str) or not re.fullmatch('[A-Za-z_][A-Za-z0-9_]*', name):
                raise TransportError('token-env authentication requires only a token_env variable name')
            token = os.environ.get(name, '')
        elif auth == 'proxy':
            if settings.get('token_file') or settings.get('token_env'):
                raise TransportError('proxy authentication cannot also select a local token')
            token = None
        else:
            raise TransportError('unsupported data authentication mode')
        if token is not None:
            if not token or any(character.isspace() or ord(character) < 32 or ord(character) > 126 for character in token):
                raise TransportError('missing or invalid data authentication value')
            self.authorization = 'Bearer ' + token
        context = ssl.create_default_context(cafile=settings.get('ca_file'))
        self.opener = build_opener(NoRedirect(), HTTPSHandler(context=context))
        self.use_sessions = settings.get('use_sessions', False)
        if type(self.use_sessions) is not bool:
            raise TransportError('use_sessions must be a boolean')
        self.sessions = {}

    def raw_open(self, method, route, payload=None, headers=None):
        headers = dict(headers or {})
        if any(name.lower() == 'authorization' for name in headers):
            raise TransportError('request headers cannot override data authentication')
        if self.authorization is not None:
            headers['Authorization'] = self.authorization
        request = Request(self.endpoint + route, data=payload, method=method, headers=headers)
        try:
            return self.opener.open(request, timeout=120)
        except HTTPError as error:
            expired = False
            try:
                if error.code == 401:
                    value = json.loads(error.read(1024))
                    expired = isinstance(value, dict) and value.get('error') == 'session_expired'
            except (ValueError, OSError, HTTPException):
                pass
            finally:
                error.close()
            if expired:
                raise SessionExpiredError('access session expired') from None
            raise TransportError(f'data endpoint rejected request (HTTP {error.code})') from None
        except (URLError, OSError, HTTPException) as error:
            raise TransportError('data endpoint connection failed; partial transfer retained') from error

    def session(self, project, *, renew=False):
        current = self.sessions.get(project)
        if renew or current is None or current['expires_at'] <= time.time() + 5:
            with self.raw_open('POST', '/v1/session', store.encoded({'project': project}),
                               {'Content-Type': 'application/json'}) as response:
                current = json.loads(response.read(CONTROL_LIMIT + 1))
            if (not isinstance(current, dict) or current.get('status') != 'complete' or current.get('project') != project
                    or not isinstance(current.get('session'), str)
                    or len(current['session']) > 4096
                    or type(current.get('expires_at')) not in {int, float}
                    or not time.time() < current['expires_at'] <= time.time() + 3605):
                raise TransportError('data endpoint returned an invalid access session')
            self.sessions[project] = current
        return current['session']

    def open(self, method, route, payload=None, headers=None):
        headers = dict(headers or {})
        if any(name.lower() in {'authorization', 'x-ctx-session'} for name in headers):
            raise TransportError('request headers cannot override data authentication')
        if not self.use_sessions:
            return self.raw_open(method, route, payload, headers)
        if route == '/v1/store':
            project = store.component(json.loads(payload)['project'])
        else:
            parts = unquote(urlsplit(route).path).split('/')
            if len(parts) < 4 or parts[:3] != ['', 'v1', 'projects']:
                raise TransportError('access session requires a project data route')
            project = store.component(parts[3])
        for attempt in range(2):
            request_headers = {**headers, 'X-CTX-Session': self.session(project, renew=bool(attempt))}
            try:
                return self.raw_open(method, route, payload, request_headers)
            except SessionExpiredError:
                if attempt:
                    raise TransportError('access session expired after renewal') from None
        raise TransportError('access session renewal failed')

    def json(self, method, route, value=None):
        payload = store.encoded(value) if value is not None else None
        try:
            with self.open(method, route, payload, {'Content-Type': 'application/json'}) as response:
                body = response.read(JSON_LIMIT + 1)
        except (OSError, HTTPException) as error:
            raise TransportError('data endpoint response interrupted; operation retained for retry') from error
        if len(body) > JSON_LIMIT:
            raise TransportError('data endpoint response exceeds manifest limit')
        return json.loads(body)

    def command(self, request):
        if request.get('action') == 'receipt':
            return self.json('POST', '/v1/store', request)
        deadline = time.monotonic() + 24 * 3600
        while True:
            result = self.json('POST', '/v1/store', request)
            if result.get('status') != 'pending':
                return result
            if time.monotonic() >= deadline:
                raise TransportError('publication verification pending; candidate retained for retry')
            time.sleep(1)

    def transfer(self, source, target, *, upload=False, names=None):
        try:
            return self._transfer(source, target, upload=upload, names=names)
        except (OSError, HTTPException) as error:
            raise TransportError('data transfer interrupted; partial transfer retained') from error

    def _transfer(self, source, target, *, upload=False, names=None):
        remote = str(target if upload else source).rstrip('/')
        parsed = urlsplit(remote)
        if parsed.scheme != 'ctx-http':
            raise TransportError('invalid data transport location')
        project = store.component(parsed.netloc)
        parts = parsed.path.strip('/').split('/')
        kind, identifier = parts[:2]
        if kind not in {'staging', 'checkpoints'}:
            raise TransportError('invalid data transport location')
        store.component(identifier)
        base = '/v1/projects/' + project + '/' + kind + '/' + identifier
        if upload:
            source = Path(source)
            manifest = json.loads((source / 'manifest.json').read_text())
            self.json('POST', base + '/manifest', manifest)
            for name, entry in manifest['files'].items():
                route = base + '/files/' + quote(name, safe='/')
                state = self.json('GET', route)
                if state['complete']:
                    continue
                offset = state['offset']
                with (source / 'payload' / name).open('rb') as handle:
                    handle.seek(offset)
                    while offset < entry['size'] or (entry['size'] == 0 and offset == 0):
                        block = handle.read(CHUNK)
                        with self.open('PUT', route, block, {'Upload-Offset': str(offset), 'Content-Type': 'application/octet-stream'}) as response:
                            state = json.loads(response.read(1024))
                        offset = state['offset']
                        if state['complete'] or offset == entry['size']:
                            break
                deadline = time.monotonic() + 24 * 3600
                while not state['complete']:
                    if time.monotonic() >= deadline:
                        raise TransportError('upload verification pending; partial transfer retained')
                    time.sleep(0.1)
                    state = self.json('GET', route)
                    if state.get('failed'):
                        raise TransportError('upload checksum verification failed; candidate retained')
            return
        target = Path(target)
        if not names:
            return
        manifest = self.command({'action': 'inspect', 'project': project, 'revision': identifier})['manifest']
        for name in names:
            store.safe_path(name)
            destination = target / name
            destination.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
            partial = target.parent / ('.download-' + hashlib.sha256(name.encode()).hexdigest())
            offset = partial.stat().st_size if partial.exists() else 0
            if offset > manifest['files'][name]['size']:
                partial.unlink()
                offset = 0
            headers = {'Range': f'bytes={offset}-'} if offset else {}
            with self.open('GET', base + '/files/' + quote(name, safe='/'), headers=headers) as response:
                remaining = int(response.headers['Content-Length'])
                received = 0
                if offset and response.status != 206:
                    raise TransportError('data endpoint did not honor resumed download')
                with partial.open('ab' if offset else 'wb') as handle:
                    while True:
                        block = response.read(CHUNK)
                        if not block:
                            break
                        handle.write(block)
                        received += len(block)
                    handle.flush()
                    os.fsync(handle.fileno())
            if received != remaining:
                raise TransportError('download interrupted; partial transfer retained')
            os.replace(partial, destination)


def confined(root, relative, *, create=False):
    """Refuse every symlink, including missing-path parents, under server root."""
    store.safe_path(relative)
    current = root
    for part in Path(relative).parts:
        current = current / part
        if current.is_symlink():
            raise ValueError('symlinks are not permitted')
    if create:
        current.mkdir(parents=True, exist_ok=True, mode=0o700)
    return current


def validate_manifest(value, project):
    if value.get('schema_version') != 1 or value.get('project') != project or not isinstance(value.get('files'), dict):
        raise ValueError('invalid manifest identity')
    for name, entry in value['files'].items():
        store.safe_path(name)
        if not isinstance(entry, dict) or type(entry.get('size')) is not int or entry['size'] < 0 or not re.fullmatch('[0-9a-f]{64}', entry.get('sha256', '')):
            raise ValueError('invalid manifest file')
    if sum(entry['size'] for entry in value['files'].values()) > MAX_CHECKPOINT_BYTES:
        raise ValueError('checkpoint exceeds storage limit')
    return value


class Server(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, address, root, auth_file):
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True, mode=0o700)
        self.auth_file = Path(auth_file)
        self.jobs = set()
        self.jobs_lock = threading.Lock()
        self.connections = threading.BoundedSemaphore(32)
        super().__init__(address, Handler)

    def process_request(self, request, client_address):
        if not self.connections.acquire(blocking=False):
            self.shutdown_request(request)
            return
        try:
            super().process_request(request, client_address)
        except Exception:
            self.connections.release()
            raise

    def process_request_thread(self, request, client_address):
        try:
            super().process_request_thread(request, client_address)
        finally:
            self.connections.release()

    def launch(self, identifier, worker):
        with self.jobs_lock:
            if identifier in self.jobs:
                return
            if len(self.jobs) >= 8:
                return
            self.jobs.add(identifier)
        def execute():
            try:
                worker()
            finally:
                with self.jobs_lock:
                    self.jobs.discard(identifier)
        threading.Thread(target=execute, daemon=True).start()


class Handler(BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'

    def log_message(self, *args):
        pass

    def setup(self):
        super().setup()
        self.connection.settimeout(120)

    def reply(self, code, value):
        body = store.encoded(value)
        self.send_response(code)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(body)

    def body(self, limit):
        if self.headers.get('Transfer-Encoding'):
            raise ValueError('transfer encoding is unsupported')
        length = int(self.headers.get('Content-Length', '-1'))
        if not 0 <= length <= limit:
            raise ValueError('request size exceeds limit')
        data = self.rfile.read(length)
        if len(data) != length:
            raise ValueError('incomplete request')
        return data

    def authenticate(self):
        if (len(self.headers.get_all('Authorization', [])) != 1
                or len(self.headers.get_all('X-CTX-Session', [])) > 1):
            raise PermissionError('unauthorized')
        owner, grant = auth.authenticate(self.server.auth_file,
                                        self.headers.get('Authorization', ''),
                                        self.headers.get('X-CTX-Session'))
        self.auth_grant = grant
        return owner, grant

    def authorize(self, project, permission):
        if (len(self.headers.get_all('Authorization', [])) != 1
                or len(self.headers.get_all('X-CTX-Session', [])) > 1):
            raise PermissionError('unauthorized')
        owner, grant = auth.authenticate(self.server.auth_file,
                                        self.headers.get('Authorization', ''),
                                        self.headers.get('X-CTX-Session'),
                                        project=project, permission=permission)
        self.auth_grant = grant
        return owner

    def owns(self, recorded, owner):
        return auth.owns(self.auth_grant, owner, recorded)

    @contextmanager
    def stage_lock(self, project, identifier, fingerprint):
        lock_dir = confined(self.server.root, f'projects/{project}/.http-locks', create=True)
        with (lock_dir / identifier).open('a+') as handle:
            fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
            handle.seek(0)
            owner = handle.read().strip()
            if owner and not self.owns(owner, fingerprint):
                raise PermissionError('ticket belongs to another credential')
            if owner != fingerprint:
                handle.seek(0)
                handle.truncate()
                handle.write(fingerprint)
                handle.flush()
                os.fsync(handle.fileno())
            yield

    def do_GET(self):
        self.handle_request()

    def do_POST(self):
        self.handle_request()

    def do_PUT(self):
        self.handle_request()

    def handle_request(self):
        try:
            route = urlsplit(self.path)
            if route.query or route.fragment:
                raise ValueError('invalid route')
            if route.path == '/v1/session' and self.command == 'POST':
                if (len(self.headers.get_all('Authorization', [])) != 1
                        or self.headers.get_all('X-CTX-Session', [])):
                    raise PermissionError('unauthorized')
                request = json.loads(self.body(CONTROL_LIMIT))
                if set(request) != {'project'}:
                    raise ValueError('invalid access session request')
                self.reply(200, auth.issue_session(self.server.auth_file,
                                                  self.headers.get('Authorization', ''),
                                                  store.component(request['project'])))
                return
            if route.path == '/v1/store' and self.command == 'POST':
                self.store_command()
                return
            parts = unquote(route.path).split('/')
            if len(parts) < 7 or parts[:3] != ['', 'v1', 'projects']:
                raise ValueError('invalid route')
            project, kind, identifier = store.component(parts[3]), parts[4], store.component(parts[5])
            resource = parts[6]
            if kind == 'checkpoints' and resource == 'files' and self.command == 'GET':
                self.authorize(project, 'read')
                auth.authorize_revision(self.auth_grant, project, identifier)
                self.download(project, identifier, '/'.join(parts[7:]))
                return
            if kind != 'staging':
                raise ValueError('immutable checkpoint or invalid route')
            fingerprint = self.authorize(project, 'write')
            with self.stage_lock(project, identifier, fingerprint):
                stage = confined(self.server.root, f'projects/{project}/staging/{identifier}')
                if not stage.is_dir():
                    raise ValueError('stage not found')
                if resource == 'manifest' and len(parts) == 7 and self.command == 'POST':
                    self.manifest(stage, project)
                elif resource == 'files' and len(parts) >= 8:
                    self.upload(stage, '/'.join(parts[7:]))
                else:
                    raise ValueError('invalid route')
        except auth.ExpiredSession:
            self.close_connection = True
            self.reply(401, {'status': 'not_ready', 'error': 'session_expired'})
        except PermissionError:
            self.close_connection = True
            self.reply(403, {'status': 'not_ready', 'reason': 'access denied'})
        except (ValueError, OSError, KeyError, TypeError):
            self.close_connection = True
            self.reply(400, {'status': 'not_ready', 'reason': 'invalid or incomplete checkpoint request'})

    def store_command(self):
        self.authenticate()
        request = json.loads(self.body(CONTROL_LIMIT))
        project = store.component(request['project'])
        action = request['action']
        if action not in {'inspect', 'receipt', 'stage', 'publish'}:
            raise ValueError('unknown store action')
        if action == 'receipt':
            allowed = {'action', 'project', 'id'}
        else:
            allowed = {'action', 'project', 'revision'} if action == 'inspect' else {'action', 'project', 'id', 'revision', 'base'}
        if set(request) - allowed:
            raise ValueError('unexpected store fields')
        for key in ('revision', 'base', 'id'):
            if request.get(key) is not None:
                store.component(request[key])
        if action == 'publish' and not request.get('revision'):
            raise ValueError('publication revision is required')
        fingerprint = self.authorize(project, 'read' if action in {'inspect', 'receipt'} else 'write')
        confined(self.server.root, f'projects/{project}')
        if action == 'receipt':
            self.publication_receipt(project, store.component(request['id']))
            return
        for location in ('refs', 'refs/current.json', 'checkpoints', 'staging', '.publish.lock'):
            confined(self.server.root, f'projects/{project}/{location}')
        if action == 'inspect':
            value = self.inspect_checkpoint(project, request.get('revision'))
            if value.get('payload'):
                value['payload'] = f'ctx-http://{project}/checkpoints/{value["revision"]}/payload'
            self.reply(200, value)
            return
        identifier = store.component(request['id'])
        confined(self.server.root, f'projects/{project}/staging/{identifier}')
        if action == 'publish':
            auth.authorize_revision(self.auth_grant, project, request.get('base'))
            auth.authorize_revision(self.auth_grant, project, request['revision'])
            self.publish_async(project, identifier, fingerprint, request)
            return
        marker = confined(self.server.root, f'projects/{project}/.http-jobs/{identifier}.json')
        if marker.exists():
            job = json.loads(marker.read_text())
            if not self.owns(job['owner'], fingerprint):
                raise PermissionError('ticket belongs to another credential')
            if job['result']['status'] != 'not_ready':
                self.reply(200, {'status': 'complete', 'stage': f'ctx-http://{project}/staging/{identifier}',
                                 'resumed': True, 'publishing': True})
                return
        with self.stage_lock(project, identifier, fingerprint):
            if marker.exists():
                job = json.loads(marker.read_text())
                if not self.owns(job['owner'], fingerprint):
                    raise PermissionError('ticket belongs to another credential')
                if job['result']['status'] == 'not_ready':
                    marker.unlink()
                else:
                    self.reply(200, {'status': 'complete', 'stage': f'ctx-http://{project}/staging/{identifier}',
                                     'resumed': True, 'publishing': True})
                    return
            value = store.dispatch(self.server.root, request)
            if value.get('stage'):
                value['stage'] = f'ctx-http://{project}/staging/{identifier}'
        self.reply(200, value)

    def publication_receipt(self, project, identifier):
        """Read a task's publication without impersonating or restarting its writer."""
        marker = confined(self.server.root, f'projects/{project}/.http-jobs/{identifier}.json')
        if not marker.exists():
            self.reply(200, {'status': 'not_ready', 'reason': 'publication receipt not found',
                             'project': project, 'id': identifier})
            return
        with marker.open('rb') as handle:
            body = handle.read(CONTROL_LIMIT + 1)
        if len(body) > CONTROL_LIMIT:
            raise ValueError('publication receipt exceeds limit')
        job = json.loads(body)
        if not isinstance(job, dict):
            raise ValueError('invalid publication receipt')
        request, result = job['request'], job['result']
        if (not isinstance(request, dict) or not isinstance(result, dict)
                or request.get('action') != 'publish' or request.get('project') != project
                or request.get('id') != identifier
                or result.get('status') not in {'pending', 'complete', 'not_ready', 'conflict'}):
            raise ValueError('invalid publication receipt')
        store.component(request['revision'])
        for revision in (request.get('base'), request['revision'], result.get('revision')):
            if revision is not None:
                store.component(revision)
            auth.authorize_revision(self.auth_grant, project, revision)
        if result['status'] == 'complete' and result.get('revision') != request['revision']:
            raise ValueError('publication receipt revision mismatch')
        public_request = {key: request[key] for key in ('action', 'project', 'id', 'revision', 'base') if key in request}
        public_result = {key: result[key] for key in ('status', 'revision', 'idempotent', 'reason') if key in result}
        if ('idempotent' in public_result and type(public_result['idempotent']) is not bool
                or 'reason' in public_result and (not isinstance(public_result['reason'], str)
                                                or len(public_result['reason']) > 512)):
            raise ValueError('invalid publication receipt result')
        self.reply(200, {**public_result, 'project': project, 'id': identifier,
                         'request': public_request, 'result': public_result})

    def inspect_checkpoint(self, project, revision=None):
        reference = confined(self.server.root, f'projects/{project}/refs/current.json')
        current = json.loads(reference.read_text()) if reference.exists() else {}
        revision = revision or current.get('revision')
        auth.authorize_revision(self.auth_grant, project, revision)
        if revision is None:
            return {'status': 'complete', 'revision': None, 'manifest': None}
        checkpoint = confined(self.server.root, f'projects/{project}/checkpoints/{store.component(revision)}')
        confined(checkpoint, 'manifest.json')
        confined(checkpoint, 'payload')
        return store.dispatch(self.server.root, {'action': 'inspect', 'project': project, 'revision': revision})

    def publish_async(self, project, identifier, fingerprint, request):
        job_dir = confined(self.server.root, f'projects/{project}/.http-jobs', create=True)
        marker = confined(job_dir, identifier + '.json')
        if marker.exists():
            job = json.loads(marker.read_text())
            if not self.owns(job['owner'], fingerprint):
                raise PermissionError('ticket belongs to another credential')
            if job['request'] != request:
                raise ValueError('publication request cannot change')
        else:
            with self.stage_lock(project, identifier, fingerprint):
                if marker.exists():
                    job = json.loads(marker.read_text())
                    if not self.owns(job['owner'], fingerprint) or job['request'] != request:
                        raise ValueError('publication request cannot change')
                else:
                    job = {'owner': fingerprint, 'request': request, 'result': {'status': 'pending'}}
                    store.write_json(marker, job)
        if job['result']['status'] == 'pending':
            def verify():
                try:
                    with self.stage_lock(project, identifier, fingerprint):
                        stage = confined(self.server.root, f'projects/{project}/staging/{identifier}')
                        if stage.exists():
                            confined(stage, 'manifest.json')
                            confined(stage, 'payload')
                        checkpoint = confined(self.server.root, f'projects/{project}/checkpoints/{store.component(request["revision"])}')
                        if checkpoint.exists():
                            confined(checkpoint, 'manifest.json')
                            confined(checkpoint, 'payload')
                        result = store.dispatch(self.server.root, request,
                                                authorize=lambda: auth.revalidate(
                                                    self.server.auth_file, fingerprint, project, 'write',
                                                    revisions=(request.get('base'), request['revision'])))
                except (ValueError, OSError, KeyError, PermissionError):
                    result = {'status': 'not_ready', 'reason': 'checkpoint verification failed; candidate retained'}
                store.write_json(marker, {**job, 'result': result})
            self.server.launch(str(marker), verify)
        result = job['result']
        if result['status'] == 'complete':
            with self.stage_lock(project, identifier, fingerprint):
                latest = json.loads(marker.read_text())
                if latest.get('delivered'):
                    result = {**result, 'idempotent': True}
                else:
                    store.write_json(marker, {**latest, 'delivered': True})
        self.reply(200, result)

    def upload_paths(self, stage, name):
        directory = confined(stage.parent.parent, '.http-parts/' + stage.name, create=True)
        identity = hashlib.sha256(name.encode()).hexdigest()
        return directory / identity, directory / (identity + '.json')

    def verify_upload(self, stage, name, entry, fingerprint):
        partial, marker = self.upload_paths(stage, name)
        def verify():
            try:
                existing = json.loads(marker.read_text()) if marker.exists() else {}
                if existing.get('status') == 'complete':
                    return
                path = confined(stage, 'payload/' + name)
                candidate = partial if partial.exists() else path
                valid = candidate.is_file() and candidate.stat().st_size == entry['size'] and store.sha(candidate) == entry['sha256']
                with self.stage_lock(stage.parent.parent.name, stage.name, fingerprint):
                    if valid:
                        path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
                        if candidate == partial:
                            os.replace(partial, path)
                        store.write_json(marker, {'status': 'complete', 'size': entry['size'], 'sha256': entry['sha256']})
                    else:
                        if candidate.exists():
                            candidate.unlink()
                        store.write_json(marker, {'status': 'failed'})
            except (ValueError, OSError, KeyError):
                store.write_json(marker, {'status': 'failed'})
        self.server.launch(str(marker), verify)

    def manifest(self, stage, project):
        manifest = validate_manifest(json.loads(self.body(JSON_LIMIT)), project)
        marker = confined(stage, 'manifest.json')
        if marker.exists():
            if json.loads(marker.read_text()) != manifest:
                raise ValueError('ticket manifest cannot change')
            self.reply(200, {'status': 'complete'})
            return
        current = self.inspect_checkpoint(project)
        if current.get('manifest'):
            for name, entry in manifest['files'].items():
                if current['manifest']['files'].get(name) != entry:
                    continue
                source = confined(Path(current['payload']), name)
                target = confined(stage, 'payload/' + name)
                target.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
                if target.exists():
                    if not target.samefile(source) or target.stat().st_size != entry['size']:
                        raise ValueError('incomplete staging data differs from candidate')
                else:
                    os.link(source, target)
                _, upload_marker = self.upload_paths(stage, name)
                store.write_json(upload_marker, {'status': 'complete', 'size': entry['size'], 'sha256': entry['sha256']})
        store.write_json(marker, manifest)
        self.reply(200, {'status': 'complete'})

    def download(self, project, revision, name):
        store.safe_path(name)
        checkpoint = confined(self.server.root, f'projects/{project}/checkpoints/{revision}')
        manifest = json.loads(confined(checkpoint, 'manifest.json').read_text())
        if hashlib.sha256(store.encoded(manifest)).hexdigest() != revision or name not in manifest['files']:
            raise ValueError('unknown checkpoint file')
        path = confined(checkpoint, 'payload/' + name)
        size = path.stat().st_size
        if size != manifest['files'][name]['size']:
            raise ValueError('checkpoint size mismatch')
        offset = 0
        if self.headers.get('Range'):
            match = re.fullmatch(r'bytes=([0-9]+)-', self.headers['Range'])
            if not match:
                raise ValueError('invalid range')
            offset = int(match[1])
            if offset > size:
                raise ValueError('range exceeds file')
        self.send_response(206 if self.headers.get('Range') else 200)
        self.send_header('Content-Length', str(size - offset))
        self.send_header('Content-Type', 'application/octet-stream')
        self.send_header('Accept-Ranges', 'bytes')
        if self.headers.get('Range'):
            self.send_header('Content-Range', f'bytes {offset}-{max(offset, size - 1)}/{size}')
        self.end_headers()
        with path.open('rb') as handle:
            handle.seek(offset)
            shutil.copyfileobj(handle, self.wfile, CHUNK)

    def upload(self, stage, name):
        store.safe_path(name)
        manifest = json.loads(confined(stage, 'manifest.json').read_text())
        entry = manifest['files'][name]
        path = confined(stage, 'payload/' + name)
        partial, marker = self.upload_paths(stage, name)
        state = json.loads(marker.read_text()) if marker.exists() else {}
        complete = (state.get('status') == 'complete' and state.get('size') == entry['size']
                    and state.get('sha256') == entry['sha256'] and path.is_file()
                    and path.stat().st_size == entry['size'])
        offset = partial.stat().st_size if partial.exists() else 0
        fingerprint = self.authorize(stage.parent.parent.name, 'write')
        if self.command == 'GET':
            if not complete and (state.get('status') == 'pending' or (partial.exists() and offset == entry['size'])
                                 or (path.is_file() and path.stat().st_size == entry['size'])):
                if state.get('status') != 'pending':
                    store.write_json(marker, {'status': 'pending'})
                    state = {'status': 'pending'}
                self.verify_upload(stage, name, entry, fingerprint)
            if state.get('status') == 'failed':
                self.reply(200, {'offset': offset, 'complete': False, 'failed': True})
            else:
                self.reply(200, {'offset': entry['size'] if complete else offset, 'complete': complete})
            return
        if (self.command != 'PUT' or complete or state.get('status') == 'pending'
                or int(self.headers.get('Upload-Offset', '-1')) != offset):
            raise ValueError('invalid upload offset or completed file')
        block = self.body(CHUNK)
        if offset + len(block) > entry['size'] or (not block and entry['size']):
            raise ValueError('upload exceeds declared size')
        if shutil.disk_usage(self.server.root).free < len(block) + CHUNK:
            raise ValueError('insufficient staging space')
        with partial.open('ab') as handle:
            handle.write(block)
            handle.flush()
            os.fsync(handle.fileno())
        offset += len(block)
        if offset == entry['size']:
            store.write_json(marker, {'status': 'pending'})
            self.verify_upload(stage, name, entry, fingerprint)
        elif state.get('status') == 'failed':
            marker.unlink()
        self.reply(200, {'offset': offset, 'complete': False})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', required=True)
    parser.add_argument('--auth-file', required=True)
    parser.add_argument('--bind', default='127.0.0.1')
    parser.add_argument('--port', type=int, default=8766)
    args = parser.parse_args()
    os.umask(0o077)
    Server((args.bind, args.port), args.root, args.auth_file).serve_forever()


if __name__ == '__main__':
    main()
