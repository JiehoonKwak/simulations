"""Session inbox: one review queue of agent sessions and Switchboard tasks, kept on M1.

Hooks on each host spool prompt and Stop events locally. On the Macs `flush` enriches them
from native metadata and applies them to the store on the owner (M1), over SSH from M3.
NAS and BV have no route to M1, so M1 pulls them (`pull`): the host enriches and plans its
Herdr exits read-only (`export`), M1 validates that untrusted answer, stores it, and only
then lets the host delete the spool files it stored (`acknowledge`). Jiehoonk's Dashboard
reads and writes the same SQLite file; the schema below is its contract (see
docs/agents/session-inbox.md).
"""

from __future__ import annotations

from datetime import datetime
import fcntl
import json
import os
from pathlib import Path
import re
import sqlite3
import subprocess
import sys
import time
import uuid

from .core import NotReady, atomic_json, host_alias, remote
from . import herdr
from . import activity
from .dialogue import origin, redact
from .index import key as session_key

OWNER = "m1pro"
MACS = ("m1pro", "m3max")
PULLED = ("nas", "bv")
LABELS = {"m1pro": "M1", "m3max": "M3", "nas": "NAS", "bv": "BV"}
SPOOL = Path(os.environ.get("CTX_INBOX_SPOOL", Path.home() / ".local/state/ctx/inbox-spool"))
PULL_STATE = Path(os.environ.get("CTX_INBOX_PULL_STATE", Path.home() / ".local/state/ctx/inbox-pull"))
SPOOL_NAME = re.compile(r"\d{1,20}-[0-9a-f]{8}\.json")
NATIVE_ID = re.compile(r"[A-Za-z0-9][A-Za-z0-9._:-]{0,127}")
PANE = re.compile(r"[A-Za-z0-9][A-Za-z0-9:._-]{0,63}")
CONTROL = re.compile(r"[\x00-\x1f\x7f-\x9f]")
EXPORT_LIMIT = 200
DESKTOP_APP = sys.platform == "darwin"
STORE = Path(os.environ.get("CTX_INBOX_DB", Path.home() / ".local/share/ctx/inbox.sqlite"))
CODEX_HOME = Path(os.environ.get("CODEX_HOME", Path.home() / ".codex"))
BACKGROUND = {"agent", "headless"}
MACHINES = {"m1": "m1pro", "m3": "m3max", "nas": "nas"}
# What an agent needs to judge a session without opening it: the last exchange, what waits on the user,
# and what the session changed. Files and commits accumulate over the session (JSON lists).
DETAIL_COLUMNS = {"prompt": "TEXT NOT NULL DEFAULT ''", "reply": "TEXT NOT NULL DEFAULT ''",
                  "question": "TEXT NOT NULL DEFAULT ''", "waiting": "TEXT NOT NULL DEFAULT ''",
                  "waiting_at": "REAL NOT NULL DEFAULT 0", "files": "TEXT NOT NULL DEFAULT '[]'",
                  "commits": "TEXT NOT NULL DEFAULT '[]'", "branch": "TEXT NOT NULL DEFAULT ''",
                  "head": "TEXT NOT NULL DEFAULT ''"}
TEXT_LIMITS = {"prompt": 2000, "reply": 4000, "question": 1000, "waiting": 1000, "branch": 200, "head": 40}
SCHEMA = """
CREATE TABLE IF NOT EXISTS items (
    key TEXT PRIMARY KEY, kind TEXT NOT NULL, host TEXT NOT NULL, harness TEXT NOT NULL,
    native_id TEXT NOT NULL, title TEXT NOT NULL DEFAULT '', cwd TEXT NOT NULL DEFAULT '',
    surface TEXT NOT NULL DEFAULT '', background INTEGER NOT NULL DEFAULT 0,
    state TEXT NOT NULL, prompt_at REAL, stop_at REAL, read_at REAL, event_at REAL NOT NULL DEFAULT 0,
    pane TEXT NOT NULL DEFAULT '', url TEXT NOT NULL DEFAULT '', task_state TEXT NOT NULL DEFAULT '',
    position REAL, updated_at REAL NOT NULL,
    closed_at REAL NOT NULL DEFAULT 0, turn_id TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS items_state ON items(state, stop_at);
CREATE TABLE IF NOT EXISTS applied (id TEXT PRIMARY KEY, at REAL NOT NULL);
CREATE TABLE IF NOT EXISTS meta (name TEXT PRIMARY KEY, value TEXT NOT NULL);
"""


def connect(path: Path = STORE) -> sqlite3.Connection:
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    db = sqlite3.connect(path, timeout=10)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA journal_mode=WAL")
    db.executescript(SCHEMA)
    db.execute("BEGIN IMMEDIATE")
    columns = {row[1] for row in db.execute("PRAGMA table_info(items)")}
    for name, declaration in {"closed_at": "REAL NOT NULL DEFAULT 0", "turn_id": "TEXT NOT NULL DEFAULT ''",
                              "run_id": "TEXT NOT NULL DEFAULT ''", **DETAIL_COLUMNS}.items():
        if name not in columns:
            db.execute(f"ALTER TABLE items ADD COLUMN {name} {declaration}")
    db.commit()
    path.chmod(0o600)
    return db


def apply(db: sqlite3.Connection, event: dict) -> bool:
    """Apply one event once. Times decide order, so late or repeated deliveries are harmless."""
    kind = event["type"]
    if kind not in {"prompt", "stop", "closed", "metadata", "finished", "wait"}:
        raise ValueError(f"Unknown inbox event: {kind}")
    if db.execute("INSERT OR IGNORE INTO applied(id, at) VALUES (?, ?)", (event["id"], time.time())).rowcount == 0:
        return False
    at, now = float(event["at"]), time.time()
    key = session_key(event["host"], event["harness"], event["native_id"])
    row = db.execute("SELECT * FROM items WHERE key=?", (key,)).fetchone()
    if kind in {"metadata", "finished"}:
        if row is None or row["kind"] != "session" or row["event_at"] != event.get("expected_event_at"):
            return False
        if kind == "metadata":
            fields = {name: event[name] for name in ("run_id", "background") if name in event}
            if not fields:
                return False
            db.execute(f"UPDATE items SET {', '.join(f'{name}=?' for name in fields)}, updated_at=? WHERE key=?",
                       (*fields.values(), now, key))
        else:
            if not row["background"] or row["state"] != "running" or not row["run_id"] or row["run_id"] != event.get("run_id") or at < row["event_at"]:
                return False
            db.execute("UPDATE items SET state='read', stop_at=?, event_at=?, closed_at=?, read_at=?, updated_at=? WHERE key=?",
                       (at, at, at, max(at, row["read_at"] or 0), now, key))
        return True
    if kind == "closed":
        if row is None or row["surface"] != "herdr" or row["state"] == "read" or row["event_at"] != event.get("expected_event_at") or at < row["event_at"]:
            return False
        db.execute("UPDATE items SET state='read', read_at=?, closed_at=?, updated_at=? WHERE key=?",
                   (max(at, row["read_at"] or 0), at, now, key))
        return True
    if kind == "wait":
        if row is None or row["state"] != "running" or at < (row["prompt_at"] or 0):
            return False
        db.execute("UPDATE items SET waiting=?, waiting_at=?, updated_at=? WHERE key=?",
                   (_text(event.get("waiting"), TEXT_LIMITS["waiting"]) or "waiting for input", at, now, key))
        return True
    if row is None:
        db.execute("INSERT INTO items(key, kind, host, harness, native_id, state, updated_at) VALUES (?, 'session', ?, ?, ?, 'read', ?)",
                   (key, event["host"], event["harness"], event["native_id"], now))
        row = db.execute("SELECT * FROM items WHERE key=?", (key,)).fetchone()
    start = event.get("prompt_at", at if kind == "prompt" else row["prompt_at"])
    barrier = max(row["read_at"] or 0, row["closed_at"])
    newer_turn = start is not None and start > (row["prompt_at"] or 0)
    if kind == "prompt":
        if at <= barrier or at < (row["prompt_at"] or 0) or (at == row["prompt_at"] and (row["stop_at"] or 0) >= at):
            return False
    elif event.get("prompt_at") is not None:
        if start < (row["prompt_at"] or 0) or (newer_turn and start <= row["closed_at"]):
            return False
    elif event.get("turn_id") and row["turn_id"] and event["turn_id"] != row["turn_id"]:
        return False
    if not newer_turn and at < row["event_at"]:
        return False
    fields = {name: event[name] for name in ("title", "cwd", "surface", "pane", "turn_id") if name in event}
    fields.update({name: _clip(event[name], limit) for name, limit in TEXT_LIMITS.items() if name in event and name != "waiting"})
    fields.update(waiting="", waiting_at=0)
    if "background" in event:
        fields["background"] = int(bool(event["background"]))
    if "run_id" in event:
        fields["run_id"] = event["run_id"]
    background = fields.get("background", row["background"])
    if kind == "prompt":
        fields.update(state="running", prompt_at=at, read_at=at, closed_at=0, question="")
    else:
        fields.update(files=_merge(row["files"], event.get("files"), 50), commits=_merge(row["commits"], event.get("commits"), 20))
        if newer_turn:
            fields.update(prompt_at=start, read_at=max(start, row["read_at"] or 0), closed_at=0)
        fields.update(state="read" if background or (row["closed_at"] and not newer_turn) or at <= (fields.get("read_at", row["read_at"]) or 0) else "unread", stop_at=at)
    fields.update(event_at=at, updated_at=now)
    db.execute(f"UPDATE items SET {', '.join(f'{name}=?' for name in fields)} WHERE key=?", (*fields.values(), key))
    return True


def _merge(stored: str, new, limit: int) -> str:
    """Accumulate a session's files or commits across turns, newest last, without duplicates."""
    values = json.loads(stored or "[]")
    for value in new if isinstance(new, list) else []:
        if value in values:
            values.remove(value)
        values.append(value)
    return json.dumps(values[-limit:], ensure_ascii=False)


def mark(db: sqlite3.Connection, keys: list[str], state: str) -> int:
    """Dismiss (read) or restore (unread) items by key prefix; running items keep running."""
    now, changed = time.time(), 0
    for prefix in keys:
        rows = db.execute("SELECT key FROM items WHERE key LIKE ? AND state != 'running'", (prefix + "%",)).fetchall()
        if len(rows) != 1:
            raise LookupError(f"{prefix}: {'no item' if not rows else 'ambiguous'}")
        read_at = now if state == "read" else 0
        changed += db.execute("UPDATE items SET state=?, read_at=?, updated_at=? WHERE key=?", (state, read_at, now, rows[0]["key"])).rowcount
    return changed


def listing(db: sqlite3.Connection, *, everything: bool = False, limit: int = 200) -> dict:
    where = "" if everything else "WHERE background = 0"
    rows = db.execute(f"""SELECT * FROM items {where} ORDER BY CASE state WHEN 'unread' THEN 0 WHEN 'running' THEN 1 ELSE 2 END,
                          COALESCE(stop_at, prompt_at, updated_at) DESC LIMIT ?""", (limit,)).fetchall()
    items = [_public(row) for row in rows]
    board = db.execute("SELECT value FROM meta WHERE name='switchboard'").fetchone()
    return {"status": "complete", "items": items, "unread": sum(item["state"] == "unread" for item in items),
            "switchboard": json.loads(board["value"]) if board else None}


def _public(row: sqlite3.Row) -> dict:
    value = dict(row)
    value["id"] = value["key"][:10]
    value["host"] = LABELS.get(value["host"], value["host"])
    value["cwd"] = re.sub(r"^(/Users|/home|/var/services/homes|/volume1/homes)/[^/]+", "~", value["cwd"])
    value["duration"] = round(value["stop_at"] - value["prompt_at"]) if value["stop_at"] and value["prompt_at"] and value["stop_at"] >= value["prompt_at"] else None
    value["background"] = bool(value["background"])
    value["files"], value["commits"] = json.loads(value.get("files") or "[]"), json.loads(value.get("commits") or "[]")
    for name in ("applied", "event_at", "read_at", "closed_at", "turn_id", "run_id"):
        value.pop(name, None)
    return value


def spool(event: dict, directory: Path = SPOOL) -> Path:
    directory.mkdir(parents=True, exist_ok=True, mode=0o700)
    event = {"id": uuid.uuid4().hex, "at": time.time(), "host": host_alias(), **event}
    path = directory / f"{time.time_ns()}-{event['id'][:8]}.json"
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(event, ensure_ascii=False))
    os.replace(temporary, path)
    return path


def flush(directory: Path = SPOOL, *, host: str | None = None) -> dict:
    """Enrich and deliver spooled events to the owner; files are removed only after delivery."""
    host = host or host_alias()
    if host not in MACS:
        return {"status": "complete", "delivered": 0, "pulled_by": OWNER}
    directory.mkdir(parents=True, exist_ok=True, mode=0o700)
    with (directory / ".lock").open("a+") as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            return {"status": "complete", "delivered": 0, "busy": True}
        files = sorted(directory.glob("*.json"))[:500]
        if not files:
            return {"status": "complete", "delivered": 0}
        events = []
        for path in files:
            try:
                events.append(enrich({"host": host, **json.loads(path.read_text())}))
            except (OSError, ValueError):
                path.unlink(missing_ok=True)
        if host == OWNER:
            ingest(events)
        else:
            remote(OWNER, ["inbox", "_ingest"], {"events": events}, timeout=30)
        for path in files:
            path.unlink(missing_ok=True)
        return {"status": "complete", "delivered": len(events)}


def ingest(events: list[dict], path: Path = STORE) -> dict:
    db = connect(path)
    try:
        with db:
            applied = sum(apply(db, event) for event in events)
        return {"status": "complete", "applied": applied}
    finally:
        db.close()


def export(payload: dict, *, host: str, directory: Path = SPOOL) -> dict:
    """Answer M1's pull without changing anything here: spooled events and planned Herdr exits; the planner state round-trips through M1."""
    from .inbox_herdr import exits

    events, names = [], []
    for path in sorted(directory.glob("*.json"))[:EXPORT_LIMIT]:
        names.append(path.name)
        try:
            events.append(enrich({**json.loads(path.read_text()), "host": host}))
        except (OSError, ValueError, KeyError, TypeError, AttributeError):
            continue
    from .inbox_runtime import metadata_events
    items = payload.get("items") or []
    events.extend(metadata_events(items, host=host))
    return {"status": "complete", "host": host, "spool": names, "events": events,
            **exits([item for item in items if not item.get("background")], payload.get("state") or {})}


def acknowledge(names: list, directory: Path = SPOOL) -> dict:
    """Delete only spool files M1 reported stored; a name can never leave the spool directory."""
    removed = 0
    for name in names:
        if isinstance(name, str) and SPOOL_NAME.fullmatch(name) and (directory / name).is_file():
            (directory / name).unlink()
            removed += 1
    return {"status": "complete", "removed": removed}


def _text(value, limit: int) -> str:
    return CONTROL.sub(" ", value)[:limit] if isinstance(value, str) else ""


def _clip(value, limit: int) -> str:
    """Bounded text that keeps both ends: a reply's summary comes first and its question last."""
    if not isinstance(value, str):
        return ""
    value = re.sub(r"[\x00-\x08\x0b-\x1f\x7f]", " ", value)
    return value if len(value) <= limit else value[:limit // 3] + "\n…\n" + value[-(limit - limit // 3 - 3):]


def _time(value, now: float) -> float | None:
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not 1_000_000_000 < value <= now + 300:
        return None
    return float(value)


def admit(host: str, raw, keys: set[str], now: float) -> dict | None:
    """Rebuild one event from a pulled host's untrusted answer: its own host only, bounded plain fields, no extra keys."""
    if not isinstance(raw, dict) or raw.get("type") not in {"prompt", "stop", "closed", "metadata", "wait"} or raw.get("harness") not in {"codex", "claude"}:
        return None
    native_id, at = raw.get("native_id"), _time(raw.get("at"), now)
    if not isinstance(native_id, str) or not NATIVE_ID.fullmatch(native_id) or at is None:
        return None
    event = {"type": raw["type"], "host": host, "harness": raw["harness"], "native_id": native_id, "at": at}
    if raw["type"] in {"closed", "metadata"}:
        expected = raw.get("expected_event_at")
        if session_key(host, raw["harness"], native_id) not in keys or isinstance(expected, bool) or not isinstance(expected, (int, float)):
            return None
        event.update(id=f"{host}:{uuid.uuid4().hex}", expected_event_at=float(expected))
        if raw["type"] == "metadata":
            if raw.get("background") is True:
                event["background"] = 1
            if isinstance(raw.get("run_id"), str) and re.fullmatch(r"\d{1,20}", raw["run_id"]):
                event["run_id"] = raw["run_id"]
        return event
    if not isinstance(raw.get("id"), str) or not re.fullmatch(r"[0-9a-f]{32}", raw["id"]):
        return None
    event.update({name: _text(raw[name], limit) for name, limit in (("title", 300), ("cwd", 500), ("turn_id", 128), ("branch", 200), ("head", 40)) if name in raw})
    event.update({name: _clip(raw[name], TEXT_LIMITS[name]) for name in ("prompt", "reply", "question", "waiting") if name in raw})
    if isinstance(raw.get("files"), list):
        event["files"] = [_text(path, 500) for path in raw["files"][:50] if isinstance(path, str)]
    if isinstance(raw.get("commits"), list):
        event["commits"] = [{"sha": commit["sha"], "subject": _text(commit.get("subject"), 200), "branch": _text(commit.get("branch"), 200)}
                            for commit in raw["commits"][:20]
                            if isinstance(commit, dict) and isinstance(commit.get("sha"), str) and re.fullmatch(r"[0-9a-f]{7,40}", commit["sha"])]
    if "pane" in raw:
        event["pane"] = raw["pane"] if isinstance(raw["pane"], str) and PANE.fullmatch(raw["pane"]) else ""
    event.update(id=f"{host}:{raw['id']}", surface="herdr" if raw.get("surface") == "herdr" else "cli", background=raw.get("background") is True)
    event["run_id"] = raw["run_id"] if isinstance(raw.get("run_id"), str) and re.fullmatch(r"\d{1,20}", raw["run_id"]) else ""
    if raw.get("prompt_at") is not None:
        prompt_at = _time(raw["prompt_at"], now)
        if prompt_at is None:
            return None
        event["prompt_at"] = prompt_at
    return event


def pull_host(host: str, path: Path = STORE, state_dir: Path = PULL_STATE) -> dict:
    """One pull from a host with no route to M1: store what it validly reports, keep its Herdr state, then acknowledge."""
    db = connect(path)
    try:
        items = [dict(row) for row in db.execute("SELECT * FROM items WHERE kind='session' AND (background=0 OR state='running') AND host=?", (host,))]
    finally:
        db.close()
    state_path = state_dir / f"{host}.json"
    previous = json.loads(state_path.read_text()) if state_path.is_file() else {}
    answer = remote(host, ["inbox", "_export"], {"items": items, "state": previous}, timeout=120)
    keys, now = {item["key"] for item in items}, time.time()
    raw = [*(answer.get("events") or [])[:EXPORT_LIMIT], *(answer.get("closed") or [])[:EXPORT_LIMIT]]
    events = [event for event in (admit(host, value, keys, now) for value in raw) if event]
    applied = ingest(events, path)["applied"]
    state = answer.get("state")
    if isinstance(state, dict) and all(isinstance(state.get(name), dict) for name in ("bindings", "missing")):
        state = {name: {key: value for key, value in state[name].items() if key in keys} for name in ("bindings", "missing")}
        if len(json.dumps(state)) <= 1_000_000:
            atomic_json(state_path, state)
    names = [name for name in (answer.get("spool") or [])[:EXPORT_LIMIT] if isinstance(name, str) and SPOOL_NAME.fullmatch(name)]
    removed = remote(host, ["inbox", "_ack"], {"names": names}, timeout=30)["removed"] if names else 0
    return {"status": "complete", "received": len(raw), "rejected": len(raw) - len(events), "applied": applied,
            "acknowledged": removed, "herdr": _text(answer.get("herdr"), 300) or "observed"}


def pull(hosts: tuple = PULLED) -> dict:
    """M1's minute pull from NAS and BV; an unreachable host is a gap, not a failure of the whole maintenance run."""
    results = {}
    for host in hosts:
        try:
            results[host] = pull_host(host)
        except (NotReady, OSError, ValueError, KeyError, TypeError, AttributeError, sqlite3.Error, subprocess.TimeoutExpired) as error:
            results[host] = {"status": "not_ready", "reason": str(error)[:300]}
    return {"status": "complete" if all(value["status"] == "complete" for value in results.values()) else "complete_with_gaps",
            "hosts": results}


def enrich(event: dict) -> dict:
    """Fill surface, title and background from the native session on the host that owns it; a Stop adds what the turn changed."""
    if event.get("type") not in {"prompt", "stop", "wait"} or event.get("enriched"):
        return event
    for name in ("prompt", "reply", "question", "waiting"):
        if isinstance(event.get(name), str):
            event[name] = redact(event[name])
    if event["type"] == "wait":
        event["enriched"] = True
        return event
    pane = event.get("pane", "")
    if event["harness"] == "claude":
        from .inbox_runtime import claude_turn_origin
        transcript = Path(event.get("transcript", ""))
        kind = (claude_turn_origin(transcript, event.get("prompt_at") or 0) or origin("claude", transcript)) if transcript.is_file() else "interactive"
        event["title"] = claude_title(transcript) or event.get("title", "")
        surface = "herdr" if pane else "cli"
    else:
        thread = codex_thread(event["native_id"])
        rollout = Path((thread or {}).get("rollout_path") or "")
        kind = origin("codex", rollout) if rollout.is_file() else "headless" if thread == {} else "interactive"
        thread = thread or {}
        event["title"] = thread.get("name") or event.get("title") or thread.get("title", "")
        event["cwd"] = event.get("cwd") or thread.get("cwd", "")
        desktop = desktop_thread(thread)
        surface = "phone" if desktop and last_client_is_phone(rollout) else "desk" if desktop else "herdr" if pane else "cli"
        transcript = rollout
    if event["type"] == "stop":
        event.update(changes(event["harness"], transcript, event.get("prompt_at"), event.get("cwd", "")))
    if surface == "herdr" or (event["harness"] == "codex" and surface == "cli" and kind not in BACKGROUND):
        try:
            event["pane"] = herdr.find_session(event["harness"], event["native_id"], event.get("title", ""), event.get("cwd", ""))
            surface = "herdr"
        except (OSError, ValueError, KeyError, RuntimeError, LookupError, subprocess.TimeoutExpired):
            event["pane"] = ""
    event.update(surface=surface, background=event.get("background") is True or kind in BACKGROUND, enriched=True)
    event.pop("transcript", None)
    return event


def changes(harness: str, transcript: Path, start, cwd: str) -> dict:
    """The files and commits of the turn that just stopped, and the checkout it left."""
    found = activity.since(harness, transcript, float(start) - 1) if start and transcript.is_file() else {}
    return {"files": found.get("files", []), "commits": found.get("commits", []), **(activity.checkout(cwd) if cwd and Path(cwd).is_dir() else {})}


def desktop_thread(thread: dict) -> bool:
    """Codex Desktop exists only on the Macs; on Linux the CLI's shared app-server daemon also records the Desktop originator."""
    return DESKTOP_APP and (thread.get("originator") == "Codex Desktop" or (thread.get("source") == "vscode" and thread.get("originator") != "codex-tui"))


def codex_thread(native_id: str) -> dict | None:
    """The thread row, {} when Codex has no such thread, None when the state database is unreadable."""
    path = CODEX_HOME / "state_5.sqlite"
    if not path.is_file():
        return None
    try:
        db = sqlite3.connect(f"file:{path}?mode=ro", uri=True, timeout=1)
        db.row_factory = sqlite3.Row
        row = db.execute("SELECT name, title, cwd, source, originator, rollout_path FROM threads WHERE id=?", (native_id,)).fetchone()
        db.close()
    except sqlite3.Error:
        return None
    return dict(row) if row else {}


def _tail(path: Path, window: int = 4 * 1024 * 1024) -> str:
    try:
        with path.open("rb") as handle:
            handle.seek(max(0, path.stat().st_size - window))
            return handle.read().decode(errors="replace")
    except OSError:
        return ""


def claude_title(transcript: Path) -> str:
    """The session name Claude shows: a /rename title, else its generated title (as ctx's index does)."""
    titles: dict[str, str] = {}
    for line in _tail(transcript).splitlines():
        if '"custom-title"' in line or '"ai-title"' in line:
            try:
                record = json.loads(line)
            except ValueError:
                continue
            titles[record.get("type", "")] = record.get("customTitle") or record.get("aiTitle") or ""
    return titles.get("custom-title") or titles.get("ai-title") or ""


def last_client_is_phone(rollout: Path, window: int = 4 * 1024 * 1024) -> bool:
    """The Codex iOS app sends uppercase client IDs and Desktop lowercase ones; the latest prompt decides."""
    found = re.findall(r'"type":"UserMessage"[^\n]*?"client_id":"([0-9A-Fa-f-]{36})"', _tail(rollout, window))
    return bool(found) and found[-1] != found[-1].lower()


def refresh_switchboard(db: sqlite3.Connection, board: str) -> dict:
    """Mirror Switchboard tasks as inbox items and summarize runner slots as lights per machine."""
    from . import switchboard

    issues = json.loads(switchboard.gh("issue", "list", "--repo", board, "--state", "all", "--limit", "60", "--json",
                                       "number,title,url,labels,body,state,createdAt,updatedAt", attempts=1))
    runners = json.loads(switchboard.gh("api", f"repos/{board}/actions/runners", attempts=1))["runners"]
    seeded = db.execute("SELECT 1 FROM meta WHERE name='switchboard'").fetchone() is not None
    now = time.time()
    for issue in issues:
        labels = {label["name"] for label in issue["labels"]}
        machine = next((label[4:] for label in labels if label.startswith("run:")), "")
        task_state = next((name for name in ("running", "failed", "done") if name in labels), "queued" if machine and issue.get("state", "OPEN") == "OPEN" else "")
        fields = switchboard.parse_fields(issue.get("body") or "")
        key, stamp = f"task:{issue['number']}", _epoch(issue["updatedAt"])
        row = db.execute("SELECT task_state, state FROM items WHERE key=?", (key,)).fetchone()
        if row and row["task_state"] == task_state:
            state = row["state"]
        elif task_state in {"running", "queued"}:
            state = "running"
        else:
            state = "unread" if task_state in {"done", "failed"} and seeded else "read"
        db.execute("""INSERT INTO items(key, kind, host, harness, native_id, title, cwd, surface, state, prompt_at, stop_at,
                      url, task_state, updated_at) VALUES (?, 'task', ?, ?, ?, ?, ?, 'switchboard', ?, ?, ?, ?, ?, ?)
                      ON CONFLICT(key) DO UPDATE SET title=excluded.title, cwd=excluded.cwd, state=excluded.state,
                      stop_at=excluded.stop_at, task_state=excluded.task_state, updated_at=excluded.updated_at""",
                   (key, MACHINES.get(machine, machine), fields.get("harness", "codex").lower(), str(issue["number"]),
                    f"#{issue['number']} {issue['title']}", fields.get("directory", ""), state, _epoch(issue["createdAt"]),
                    stamp if task_state in {"done", "failed"} else None, issue["url"], task_state, now))
    summary = {"observed_at": now, "machines": lights(db, runners, board)}
    db.execute("INSERT OR REPLACE INTO meta(name, value) VALUES ('switchboard', ?)", (json.dumps(summary),))
    return summary



def lights(db: sqlite3.Connection, runners: list[dict], board: str) -> list[dict]:
    """One light per runner slot: green while it works a task, red for an offline runner or an unread failure."""
    settings = f"https://github.com/{board}/settings/actions/runners"
    machines = []
    for host in sorted({runner["name"].rsplit("-", 1)[0] for runner in runners}):
        slots = sorted((runner for runner in runners if runner["name"].rsplit("-", 1)[0] == host), key=lambda runner: runner["name"])
        tasks = lambda state, task_state: [dict(row) for row in db.execute(
            "SELECT title, url FROM items WHERE kind='task' AND host=? AND state=? AND task_state=? ORDER BY stop_at DESC, prompt_at",
            (host, state, task_state))]
        running, failed = tasks("running", "running"), tasks("unread", "failed")
        result = []
        for runner in slots:
            if runner["status"] != "online":
                result.append({"state": "err", "title": f"{runner['name']} offline", "url": settings})
            elif runner["busy"]:
                task = running.pop(0) if running else {"title": f"{runner['name']} busy", "url": f"https://github.com/{board}/actions"}
                result.append({"state": "run", **task})
            else:
                result.append({"state": "idle", "title": runner["name"], "url": ""})
        for index in reversed(range(len(result))):
            if failed and result[index]["state"] == "idle":
                result[index] = {"state": "err", **failed.pop(0)}
        machines.append({"host": LABELS.get(host, host), "lights": result})
    return machines


def _epoch(value: str) -> float:
    return datetime.fromisoformat(value.replace("Z", "+00:00")).timestamp()


def run(action: str, *, host: str, keys: tuple = (), everything: bool = False, payload: dict | None = None) -> dict:
    """The `ctx inbox` command: reads and marks go to the owner's store, from any host."""
    if action == "_activity":
        from .review import answer
        return answer(payload or {})
    if action == "_reconcile":
        from .inbox_herdr import reconcile
        from .inbox_runtime import reconcile_metadata
        refreshed = reconcile_metadata(host=host)
        return {**reconcile(host=host), "metadata_queued": refreshed}
    if action == "_focus":
        item = (payload or {})["item"]
        if item["host"] != host:
            raise RuntimeError("Herdr session belongs to another host")
        thread = codex_thread(item["native_id"]) if item["harness"] == "codex" else None
        pane = herdr.find_session(item["harness"], item["native_id"], (thread or {}).get("name") or item["title"], item["cwd"])
        herdr._call("agent", "focus", pane)
        return {"status": "complete", "pane": pane, "host": host}
    if action == "_flush":
        return flush(host=host)
    if action in {"_export", "_ack"}:
        if host not in PULLED:
            raise RuntimeError(f"inbox {action} answers {OWNER}'s pull on {', '.join(PULLED)}")
        return export(payload or {}, host=host) if action == "_export" else acknowledge((payload or {}).get("names") or [])
    if host != OWNER and action in {"ls", "dismiss", "unread", "focus", "_sessions"}:
        return remote(OWNER, ["inbox", action, *keys, *(["--all"] if everything else [])], timeout=20)
    if host != OWNER:
        raise RuntimeError(f"inbox {action} runs on {OWNER}")
    if action == "_pull":
        return pull()
    if action == "_ingest":
        return ingest((payload or {}).get("events", []))
    db = connect()
    try:
        with db:
            if action == "_sessions":
                if len(keys) != 1 or keys[0] not in LABELS:
                    raise ValueError("Choose a known inbox source host")
                return {"status": "complete", "items": [dict(row) for row in db.execute(
                    "SELECT * FROM items WHERE kind='session' AND (background=0 OR state='running') AND host=?", (keys[0],))]}
            if action == "focus":
                if len(keys) != 1:
                    raise LookupError("Choose one inbox session to focus")
                rows = db.execute("SELECT * FROM items WHERE key LIKE ? AND kind='session'", (keys[0] + "%",)).fetchall()
                if len(rows) != 1:
                    raise LookupError("No unique inbox session matches this ID")
                item = dict(rows[0])
                result = run("_focus", host=host, payload={"item": item}) if item["host"] == host else remote(item["host"], ["inbox", "_focus"], {"item": item}, timeout=15)
                db.execute("UPDATE items SET pane=? WHERE key=?", (result["pane"], item["key"]))
                return result
            if action == "_switchboard":
                from .switchboard import BOARD
                from .inbox_runtime import finish_runs
                summary = refresh_switchboard(db, BOARD)
                runs = finish_runs(db, BOARD)
                return {"status": "complete_with_gaps" if runs["deferred_runs"] else "complete", **summary, **runs}
            if action == "dismiss" and everything and not keys:
                changed = db.execute("UPDATE items SET state='read', read_at=?, updated_at=? WHERE state='unread'", (time.time(), time.time())).rowcount
                return {"status": "complete", "changed": changed}
            if action in {"dismiss", "unread"}:
                return {"status": "complete", "changed": mark(db, list(keys), "read" if action == "dismiss" else "unread")}
            return listing(db, everything=everything)
    finally:
        db.close()


def main(argv: list[str]) -> int:
    try:
        print(json.dumps(flush()))
    except (OSError, ValueError, RuntimeError) as error:
        print(json.dumps({"status": "not_ready", "reason": str(error)[:300]}))
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
