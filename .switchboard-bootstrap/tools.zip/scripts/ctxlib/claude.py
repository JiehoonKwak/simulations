"""Claude native archive plans, and background launch or resume on the local host.

Capture is read-only. The caller owns copying, drift checks, receipts, and launch idempotency.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import subprocess
import time
from pathlib import Path
from typing import Any
from urllib.parse import unquote, urlparse

from .dialogue import claude_message

HARNESS = "claude"
NATIVE_SUBTREES = ("projects", "file-history", "attachments", "plans", "paste-cache")
_ID = re.compile(r"[A-Za-z0-9_-]+\Z")
_OUTPUT = re.compile(r"Full output saved to:\s*([^\r\n<]+)")
_URL = re.compile(r"https://claude\.ai/code/[A-Za-z0-9_-]+(?:\?[^\s\x1b]*)?")
_ANSI = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")


def _config(home: Path | None) -> Path:
    if home is not None:
        return Path(home).expanduser().resolve() / ".claude"
    return Path(os.environ.get("CLAUDE_CONFIG_DIR", str(Path.home() / ".claude"))).expanduser().resolve()


def native_root(home: Path | None = None) -> Path:
    return _config(home)


def _environment(home: Path | None) -> dict[str, str]:
    env = os.environ.copy()
    if home is not None:
        env["CLAUDE_CONFIG_DIR"] = str(_config(home))
    return env


def _records(path: Path) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Read a complete valid JSONL prefix, retaining native byte/line cutoffs."""
    records: list[dict[str, Any]] = []
    cutoff: dict[str, Any] = {
        "byte_count": 0, "record_count": 0, "last_line": 0,
        "last_uuid": "", "last_timestamp": "", "error": "",
    }
    with path.open("rb") as stream:
        size = os.fstat(stream.fileno()).st_size
        cutoff["source_byte_count"] = size
        remaining = size
        for line_number, line in enumerate(stream, 1):
            if len(line) > remaining:
                line = line[:remaining]
            remaining -= len(line)
            if not line:
                break
            try:
                record = json.loads(line)
                if not isinstance(record, dict):
                    raise ValueError("native record is not an object")
            except (UnicodeDecodeError, ValueError) as error:
                cutoff["error"] = f"invalid JSONL record at line {line_number}: {type(error).__name__}"
                break
            records.append(record)
            cutoff.update(
                byte_count=cutoff["byte_count"] + len(line),
                record_count=len(records), last_line=line_number,
                last_uuid=record.get("uuid") or cutoff["last_uuid"],
                last_timestamp=record.get("timestamp") or cutoff["last_timestamp"],
            )
            if remaining <= 0:
                break
    cutoff["excluded_tail_bytes"] = size - cutoff["byte_count"]
    return records, cutoff


def _info(records: list[dict[str, Any]]) -> dict[str, Any]:
    info = {"cwd": "", "title": "", "started_at": "", "latest_user_request": ""}
    first_user = ""
    custom_title = ""
    for record in records:
        info["cwd"] = record.get("cwd") or info["cwd"]
        info["started_at"] = info["started_at"] or record.get("timestamp") or ""
        if record.get("type") == "custom-title":
            custom_title = record.get("customTitle") or custom_title
        elif record.get("type") == "ai-title":
            info["title"] = record.get("aiTitle") or info["title"]
        elif record.get("type") == "user":
            text = "\n".join(claude_message(record)[0])
            if text:
                first_user = first_user or text
                info["latest_user_request"] = text
    info["title"] = custom_title or info["title"] or first_user[:160]
    return info


def discover(*, home: Path | None = None) -> list[dict[str, Any]]:
    root = _config(home) / "projects"
    sessions = []
    for path in sorted(root.glob("*/*.jsonl")):
        if path.is_symlink() or not _ID.fullmatch(path.stem):
            continue
        records, cutoff = _records(path)
        sessions.append({
            "native_id": path.stem, "harness": HARNESS, **_info(records),
            "updated_at": path.stat().st_mtime,
            "native_path": str(path), "cutoff": cutoff,
        })
    return sessions


def _session(native_id: str, root: Path) -> Path:
    if not _ID.fullmatch(native_id):
        raise ValueError("invalid Claude native session ID")
    matches = list((root / "projects").glob(f"*/{native_id}.jsonl"))
    if len(matches) != 1:
        raise RuntimeError(f"Claude session {native_id}: expected one native transcript, found {len(matches)}")
    return matches[0]


def _references(record: dict[str, Any], root: Path, native_id: str) -> list[str]:
    """Follow stored outputs/attachments, not arbitrary paths mentioned by tools."""
    references: list[str] = []

    def walk(value: Any) -> None:
        if isinstance(value, dict):
            if isinstance(value.get("type"), str) and value["type"] in {"file", "image", "document"}:
                for field in ("path", "file_path", "filePath", "localPath"):
                    if isinstance(value.get(field), str):
                        references.append(value[field])
                if isinstance(value.get("url"), str) and value["url"].startswith("file://"):
                    references.append(value["url"])
            for key, item in value.items():
                if key == "persistedOutputPath" and isinstance(item, str):
                    references.append(item)
                elif key == "agentId" and isinstance(item, str) and _ID.fullmatch(item):
                    references.append(str(root / "projects" / record.get("_project_dir", "") / native_id / "subagents" / f"agent-{item}.jsonl"))
                elif key == "backupFileName" and isinstance(item, str) and item:
                    references.append(str(root / "file-history" / native_id / item))
                walk(item)
        elif isinstance(value, list):
            for item in value:
                walk(item)
        elif isinstance(value, str) and "<persisted-output>" in value:
            references.extend(match.strip() for match in _OUTPUT.findall(value))

    walk(record)
    tool_result = record.get("toolUseResult")
    if isinstance(tool_result, dict) and isinstance(tool_result.get("outputFile"), str):
        references.append(tool_result["outputFile"])
    attachment = record.get("attachment") or {}
    if isinstance(attachment, dict) and attachment.get("type") in {
        "file", "image", "document", "uploaded_file", "pasted_image", "plan_mode_exit",
    }:
        for key in ("path", "filePath", "file_path", "filename", "localPath", "planFilePath"):
            if isinstance(attachment.get(key), str):
                references.append(attachment[key])
    return references


def _credential_path(path: Path, root: Path) -> bool:
    parts = set(path.parts)
    return bool(parts & {".ssh", ".aws", ".gnupg", "Keychains"}) or path.name in {
        ".credentials.json", "auth.json", "credentials.json", "credentials", ".env",
    } or path.name.startswith(".env.") or path == root / "settings.json"


def _inventory(home: Path | None) -> list[dict[str, Any]]:
    binary = shutil.which("claude")
    if not binary:
        raise RuntimeError("Claude CLI unavailable; cannot verify source lifecycle")
    result = subprocess.run(
        [binary, "agents", "--json", "--all"], stdin=subprocess.DEVNULL,
        capture_output=True, text=True, timeout=2, env=_environment(home), check=False,
    )
    if result.returncode:
        raise RuntimeError("Claude native session inventory failed; source lifecycle unknown")
    try:
        rows = json.loads(result.stdout)
    except ValueError as error:
        raise RuntimeError("Claude native inventory returned invalid JSON") from error
    if not isinstance(rows, list) or any(not isinstance(row, dict) for row in rows):
        raise RuntimeError("Claude native inventory returned an unsupported schema")
    return rows


def saved_boundary(native_id: str, *, home: Path | None = None) -> dict[str, Any]:
    """Observe lifecycle; never stop a user's process or infer idle from file age."""
    if not _ID.fullmatch(native_id):
        raise ValueError("invalid Claude native session ID")
    try:
        rows = [row for row in _inventory(home) if row.get("sessionId") == native_id]
    except (OSError, RuntimeError, subprocess.TimeoutExpired) as error:
        return {"ready": False, "reason": str(error), "evidence": "native_inventory_unavailable"}
    if not rows:
        return {"ready": True, "reason": "source absent from native active inventory", "evidence": "native_inventory", "state": "stopped"}
    for row in rows:
        state, status = row.get("state"), row.get("status")
        if state == "working" or status in {"busy", "waiting"} or (state == "blocked" and status != "idle"):
            return {"ready": False, "reason": f"Claude source is {state or status}; finish or stop this task through Claude before handoff", "evidence": "native_inventory", "state": state, "status": status, "waiting_for": row.get("waitingFor", "")}
        if state not in {"done", "stopped", "failed"} and status != "idle":
            return {"ready": False, "reason": "Claude source lifecycle is unknown", "evidence": "native_inventory"}
    return {"ready": True, "reason": "native source reports a saved idle/stopped boundary", "evidence": "native_inventory", "state": rows[0].get("state"), "status": rows[0].get("status")}


def source_state(native_id: str, *, home: Path | None = None) -> dict[str, Any]:
    """Inventory native sidecars so new dependencies invalidate an idle capture."""
    primary = _session(native_id, _config(home))
    directory = primary.with_suffix("")
    files = {str(primary)}
    if directory.is_dir():
        files.update(str(path) for path in directory.rglob("*") if path.is_file() or path.is_symlink())
    return {"metadata": {"primary": str(primary)}, "files": sorted(files)}


def capture(native_id: str, *, home: Path | None = None, require_saved_boundary: bool = False) -> dict[str, Any]:
    root = _config(home)
    primary_path = _session(native_id, root)
    files: dict[str, dict[str, Any]] = {}
    missing: list[dict[str, str]] = []
    cutoffs: list[dict[str, Any]] = []
    all_records: list[dict[str, Any]] = []
    main_records: list[dict[str, Any]] = []
    dependency_aliases: list[dict[str, str]] = []

    def add(path: Path, *, native: bool = False) -> None:
        if str(path) in files:
            return
        if not native and path.is_symlink() and str(path.resolve()) in files:
            dependency_aliases.append({"source": str(path), "path": files[str(path.resolve())]["path"]})
            return
        if path.is_symlink() or any(parent.is_symlink() for parent in path.parents if parent != root.parent):
            missing.append({"source": str(path), "reason": "symlink dependency is not an immutable native file"})
            return
        if _credential_path(path, root):
            missing.append({"source": str(path), "reason": "credential/configuration file excluded"})
            return
        if not path.is_file():
            missing.append({"source": str(path), "reason": "required saved dependency missing"})
            return
        try:
            relative = path.relative_to(root).as_posix()
        except ValueError:
            relative = f"attachments/{hashlib.sha256(str(path).encode()).hexdigest()[:20]}/{path.name}"
        entry: dict[str, Any] = {"source": str(path), "path": relative}
        files[str(path)] = entry
        if native and path.suffix == ".jsonl":
            records, cutoff = _records(path)
            entry["byte_count"] = cutoff["byte_count"] if require_saved_boundary else cutoff["source_byte_count"]
            cutoffs.append({"path": relative, **cutoff})
            all_records.extend(records)
            if path == primary_path:
                main_records.extend(records)

    add(primary_path, native=True)
    session_dir = primary_path.with_suffix("")
    if session_dir.is_symlink():
        missing.append({"source": str(session_dir), "reason": "native session directory is a symlink"})
    elif session_dir.is_dir():
        for path in sorted(session_dir.rglob("*")):
            if path.is_file() or path.is_symlink():
                add(path, native=True)
    for record in all_records:
        for reference in _references({**record, "_project_dir": primary_path.parent.name}, root, native_id):
            if reference.startswith("file://"):
                reference = unquote(urlparse(reference).path)
            path = Path(reference).expanduser()
            if not path.is_absolute():
                cwd = record.get("cwd")
                if not cwd:
                    missing.append({"source": reference, "reason": "relative dependency without native cwd"})
                    continue
                path = Path(cwd) / path
            add(path)
    primary = primary_path.relative_to(root).as_posix()
    primary_cutoff = next((item for item in cutoffs if item["path"] == primary), {})
    complete = bool(primary_cutoff.get("record_count")) and not missing and all(not item["excluded_tail_bytes"] for item in cutoffs)
    boundary = saved_boundary(native_id, home=home) if require_saved_boundary else {"ready": False, "reason": "lifecycle not checked for ordinary archive capture"}
    if require_saved_boundary and (not primary_cutoff.get("record_count") or any(item["excluded_tail_bytes"] for item in cutoffs)):
        boundary = {**boundary, "ready": False, "reason": "native saved checkpoint has a partial trailing record"}
    return {
        "native_id": native_id, "harness": HARNESS, **_info(main_records),
        "files": list(files.values()), "primary": primary,
        "metadata": {"native_path": str(primary_path), "native_config_root": str(root), "preservation": "complete native records; no live process state", "dependency_aliases": dependency_aliases, "raw_locator": {"path": primary, "line_start": 1, "line_end": primary_cutoff.get("last_line", 0)}},
        "cutoff": {**primary_cutoff, "jsonl": cutoffs},
        "complete": complete, "missing": missing, "saved_boundary": boundary,
    }


def holder(native_id: str, *, home: Path | None = None) -> str | None:
    """Name a live interactive process that keeps this session open here, if any."""
    rows = [row for row in _inventory(home) if row.get("sessionId") == native_id and row.get("pid")]
    if any(row.get("kind") != "background" for row in rows):
        return "the Claude session is open in a terminal on this host; exit it first"
    return None


def release(native_id: str, *, home: Path | None = None) -> None:
    """Stop background jobs and wait for final native records before copying or resuming."""
    binary = shutil.which("claude")
    for row in _inventory(home):
        if binary and row.get("sessionId") == native_id and row.get("pid") and row.get("kind") == "background":
            result = subprocess.run([binary, "stop", row["id"]], stdin=subprocess.DEVNULL, capture_output=True, timeout=10, env=_environment(home), check=False)
            if result.returncode:
                raise RuntimeError("Claude background stop failed; do not copy or resume this session yet")
            deadline = time.monotonic() + 10
            while True:
                try:
                    os.kill(row["pid"], 0)
                except ProcessLookupError:
                    break
                if time.monotonic() >= deadline:
                    raise RuntimeError("Claude background process has not exited; final records are not ready")
                time.sleep(0.1)


def launch(workspace: Path, prompt: str, *, resume: str, home: Path | None = None) -> dict[str, Any]:
    """Continue session `resume` in the background under its own ID and title; report mobile evidence separately."""
    workspace = Path(workspace).expanduser().resolve()
    if not workspace.is_dir() or not prompt.strip():
        raise ValueError("Claude receiver needs an existing worktree and nonempty bootstrap")
    binary = shutil.which("claude")
    if not binary:
        return {"status": "not_ready", "reason": "Claude CLI is not installed on destination", "retry_safe": True}
    native_login_environment = _environment(home)
    native_login_environment.pop("CLAUDE_CODE_OAUTH_TOKEN", None)
    try:
        preflight = subprocess.run([binary, "remote-control", "--help"], cwd=Path(home).expanduser().resolve() if home else Path.home(), stdin=subprocess.DEVNULL, capture_output=True, text=True, timeout=10, env=native_login_environment, check=False)
    except (OSError, subprocess.TimeoutExpired):
        return {"status": "not_ready", "reason": "Claude Remote Control eligibility could not be checked", "retry_safe": True}
    if preflight.returncode:
        return {"status": "not_ready", "reason": "Destination Remote Control is unavailable; check full-scope claude auth login, supported subscription and endpoint", "retry_safe": True}
    try:
        keeps_saved_options = any(row.get("sessionId") == resume for row in _inventory(home))
    except (OSError, RuntimeError, subprocess.TimeoutExpired):
        keeps_saved_options = False
    command = [binary, "--bg", "--resume", resume, *([] if keeps_saved_options else ["--remote-control"]), "--", prompt]
    try:
        result = subprocess.run(command, cwd=workspace, stdin=subprocess.DEVNULL, capture_output=True, text=True, timeout=30, env=native_login_environment, check=False)
    except subprocess.TimeoutExpired:
        return {"status": "not_ready", "reason": "Claude launch timed out; find session " + resume + " in claude agents before retrying", "launch_uncertain": True}
    except OSError:
        return {"status": "not_ready", "reason": "Claude receiver process could not be started", "retry_safe": True}
    if result.returncode:
        if "Workspace not trusted." in result.stderr:
            return {"status": "not_ready", "reason": "Claude destination worktree requires its native trust prompt: " + str(workspace), "exit_code": result.returncode, "retry_safe": True}
        return {"status": "not_ready", "reason": "Claude receiver refused launch; inspect destination native inventory before retrying", "exit_code": result.returncode, "launch_uncertain": True}
    output = _ANSI.sub("", result.stdout + "\n" + result.stderr)
    url = _URL.search(output)
    background = re.search(r"backgrounded\s*[·:]\s*([A-Za-z0-9_-]+)", output)
    job_id = background.group(1) if background else ""
    try:
        matches = [row for row in _inventory(home) if job_id and row.get("id") == job_id and row.get("sessionId")]
    except (OSError, RuntimeError, subprocess.TimeoutExpired):
        matches = []
    if len(matches) != 1 or matches[0]["sessionId"] != resume:
        return {"status": "not_ready", "background_id": job_id,
                "reason": "Claude started but could not be verified as the resumed session; inspect this background job before retrying",
                "launch_uncertain": True}
    session_id = matches[0]["sessionId"]
    if job_id and not url:
        try:
            logs = subprocess.run([binary, "logs", job_id], stdin=subprocess.DEVNULL, capture_output=True, text=True, timeout=2, env=native_login_environment, check=False)
            url = _URL.search(_ANSI.sub("", logs.stdout))
        except (OSError, subprocess.TimeoutExpired):
            pass
    return {"status": "started", "native_id": session_id, "background_id": job_id, "workspace": str(workspace), "mobile_ready": bool(url), "mobile_url": url.group(0) if url else None, "mobile_reason": "Remote Control URL observed; mobile connection still needs verification" if url else "Remote Control requested; no connected URL observed yet. Check claude logs and destination full-scope login before claiming mobile availability.", "attach_command": [binary, "attach", job_id] if job_id else [binary, "--resume", session_id]}
